let fverif = {
    key: { 
        participant: '0@s.whatsapp.net', 
        remoteJid: '0@s.whatsapp.net' 
    }, 
    message: {
        conversation: "*Mans-Wabot Terverifikasi Oleh WhatsApp*"
    }
}

let handler = async (m, { conn }) => {
    await conn.sendMessage(m.chat, { text: 'wa.me/6288989721627', ...fverif });
}

handler.tags = ['main', 'info']
handler.help = ['owner', 'creator']
handler.command = ['owner', 'creator']

module.exports = handler