/*
By manzxxr
ig @manzkenzzid_
*/

const cheerio = require('cheerio')
let handler = async (m, { conn, text }) => {
if (!text) return m.reply('```🚩 Example : .appvn idle```')
m.reply('wait a minute...')
let results = await searchAppVn(text)
if (results.length > 0) {
let message = 'Hasil pencarian:\n\n';
results.forEach((result, index) => {
message += `Title : ${result.title}\nVersi : ${result.version}\nDeveloper : ${result.author}\nUrl : ${result.url}\n\n`;
 });
m.reply(message)
 } else {
m.reply('Tidak Ada Hasil.');
}
}
handler.helps = ['appvn']
handler.tags = ['tools']
handler.command = ['appvn']
module.exports = handler

async function searchAppVn(query) {
const link = "https://appvn.com"
  const response = await fetch(link + "/android/search?keyword=" + query); // Ganti URL dengan URL yang sesuai
  const body = await response.text();
  const $ = cheerio.load(body);
  const resultArray = [];
  $("div.section-content li.item").each((index, element) => {
    const item = {
      title: $(element).find("div.info > a").text().trim(),
      url: link + $(element).find("div.info > a").attr("href"),
      image: $(element).find("img.lazy").attr("data-src"),
      version: $(element).find("div.vol-chap.ver.text-left > p:first-child").text().trim(),
      date: $(element).find("div.vol-chap.ver.text-left > p.new-chap").text().trim(),
      author: $(element).find("div.new-chap.author > a").text().trim(),
      detailLink: link + $(element).find("div.btn.btn-download > a").attr("href"),
    };
    resultArray.push(item);
  });
  return resultArray;
}