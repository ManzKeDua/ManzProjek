const axios = require('axios')

let manz = async (m, { text, reply, usedPrefix, command }) => {

if (!text) return m.reply(`Masukkan teks\n\nContoh: ${usedPrefix + command} Atmin Ganteng`);
let rulz = `https://api.zenkey.my.id/api/maker/brat?text=${encodeURIComponent(text)}&apikey=zenkey`;
try {
const res = await axios.get(rulz, { responseType: 'arraybuffer' });
const buffer = Buffer.from(res.data, 'binary');
await conn.sendImageAsSticker(m.chat, buffer, m, { packname: `Mans-Wabot`, author: `V2.0.1` });
} catch (e) {
console.log(e);
await m.reply(`Sedang maintenance atau API error`);
    }
}
manz.help = ['brat']
manz.tags = ['sticker']
manz.command = ['brat']
module.exports = manz