let fetch = require('node-fetch');

let timeout = 100000; // Timeout dalam milidetik
let poin = 10000; // Poin yang didapat

let handler = async (m, { conn, usedPrefix }) => {
    conn.susun = conn.susun ? conn.susun : {};
    let id = m.chat;

    // Cek apakah ada soal yang belum terjawab
    if (id in conn.susun) {
        conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.susun[id][0]);
        throw false;
    }

    // Ambil data dari API
    let src = await (await fetch(`https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json`)).json();
    let json = src[Math.floor(Math.random() * src.length)];

    // Buat caption untuk ditampilkan di WA
    let caption = `
${json.soal}

┌─⊷ *SOAL*
▢ Tipe: ${json.tipe}
▢ Timeout *${(timeout / 1000).toFixed(2)} detik*
▢ Ketik ${usedPrefix}susn untuk bantuan
▢ Bonus: ${poin} money
▢ *Balas/ replay soal ini untuk menjawab*
└──────────────
`.trim();

    // Simpan soal dan set timeout
    conn.susun[id] = [
        await conn.reply(m.chat, caption, m),
        json, poin,
        setTimeout(() => {
            if (conn.susun[id]) {
                conn.reply(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.susun[id][0]);
                delete conn.susun[id];
            }
        }, timeout)
    ];
};

handler.help = ['susunkata'];
handler.tags = ['game'];
handler.command = /^susunkata/i;
handler.register = false;
handler.group = false;

module.exports = handler;

// tested di bileys versi 6.5.0 dan sharp versi 0.30.5
// danaputra133
// fixed by manz