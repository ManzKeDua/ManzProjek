let handler = async (m, { conn, usedPrefix }) => {
	let user = global.db.data.users[m.sender]
  let ManzUrl = 'https://telegra.ph/file/dd7b21716bbdc2d43dfc9.jpg'
	let cap = `K A N D A N G  - B U R U A N

*🐂 = [ ${user.banteng} ] banteng*
*🐅 = [ ${user.harimau} ] harimau*
*🐘 = [ ${user.gajah} ] gajah*
*🐐 = [ ${user.kambing} ] kambing*
*🐼 = [ ${user.panda} ] panda*
*🐊 = [ ${user.buaya} ] buaya*
*🐃 = [ ${user.kerbau} ] kerbau*
*🐮 = [ ${user.sapi} ] sapi*
*🐒 = [ ${user.monyet} ] monyet*
*🐗 = [ ${user.babihutan} ] babihutan*
*🐖 = [ ${user.babi} ] babi*
*🐓 = [ ${user.ayam} ] ayam*

Gunakan *${usedPrefix}pasar* untuk dijual atau *${usedPrefix}cook* untuk dijadikan bahan masakan.`

conn.sendFile(m.chat, ManzUrl, 'kandang.jpg', cap, m)
}	

handler.help = ['kandang']
handler.tags = ['rpg']
handler.command = /^(kandang)$/i

module.exports = handler