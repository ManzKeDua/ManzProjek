const cheerio = require('cheerio')

let handler = async (m, { conn, text, }) => {
if (!text) return m.reply('```🚩 Example : .brilio batik```')
m.reply('wait a minute...')
let results = await searchBrilio(text)
if (results.length > 0) {
let message = 'Hasil pencarian:\n\n';
results.forEach((result, index) => {
message += `Judul : ${result.title}\nDate : ${result.date}\nUrl : ${result.url}\n\n`;
 });
m.reply(message)
 } else {
m.reply('Tidak Ada Hasil.');
}
}
handler.help = ['brilio']
handler.tags = ['tools']
handler.command = ['brilio']
module.exports = handler

async function searchBrilio(query) {
  const url = 'https://m.brilio.net'; // Ganti dengan URL yang sesuai
  const response = await fetch(`${url}/search-result/${query}`);
  const html = await response.text();
//wm senn
  const $ = cheerio.load(html);
  const results = [];
//wm senn
  $('ul.article-berita li').each((index, element) => {
    const $element = $(element);
//wm senn
    const articleTitle = $element.find('.text-article a').text().trim();
    const articleUrl = $element.find('.text-article a').attr('href');
//wm senn
    const articleImage = $element.find('.article-img-index').attr('src');
    const articleDate = $element.find('.index-date').text().trim();
//wm senn
    const articleData = {
      title: articleTitle,
      url: articleUrl.startsWith('https://') ? articleUrl : url + articleUrl,
      image: articleImage,
      date: articleDate
    };
//wm senn
    results.push(articleData);
  });
  return results;
}