const axios = require('axios');

const handler = async (m, { text, conn }) => {
if (!text) return m.reply('mau nanya apa?')
    try {
        const response = await fetchContent(text);
        const message = response;
        await conn.sendMessage(m.chat, { text: message.result }, { quoted: m });
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan dalam memproses permintaan.');
    }
};

handler.command = ['latukam'];
handler.help = ['latukam <teks>'];
handler.tags = ['ai'];
handler.limit = true;

async function fetchContent(content) {
    try {
        const response = await axios.post('https://luminai.my.id/', {
            content,
            cName: "latukam",
            cID: "latukam"
        });
        return response.data;
    } catch (error) {
        console.error(error);
        throw error;
    }
}

module.exports = handler;