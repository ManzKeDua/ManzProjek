const axios = require('axios');
const cheerio = require('cheerio');

let manz = async (m, { usedPrefix, command, text }) => {
  if (!text) return m.reply(`*☘️ Example :* ${usedPrefix + command} Majo no tabitabi`);

  async function AvoskyZV(keyword, m) {
    try {
      const searchUrl = `https://9animetv.to/search?keyword=${encodeURIComponent(keyword)}`;
      const { data } = await axios.get(searchUrl);
      const $ = cheerio.load(data);

      const animeList = [];

      $('.flw-item').each((index, element) => {
        const titleElement = $(element).find('.film-name a');
        const title = titleElement.text().trim();
        const link = titleElement.attr('href');

        const imageUrl = $(element).find('.film-poster-img').attr('data-src');
        animeList.push({
          title,
          link: `https://9animetv.to${link}`,
          imageUrl
        });
      });

      if (animeList.length > 0) {
        let AvoskyZ = `*Results For '${keyword}':*\n\n`;
        animeList.forEach(anime => {
          AvoskyZ += `*Title:* ${anime.title}\n`;
          AvoskyZ += `*Link:* ${anime.link}\n`;
          AvoskyZ += `*Image URL:* ${anime.imageUrl}\n\n`;
        });
        m.reply(AvoskyZ); // Ganti reply dengan m.reply
      } else {
        m.reply(`Anime with search '${keyword}' not found.`);
      }

    } catch (error) {
      console.error('Error:', error);
      m.reply('Error occurred while fetching data.');
    }
  }

  AvoskyZV(text, m); // Menggunakan text langsung tanpa encodeURIComponent
};

manz.help = ['9anime'];
manz.tags = ['anime']; // Menambahkan tanda sama dengan
manz.command = ['9anime']; // Menambahkan tanda sama dengan
module.exports = manz;