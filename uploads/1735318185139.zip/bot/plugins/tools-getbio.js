// * Code By Nazand Code
// * Fitur getbio beton (Dibuat Krn Gabut)
// * Hapus Wm Denda 500k Rupiah
// * https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l

const fetch = require('node-fetch');
const { 
    proto, 
    generateWAMessageFromContent, 
    prepareWAMessageMedia 
} = require('@adiwajshing/baileys');

let handler = async (m, { conn, args }) => {
    if (!args[0]) return m.reply("Silakan masukkan nomor telepon yang ingin dicari bionya.");
    let number = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'; 

    try {
        await conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });
        let [contact] = await conn.onWhatsApp(number);
        
        if (contact && contact.exists) {
            let contactInfo = await conn.fetchStatus(number).catch(() => null);

            let name = contactInfo && contactInfo.status ? contactInfo.status : "Bio dari nomor tersebut tidak ada atau disetel private.";
            let responseMessage = `Bio dari nomor tersebut adalah: ${name}`;

            let whatsappUrl = `https://wa.me/${args[0].replace(/[^0-9]/g, '')}`;
            let msgs = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": {
                            "deviceListMetadata": {},
                            "deviceListMetadataVersion": 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: responseMessage
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: wm
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: true,
                                ...await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/xdd7es.jpg" } }, { upload: conn.waUploadToServer })
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        "name": "cta_url",
                                        "buttonParamsJson": `{"display_text":"${name}","url":"${whatsappUrl}"}` //klo mau diubah menjadi copy teks silahkan
                                    }
                                ],
                            })
                        })
                    }
                }
            }, { quoted: m });

            return await conn.relayMessage(m.chat, msgs.message, {});
        } else {
            m.reply("Nomor tersebut tidak terdaftar di WhatsApp.");
        }
    } catch (error) {
        m.reply("Terjadi kesalahan saat mengambil bio: " + error.message);
    }
};

handler.help = ["getbio"].map(v => v + " <nomor>");
handler.tags = ["tools"];
handler.command = /^getbio$/i;
handler.limit = false;
handler.register = true;
module.exports = handler; 