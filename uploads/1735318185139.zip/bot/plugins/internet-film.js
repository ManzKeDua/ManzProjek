const https = require('https');
const cheerio = require('cheerio');

let manz = async (m, { reply, text }) => {
    if (!text) return m.reply('Masukan query'); // Memastikan query ada

    const wait = 'Sedang mencari...'; // Menambahkan pesan tunggu
    m.reply(wait);

    async function film(query) {
        return new Promise((resolve, reject) => {
            const url = `https://ruangmoviez.my.id/?s=${query}`;
            
            https.get(url, (resp) => {
                let data = '';
                
                resp.on('data', (chunk) => {
                    data += chunk;
                });
                
                resp.on('end', () => {
                    let $ = cheerio.load(data);
                    const movies = [];

                    $('article.item-infinite').each((index, element) => {
                        const movie = {};
                        movie.link = $(element).find('a[itemprop="url"]').attr('href');
                        movie.title = $(element).find('h2.entry-title a').text();
                        movie.relTag = $(element).find('a[rel="category tag"]').map((i, el) => $(el).text()).get();
                        movies.push(movie);
                    });

                    resolve({
                        status: 200,
                        creator: 'Author', // Menambahkan penulis
                        result: movies
                    });
                });
            }).on("error", (err) => {
                resolve({
                    status: 404,
                    msg: err.message
                });
            });
        });
    }

    let { result } = await film(text);
    let cap = `\`Search Film From: ${text}\`\n\n`;
    for (let res of result) {
        cap += `*Title*: ${res.title}\n`;
        cap += `*Link*: ${res.link}\n`;
        cap += `*Genre*: ${res.relTag.map(v => v).join(', ')}\n\n`;
    }
    
    if (result.length === 0) {
        cap += 'Tidak ada film yang ditemukan. 😞'; // Pesan jika tidak ada hasil
    }

    m.reply(cap);
}

manz.help = ['filmsearch'];
manz.tags = ['internet'];
manz.command = ['filmsearch'];
module.exports = manz;