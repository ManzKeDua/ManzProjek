const { MessageType, prepareWAMessageMedia, generateWAMessageFromContent } = require('@adiwajshing/baileys');
const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn, text, command, usedPrefix, args }) => {
    const chara = args.join(' '); // Mengambil argumen karakter
    if (!chara) return m.reply(`Contoh: ${usedPrefix}${command} Naruto`);

    const konachan = async (chara) => {
        return new Promise((resolve, reject) => {
            let text = chara.replace(' ', '_');
            axios.get('https://konachan.net/post?tags=' + text + '+')
                .then(({ data }) => {
                    const $$ = cheerio.load(data);
                    const no = [];

                    $$('div.pagination > a').each(function (c, d) {
                        no.push($$(d).text());
                    });

                    let mat = Math.floor(Math.random() * no.length);
                    axios.get('https://konachan.net/post?page=' + mat + '&tags=' + text + '+')
                        .then(({ data }) => {
                            const $ = cheerio.load(data);
                            const result = [];

                            $('#post-list > div.content > div:nth-child(4) > ul > li > a.directlink.largeimg').each(function (a, b) {
                                result.push($(b).attr('href'));
                            });

                            resolve(result);
                        })
                        .catch(reject);
                })
                .catch(reject);
        });
    };

    let push = [];
    for (let i = 0; i < 5; i++) {
        let hasile = await konachan(chara);
        if (hasile.length === 0) return m.reply('Tidak ada hasil yang ditemukan.');

        let ngawi = hasile[Math.floor(Math.random() * hasile.length)]; // Mengambil gambar secara acak
        let tsst = await prepareWAMessageMedia({ 'image': { url: ngawi } }, { 'upload': conn.waUploadToServer });

        push.push({
            body: { text: 'hasil:' },
            footer: { text: '— M4NZK3NZ#1979.' },
            header: { title: '', hasMediaAttachment: true, ...tsst },
            nativeFlowMessage: { buttons: [] }
        });
    }

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: '' },
                    footer: { text: '' },
                    header: { hasMediaAttachment: false },
                    carouselMessage: { cards: [...push] }
                }
            }
        }
    }, { quoted: m });

    await conn.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
    });
};

handler.help = ['konachan'];
handler.tags = ['internet'];
handler.command = ['konachan'];

module.exports = handler;