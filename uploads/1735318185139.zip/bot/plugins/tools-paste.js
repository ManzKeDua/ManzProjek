// * Code By Nazand Code
// * Fitur Upload Teks kepaste.gg (dibuat krn gabut)
// * Hapus WM denda 500k Rupiah
// * https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l
/*
 - Tata Cara Pakai:
 - Gunakan dengan format .paste nama | teks
 - Nama file adalah opsional, jika tidak disediakan, akan menggunakan nama default.
 - Kirim perintah ke bot dan tunggu hingga link hasil upload dikirim.
 
 - Kode ini hanya berfungsi untuk mengunggah teks ke paste.gg.
*/
const axios = require('axios');

const handler = async (m, { conn, args }) => {
    const input = args.join(" ");
    const [name, ...contentParts] = input.split("|").map(part => part.trim());
    const text = contentParts.join(" ");

    if (!text) {
        return m.reply("*Masukkan Nama | Teks Bang*");
    }
    const fileName = name || "Teks_Unggahan_Bot";
    try {
        await m.react('⏳');
        const requestData = {
            name: fileName,
            description: `Unggahan oleh ${fileName}`,
            visibility: "public",
            expires: null,
            files: [
                {
                    name: `${fileName}.txt`,
                    content: {
                        format: "text",
                        value: text
                    }
                }
            ]
        };
        const response = await axios.post("https://api.paste.gg/v1/pastes", requestData, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
        });

        if (
            response.status === 201 &&
            response.data &&
            response.data.result &&
            response.data.result.id
        ) {
            const pasteId = response.data.result.id;
            const pasteUrl = `https://paste.gg/${pasteId}`;

            await conn.sendMessage(m.chat, {
                text: `✅ *Teks berhasil diunggah ke Paste.gg!*\n\n📝 *Nama File:* ${fileName}\n🔗 *Link Unggahan:* ${pasteUrl}\n\n*Terima kasih telah menggunakan layanan kami!*`
            }, { quoted: m });
            await m.react('✅');
            console.log(`Teks telah diunggah ke paste.gg dengan nama "${fileName}" dan link dikirim ke ${m.chat}`);
        } else {
            console.error("Error dalam respons API paste.gg:", response.data);
            m.reply("⚠️ *Terjadi kesalahan saat mengunggah ke paste.gg. Mohon coba lagi nanti.*");
        }
    } catch (error) {
        console.error('Error:', error.message);
        m.reply(`⚠️ *Terjadi kesalahan saat mengunggah ke paste.gg: ${error.message}*`);
    }
};
handler.tags = ['tools'];
handler.command = ['paste'];
handler.help = ['paste nama | teks'];
module.exports = handler;