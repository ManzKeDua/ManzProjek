const cheerio = require('cheerio');
const axios = require('axios');

let handler = async (m, { conn, text, command, prefix }) => {
  if (!text) return m.reply(`Example: ${prefix + command}`);
  
  try {
    const date = await dongworld(text);
    const kanjut = await getDetail(date[0].link);
    
    conn.sendMessage(m.chat, {
      image: { url: `${kanjut.image}` },
      caption: `Hasil Pencarian Anime:

Judul: ${date[0].judul}
Rating: ${kanjut.rating}
Tags: ${kanjut.tags.join(', ')}
Link: ${date[0].link}
      `
    }, { quoted: m });
  } catch (e) {
    m.reply(e.message);
  }
};

handler.help = ['dongworld'];
handler.tags = ['internet', 'tools'];
handler.command = ['dongworld']; // Perbaiki di sini

module.exports = handler;

function dongworld(query) {
  return new Promise((resolve, reject) => {
    axios.get('https://donghuaworld.com/?s=' + query)
      .then(response => {
        const $ = cheerio.load(response.data);
        const anime = [];
        const ling = [];
        
        $('div.bsx a').each(function(a, b) {
          ling.push($(b).attr('href'));
        });

        const jud = $('div.tt');
        for (let i = 0; i < Math.min(5, ling.length); i++) { // Cek panjang ling
          const link = ling[i];
          const judul = $(jud[i]).text().trim();
          anime.push({ link, judul });
        }
        resolve(anime);
      })
      .catch(error => {
        reject(error);
      });
  });
}

async function getDetail(url) {
  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const rating = $('div.rating strong').text().trim(); // Perbaiki di sini
    const image = $('div.thumb img').attr('src');
    const tags = $('div.mindesc strong').map((i, el) => $(el).text().trim()).get(); // Perbaiki di sini

    const animeDataa = {
      image,
      rating,
      tags
    };

    return animeDataa;
  } catch (error) {
    console.error(error);
    throw new Error('Gagal mengambil detail anime'); // Tambahin error handling
  }
}