const axios = require('axios');
const cheerio = require('cheerio');

let manz = async (m, { conn, usedPrefix, text, command }) => {
    async function mediafiredll(url) {
        const res = await axios.get(`https://www-mediafire-com.translate.goog/${url.replace('https://www.mediafire.com/', '')}?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=en&_x_tr_pto=wapp`);
        const $ = cheerio.load(res.data);
        
        const fileurl = $('#downloadButton').attr('href');
        const filename = $('body > main > div.content > div.center > div > div.dl-btn-cont > div.dl-btn-labelWrap > div.promoDownloadName.notranslate > div')
            .attr('title')
            .replaceAll(' ', '')
            .replaceAll('\n', '');
        
        const date = $('body > main > div.content > div.center > div > div.dl-info > ul > li:nth-child(2) > span').text();
        const filesize = $('#downloadButton').text()
            .replace('Download', '')
            .replace('(', '')
            .replace(')', '')
            .replace('\n', '')
            .replaceAll(' ', '');

        let filetype = '';
        let rese = await axios.head(fileurl); // Menggunakan fileurl yang benar
        filetype = rese.headers['content-type'];

        return { filename, filesize, date, filetype, fileurl };
    }
   
    if (!text) return m.reply(`*Contoh*: ${usedPrefix + command} https://www.mediafire.com/xxxxxxx`);
    
    const dataJson = await mediafiredll(text);
    const { filename, filesize, date, filetype, fileurl } = dataJson;
    
    // Memastikan ukuran file tidak lebih dari 100 MB
    const sizeInMB = parseFloat(filesize.split('MB')[0]);
    if (sizeInMB >= 100) {
        return m.reply('*Ih gede banget size-nya, gak mau ah😠*');
    }

    const caption = `≡ *MEDIAFIRE*

▢ *Nama* : ${filename}
▢ *Ukuran* : ${filesize}
▢ *Tipe* : ${filetype}
▢ *Diunggah pada*: ${date}`;

    conn.sendMessage(m.chat, { document: { url: fileurl }, fileName: filename, caption: caption, mimetype: filetype }, { quoted: m });
}

manz.help = ['mf', 'mediafire'];
manz.tags = ['downloader'];
manz.command = ['mf', 'mediafire'];
module.exports = manz;