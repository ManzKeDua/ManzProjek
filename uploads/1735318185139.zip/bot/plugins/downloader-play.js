const axios = require("axios");
const yts = require("yt-search");

let handler = async (m, { conn, usedPrefix, command, text }) => {
    // Memastikan ada input teks
    if (!text) {
        throw `*• Contoh :* ${usedPrefix + command} *<query>*`;
    }

    m.reply("Tunggu sebentar...");

    let videoUrl;

    // Mencari video berdasarkan teks
    let result = await yts(text);
    videoUrl = result.videos[0]?.url; // Ambil URL video pertama
    if (!videoUrl) {
        return m.reply("Tidak ada video ditemukan dengan pencarian tersebut.");
    }

    // Encode URL untuk digunakan dalam permintaan API
    const encodedUrl = encodeURIComponent(videoUrl);
    const apiUrl = `https://Ikygantengbangetanjay-api.hf.space/yt?query=${encodedUrl}`;

    try {
        console.log(`Mengirim permintaan ke API: ${apiUrl}`); // Log URL API
        let response = await axios.get(apiUrl);
        console.log(`Respons dari API:`, response.data); // Log respons dari API

        let data = response.data;

        // Memeriksa apakah hasil valid
        if (!data.success || !data.result) {
            return m.reply("Tidak ada hasil ditemukan.");
        }

        let videoData = data.result;
        let cap = `*乂 Y T - P L A Y*\n\n` +
                  `◦ Judul : ${videoData.title}\n` +
                  `◦ Link Video : ${videoData.url}\n` +
                  `◦ Durasi : ${videoData.timestamp}\n` +
                  `◦ Penulis : ${videoData.author.name}\n` +
                  `◦ Views : ${videoData.views}\n` +
                  `◦ Diunggah : ${videoData.ago}`;

        await conn.sendMessage(m.chat, { text: cap }, { quoted: m });

        // Mengunduh audio
        const audioResponse = await axios.get(videoData.download.audio, { responseType: 'arraybuffer' });
        const audioBuffer = Buffer.from(audioResponse.data, 'binary');

        // Kirim audio sebagai pesan media
        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${videoData.title}.mp3`,
            caption: cap
        }, { quoted: m });

    } catch (error) {
        console.error("Terjadi kesalahan:", error); // Log kesalahan
        m.reply("Terjadi kesalahan saat mengunduh audio. Silakan periksa log untuk detail.");
    }
}

handler.help = ["play"].map(a => a + " *[query]*");
handler.tags = ["downloader"];
handler.command = ["play"];

module.exports = handler;