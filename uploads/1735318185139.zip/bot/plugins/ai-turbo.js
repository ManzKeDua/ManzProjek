const fetch = require('node-fetch');

let manz = async (m, { reply, text }) => {
    if (!text) return m.reply(`Where is the question? ❓`);

    // Fungsi untuk mengambil jawaban dari API
    async function avvmx(av) {
        try {
            const avis = await fetch("https://www.turboseek.io/api/getAnswer", {
                method: "POST",
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 13; Infinix HOT 40 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
                    Referer: "https://www.turboseek.io/",
                    "Content-Type": "application/json" // Menambahkan Content-Type
                },
                body: JSON.stringify({
                    question: av,
                    sources: []
                })
            });

            const data = await avis.text();
            const avv = data.split("\n").map(line => {
                try {
                    return JSON.parse(line.slice(6)).text;
                } catch (e) {
                    return "";
                }
            });

            const avosky = avv.join("").trim();
            return avosky.trim();
        } catch (error) {
            console.error("Error:", error);
            return null;
        }
    }

    // Fungsi untuk mengirim jawaban ke pengguna
    async function avoskyyy(m, question) {
        const answer = await avvmx(question);
        if (answer) {
            m.reply(answer);
        } else {
            m.reply("Terjadi kesalahan. ⚠️");
        }
    }

    // Memanggil fungsi untuk mendapatkan jawaban
    await avoskyyy(m, text);
}

manz.help = ['turbo'];
manz.tags = ['ai'];
manz.command = ['turbo'];
module.exports = manz;