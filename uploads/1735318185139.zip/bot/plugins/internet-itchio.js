const axios = require('axios')
const cheerio = require('cheerio')

let manz = async (m, { usedPrefix, text, command }) => {

    if (!text) return m.reply(`*☘️ Example :* ${usedPrefix + command} Minecraft`)

    async function scrapeItchIoSearch(query) {
        return new Promise((resolve, reject) => {
            axios.get('https://itch.io/search?q=' + query)
                .then(response => {
                    const $ = cheerio.load(response.data)
                    const games = []
                    const ling = []
                    const aut = []
                    const judul = []

                    $('div.game_title > a').each(function (a, b) {
                        ling.push($(b).attr('href'))
                        judul.push($(b).text().trim())
                    })

                    $('div.game_author > a').each(function (a, b) {
                        aut.push($(b).attr('href'))
                    })

                    const gen = $('div.game_genre')
                    const plat = $('span.web_flag')
                    const desk = $('div.game_text')
                    const rate = $('span.screenreader_only')

                    for (let i = 0; i < 10; i++) {
                        const Title = judul[i]
                        const Link = ling[i]
                        const Author = aut[i]
                        const Genre = $(gen[i]).text().trim()
                        const Platform = $(plat[i]).text().trim()
                        const Deskripsi = $(desk[i]).text().trim()
                        const Rating = $(rate[i]).text().trim()
                        games.push({
                            Title, Genre, Platform, Deskripsi, Rating, Author, Link
                        })
                    }
                    resolve(games)
                })
                .catch(error => {
                    reject(error)
                })
        })
    }

    const query = `${encodeURIComponent(text)}`
    scrapeItchIoSearch(query)
        .then(games => {
            if (games.length > 0) {
                const formattedGames = games.map(game => `
Title: ${game.Title}
Author: ${game.Author}
Genre: ${game.Genre}
Platform: ${game.Platform}
Description: ${game.Deskripsi}
Rating: ${game.Rating}
Link: ${game.Link}
                `).join('\n\n')

                m.reply(`Found games:\n${formattedGames}`)
            } else {
                m.reply('No games found.')
            }
        })
        .catch(error => {
            console.error('Error:', error)
            m.reply('An error occurred while fetching data.')
        })
}

manz.help = ['itchio-search']
manz.tags = ['tools', 'internet']
manz.command = ['itchio-search']
module.exports = manz