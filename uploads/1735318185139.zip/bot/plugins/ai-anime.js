const fetch = require('node-fetch');

const cifumo = async (m, { text, conn, args }) => {
    const prompt = text
    
    if (!prompt) {
        return m.reply("Silakan masukkan prompt untuk membuat animasi.");
    }

    try {
        const response = await fetch(`https://rest.cifumo.biz.id/api/ai/animagine?prompt=${encodeURIComponent(prompt)}`);
        if (!response.ok) throw new Error("Gagal mengambil data dari API.");
        
        const result = await response.json();

        if (result && result.data) {
            await conn.sendMessage(m.chat, { image: { url: result.data }, caption: `Hasil untuk prompt: ${prompt}\n\n© ${wm}` }, { quoted: m });
        } else {
            m.reply("Gambar tidak ditemukan dalam respons API.");
        }

    } catch (error) {
        console.error(error);
        m.reply(error.message);
    }
};

cifumo.command = ["animagine2"];
cifumo.help = ["animagine2"];
cifumo.tags = ["anime", 'ai'];
cifumo.limit = true;

module.exports = cifumo;