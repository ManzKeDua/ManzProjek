const cheerio = require('cheerio');
const axios = require('axios');

let manz = async (m, { text, reply, usedPrefix }) => {
    if (!text) {
        return m.reply("Silakan masukkan judul film yang ingin dicari.");
    }

    // Fungsi untuk mencari film
    async function avzzzz(text) {
        try {
            const response = await axios.get(`https://tv.lk21official.my/search.php?s=${text}`);
            const html = response.data;
            const $ = cheerio.load(html);
            let results = [];

            // Mengambil data film
            $('.search-item').each((index, element) => {
                const title = $(element).find('h3 a').text().trim();
                const url = 'https://tv.lk21official.my' + $(element).find('h3 a').attr('href');
                const director = $(element).find('p strong:contains("Sutradara:")').parent().text().replace("Sutradara:", "").trim();
                const cast = $(element).find('p strong:contains("Bintang:")').parent().text().replace("Bintang:", "").trim();

                results.push({
                    title,
                    url,
                    director,
                    cast
                });
            });

            return results;
        } catch (error) {
            console.error("Error fetching data:", error);
            return [];
        }
    }

    const results = await avzzzz(text);
    if (results.length === 0) {
        return m.reply("Tidak ditemukan hasil untuk pencarian: " + text);
    }

    // Menyusun pesan hasil pencarian
    let message = "Hasil pencarian untuk: *" + text + "*\n\n";
    results.forEach((result) => {
        message += `Judul: ${result.title}\n`;
        if (result.director) {
            message += `Sutradara: ${result.director}\n`;
        }
        if (result.cast) {
            message += `Bintang: ${result.cast}\n`;
        }
        message += `Url: ${result.url}\n\n`;
    });

    m.reply(message);
}

manz.help = ['lk21'];
manz.tags = ['internet'];
manz.command = ['lk21'];
module.exports = manz;