let handler = async (m, { conn, usedPrefix }) => {
    let paus = global.db.data.users[m.sender].paus 
    let kepiting = global.db.data.users[m.sender].kepiting
    let gurita = global.db.data.users[m.sender].gurita 
    let cumi = global.db.data.users[m.sender].cumi 
    let buntal = global.db.data.users[m.sender].buntal 
    let dory = global.db.data.users[m.sender].dory 
    let lele = global.db.data.users[m.sender].lele
    let nila = global.db.data.users[m.sender].nila
    let lumba = global.db.data.users[m.sender].lumba 
    let lobster = global.db.data.users[m.sender].lobster 
    let hiu = global.db.data.users[m.sender].hiu 
    let udang = global.db.data.users[m.sender].udang
    let ikan = global.db.data.users[m.sender].ikan 
    let orca = global.db.data.users[m.sender].orca 
let fishingrod = global.db.data.users[m.sender].fishingrod;
    let fishingroddurability = global.db.data.users[m.sender].fishingroddurability;

    let fishingRodNames = [
        'Tidak Punya',
        'Wood FishingRod',
        'Iron FishingRod',
        'Gold FishingRod',
        'Diamond FishingRod',
        'Netherite FishingRod',
        'Crystal FishingRod',
        'Obsidian FishingRod',
        'Netherite FishingRod',
        'Wither FishingRod',
        'Dragon FishingRod',
        'Hacker FishingRod',
        'SemiGOD FishingRod',
        'GOD FishingRod'
    ];

    let ManzUrl = 'https://files.catbox.moe/82b21i.jpg'
    let dann = `
乂 *F I S H - P O N D*

*[ 🦈 ]* - *Hiu* : _${hiu}_
*[ 🐟 ]* - *Ikan* : _${ikan}_
*[ 🐟 ]* - *Lele* : _${lele}_
*[ 🐟 ]* - *Nila* : _${nila}_
*[ 🐠 ]* - *Dory* : _${dory}_
*[ 🐳 ]* - *Orca* : _${orca}_
*[ 🐋 ]* - *Paus* : _${paus}_
*[ 🦑 ]* - *Cumi* : _${cumi}_
*[ 🐙 ]* - *Gurita* : _${gurita}_
*[ 🐡 ]* - *Buntal* : _${buntal}_
*[ 🦐 ]* - *Udang* : _${udang}_
*[ 🐬 ]* - *Lumba* : _${lumba}_
*[ 🦞 ]* - *Lobster* : _${lobster}_
*[ 🦀 ]* - *Kepiting* : _${kepiting}_

乂 *L E V E L*
*[ 🎣 ]* • *FishingRod* : *${fishingRodNames[fishingrod] || 'Unknown'}*
- *Durability* : _${fishingroddurability}_
`.trim()

    conn.sendFile(m.chat, ManzUrl, 'kolam.jpg', dann, m)
}

handler.help = ['kolam']
handler.tags = ['rpg']
handler.command = /^(kolam)$/i
handler.group = true
module.exports = handler