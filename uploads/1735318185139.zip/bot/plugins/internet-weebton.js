const axios = require('axios');
const cheerio = require('cheerio');

let manz = async (m, { reply, text }) => {

    async function webtoons(query) {
        return new Promise((resolve, reject) => {
            axios.get(`https://www.webtoons.com/id/search?keyword=${query}`)
                .then(({ data }) => {
                    const $ = cheerio.load(data);
                    const hasil = [];
                    
                    $('#content > div.card_wrap.search._searchResult > ul > li').each(function(a, b) {
                        const result = {
                            status: 200,
                            judul: $(b).find('> a > div > p.subj').text(),
                            like: $(b).find('> a > div > p.grade_area > em').text(),
                            creator: $(b).find('> a > div > p.author').text(),
                            genre: $(b).find('> a > span').text(),
                            thumbnail: $(b).find('> a > img').attr('src'),
                            url: $(b).find('> a').attr('href')
                        };
                        hasil.push(result);
                    });
                    
                    resolve(hasil);
                })
                .catch(reject);
        });
    }

    if (!text) return m.reply('Masukan judul yang ingin dicari!!\nContoh: .webtoon lookism');
    
    let results = await webtoons(text);
    if (results.length > 0) {
        let message = `Hasil dari pencarian ${text} :\n\n`;
        results.forEach((result) => {
            message += `Title : ${result.judul}\nLike : ${result.like}\nCreator : ${result.creator}\nGenre : ${result.genre}\nLink Baca : ${result.url}\n\n`;
        });
        m.reply(message);
    } else {
        m.reply('Tidak Ada Hasil.');
    }
}

manz.help = ['webtoons', 'webton'];
manz.tags = ['internet'];
manz.command = ['webtoons', 'webtoon'];
module.exports = manz;