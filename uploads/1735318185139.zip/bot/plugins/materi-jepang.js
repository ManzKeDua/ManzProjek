// ( FITUR MATERI JEPANG )
//Yuki Ainz
//https://whatsapp.com/channel/0029Vai8a3K4CrfZmzVnGI3m

const handler = async (m, { args, text, conn, usedPrefix, command }) => {
	if (!text)
		throw `Penggunaan:\n/${command} > nomor <\n\nContoh:\n/${command} 1

1. Ungkapan Umum
2. Huruf Hiragana Dasar
3. Huruf Hiragana *Tanda Tenten ('') dan Maru (°)*
4. Huruf Hiragana *Tanda Tsu Kecil (っ)*
5. Huruf Hiragana *Huruf Ya, Yu, dan Yo kecil (ゃゅょ)*
6. Huruf Katakana Dasar
7. Huruf Katakana *_Tanda tenten ('') dan maru (°)_*
8. Huruf Katakana *_Tanda tsu kecil (ッ) dan garis (ー)_*
9. Huruf Katakana *Huruf Gabungan*
10. Kosakata Umum
11. Kanji
12. Angka
13. Materi Tentang Kanji
14. Kata Ganti
15. Kosakata *_Alam_*
16. Kosakata *_Alat Tulis_*
17. Kalimat
18. Partikel *_Kata Tugas_*
19. Kata *_Desu_*
20. Kata Tunjuk
21. Kosakata *_Orang_*
22. Kosakata *_Nama Negara_*
23. Tata Bahasa *Kata Kerja*
24. Tata Bahasa *Bentuk -MASU*
25. Tata Bahasa *Bentuk -TA (Lampau)*
26. Tata Bahasa *Bentuk -NAI (Negatif)*
27. Kosakata *_Angka_*
28. Tata Bahasa *Klausa Relatif*
29. Tata Bahasa *Partikel _Wa_*
30. Tata Bahasa *_Kalimat Pengandaian dengan Partikel とto_*
31. Tata Bahasa *_$Kalimat Pengandaian dengan Partikel ならNARA_*
32. Tata Bahasa *_Bentuk Kata Kerja -BA_*
33. Tata Bahasa *_Bentuk Kata Kerja -TARA_*
34. Kosakata *_Kata Tanya_*
35. Kosakata *_Keterangan Waktu_*
36. Kata-kata *_Ungkapan Memberi Semangat_*
37. Kanji *_Kanji Pendidikan_*
38. Kosakata *_Hewan_*
39. Kosakata *_Buah Dan Sayur_*
40. Tata Bahasa *_Ni Yoru_*
41. Tata Bahasa *_Ringkasan Partikel_*
42. Kosakata *_Hobi_*
43. Tata Bahasa *_~toosu_*
44. Tata Bahasa *_Mama_*
45. Tata Bahasa *_Partikel ga (Penunjuk Subjek_*
46. Tata bahasa *_Pola Kalimat (o tooshite/o tsuujite)_*
47. Tata Bahasa *_Keigo, Bahasa Hormat_*
48. Tata Bahasa *_~oki ni_*
49. Tata Bahasa *_goto ni_*
50. Tata Bahasa *_Partikel no, Penunjuk Kepemilikan_*
51. Tata bahasa *Kata Kerja Pasif*
52. Tata Bahasa *Tabi ni*
53. Percakapan *Bahasa Singkat*
54. Perbadaan Kata *Benkyou Suru, Manabu, Narau*
55. Tata Bahasa *Kata Sifat*
56. Tata Bahasa *te iku, te kuru*
57. Tata Bahasa *Partikel o/wo, Penanda Objek*
58. Tata Bahasa *Pola Kalimat Ue De*
59. Kosa Kata *Kata Sifat Na Berakhiran I*
60. Tata Bahasa *Partikel Ni, Penanda Objek/Tujuan*
61. Kosakata *Angka Besar*
62. Kosakata *Kata Kerja*
63. Tata Bahasa *Partikel e*
64. Tata Bahasa *Partikel to, Kata Pendamping*
65. Tata Bahasa *Partikel de*
66. Tata Bahasa *Bentuk te/de*
67. Kosakata *Tempat Makan*
68. Tata Bahasa *Partikel kara*
69. Tata Bahasa *Partikel yori*
70. Tata Bahasa *Partikel to, Penghubung Kata benda (dan)*
71. Tata Bahasa *Pola Kalimat wa Mochiron*
72. Tata Bahasa *Partikel yo*
73. Tata Bahasa *Transif dan Intransif*
74. Tata Bahsa *Partikel ka*
75. Tata Bahasa *Kata Nante*
76. Tata Bahasa *Pola Kalimat -te aru*
77. Kosakata *Benda-Benda Sekitar*
78. Kanji *Pengenalan*
79. Ungkapan-Ungkapan Umum
80. Kosakata *Mencuci*
81. Kosakata *Fenomena Alam*
82. Kosakata *Rasa*
83. Kosakata *Bumbu*
84. Kosakata *Penyakit Pada Anak*
85. Kosakata *Hari Nasional Indonesia*
86. Kosakata *Jepang*
87. Ungkapan *Meminta Maaf*
88. Ungkapan *Tobu tori o otosu*
89. Tata Bahasa *Menyusun Kalimat*
90. Tata Bahasa *Menyusun Kalimat 2*
91. Tata Bahasa *Menyusun Kalimat 3*
92. Tata Bahasa *Menyusun Kalimat 4*
93. Tata Bahasa *Menyusun Kalimat 5*
94. Kata Kata Sering Digunakan
95. Pengenalan Bahasa Jepang
96. Huruf Hiragana Dasar
97. Huruf Hiragana *(Tanda Tenten dan Maru)*
98. Tanda Tsu Kecil (っ) atau Sokuon
99. Huruf Ya, Yu, dan Yo kecil (ゃ、ゅ、ょ) atau Youon
100. Bunyi Panjang atau Chouon`;
	if (text === "1") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *UNGKAPAN UMUM* ⭐
======================

⚽ *はい 。*
       _hai_
       Ya.

🏀 *いいえ。*
        _iie_
       Tidak.

🏈 *おねがいします。*
       _onegai shimasu_
》 Terjemahan langsung: "Saya mohon."
》 Makna:
     • Tolong ya...
     • Mohon (bantuannya, kerjasamanya, dll...)

⚾ *こんにちは。*
       _konnichiwa_
》 Sebagai sapaan umum.
》 Makna:
     • Halo.
     • Selamat siang.

🥎 *おはようございます。*
       _ohayou gozaimasu_
       Selamat pagi.

🏓 *こんばんは。*
       _konbanwa_
       Selamat malam. (Untuk menyapa.)

🏸 *おやすみなさい。*
       _oyasumi nasai_
       Selamat malam. (Di akhir percakapan.)
》 *おやすみ。*
     _oyasumi_ (informal)

🎾 *はじめまして。*
       _hajimemashite_
》 Diucapkan ketika pertama bertemu, sebelum memperkenalkan diri.
》 Makna:
     • Salam kenal.

🪀 *よろしくおねがいします。*
       _yoroshiku onegai shimasu_
》 Biasanya diucapkan setelah perkenalan.
》 Makna:
     • Salam kenal.
     • Mohon kerjasamanya.

🏐 *もしもし。*
       _moshi moshi_
       Halo? (Ketika menelpon)

🏉 *すみません。*
       _sumimasen_
       • Permisi. (Ketika bertanya.)
       • Maaf. (Formal)

🥏 *ありがとうございます。*
       _arigatou gozaimasu_
       Terima kasih banyak.
》 *ありがとう。*
      _arigatou_ (informal)
      • Terima kasih.
      • Makasih.

🎱 *ごめんなさい。*
       _gomen nasai_
       • Mohon maaf.
       • Maafkan aku.
》 *ごめん。*
     _gomen_ (informal)
_______________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "2") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *HURUF HIRAGANA DASAR* ⭐
=====================

Huruf hiragana yaitu salah satu jenis huruf Jepang.

Ia dipakai biasanya untuk menulis kata-kata yang berasal dari bahasa Jepang sendiri (yang berasal dari bahasa asing umumnya pakai huruf Katakana).

Untuk pemula yang belajar bahasa Jepang biasanya masih banyak menggunakan Hiragana, dan semakin tinggi levelnya, akan semakin banyak menggunakan kanji.

Huruf-huruf dasar hiragana yang umum yaitu sebagai berikut:

あ   い   う   え   お
a      i     u     e     o

か   き   く   け   こ
ka   ki    ku   ke   ko

さ   し   す   せ   そ
sa  shi   su   se   so

た   ち   つ   て   と
ta   chi   tsu  te    to

な   に   ぬ   ね   の
na   ni    nu   ne   no

は   ひ   ふ   へ   ほ
ha   hi   fu   he   ho

ま   み   む   め   も
ma  mi   mu  me  mo

や          ゆ           よ
ya           yu           yo

ら   り   る   れ   ろ
ra    ri     ru    re    ro

わ                         を
wa                         wo
               ん
                n

Penulisannya cukup mudah karena dituliskan satu per satu saja.

Contoh Kata:
● ねこ = ne + ko
= neko (kucing)

● あたま = a + ta + ma
= atama (kepala)
_______________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "3") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Huruf Hiragana* ⭐
Tanda Tenten (``) dan Maru (°)
_______________________
Kedua tanda ini digunakan untuk mengubah sedikit bunyi dari beberapa huruf:

*✅ Tanda Tenten/Dakuten (``)*
Untuk mengubah baris KA, SA, TA, dan HA
Menjadi GA, ZA, DA, BA

か き く け こ --> が ぎ ぐ げ ご
ka ki ku ke ko --> ga gi gu ge go

さ し す せ そ --> ざ じ ず ぜ ぞ
sa shi su se so --> za ji zu ze zo

た ち つ て と --> だ ぢ づ で ど
ta chi tsu te to --> da ji dzu de do

は ひ ふ へ ほ --> ば び ぶ べ ぼ
ha hi fu he ho --> ba bi bu be bo

*✅ Tanda Maru/Handakuten (°)*
Untuk mengubah baris HA menjadi PA

は ひ ふ へ ほ --> ぱ ぴぷぺ ぽ 
ha hi fu he ho --> pa pi pu pe po
_______________________
🇯🇵 Belajar Nihon-go
24-09-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "4") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Huruf Hiragana* ⭐
Tanda Tsu Kecil (っ)

_____________________________
Tanda ini berbeda dari huruf TSU yang biasa (つ). Tanda ini disebut juga dengan tanda *sokuon*. Kegunaan dari tanda ini yaitu menggandakan (mendobelkan) bunyi huruf mati setelah tanda itu.
Contoh:

             か 👉 *っか*
             ka           kka

             ぽ  👉 *っぽ*
             po          *ppo*

             ち  👉 *っち*
             chi         *cchi*

             つ  👉 *っつ*
             tsu          *ttsu*

Contoh Kata:
• がっこう gakkou (sekolah)
• さっき     sakki (tadi)
_____________________________
🇯🇵 Belajar Nihon-go
10-10-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "5") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Huruf Hiragana* ⭐
Huruf Ya, Yu, dan Yo kecil (ゃゅょ)
_____________________________

Huruf kecil ini digabung dengan huruf biasa (yang bervokal I) untuk menggabungkan bunyinya. *Contoh:*
き ki --> きゃ kya
                きゅ kyu
                きょ kyo

Perhatikan bedanya dengan huruf ya, yu dan yo yang biasa:
   きや      きゃ
    kiya       kya (bergabung)

💎 *Daftar lengkap:*
きゃ  きゅ  きょ 
 kya    kyu   kyo

ぎゃ  ぎゅ  ぎょ
gya   gyu    gyo

しゃ  しゅ  しょ
 sha   shu   sho

じゃ  じゅ  じょ
ja       ju       jo

ちゃ  ちゅ  ちょ
cha    chu   cho 

ぢゃ  ぢゅ  ぢょ
ja       ju      jo

にゃ  にゅ  にょ 
nya    nyu   nyo

ひゃ  ひゅ  ひょ
 hya   hyu   hyo

びゃ  びゅ  びょ
bya   byu    byo

ぴゃ  ぴゅ  ぴょ
pya   pyu   pyo

みゃ  みゅ  みょ 
mya  myu  myo

りゃ  りゅ  りょ
 rya    ryu    ryo

Perhatikan bahwa tanda tenten dan maru juga masih berlaku untuk huruf yang dapat diberi tanda itu.
_____________________________
🇯🇵 Belajar Nihon-go
12-10-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "6") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Huruf Katakana Dasar* ⭐
_____________________________

Huruf Katakana umumnya dipakai untuk menuliskan kata-kata yang merupakan pinjaman dari bahasa asing. Atau nama-nama yang bukan asli Jepang.

Daftar huruf-huruf dasarnya sama jumlahnya dengan hiragana dan sama bunyinya, tetapi bentuknya berbeda:

ア   イ   ウ   エ   オ
a      i       u    e     o

カ   キ   ク   ケ   コ
ka    ki     ku   ke   ko

サ   シ   ス   セ   ソ
sa   shi    su   se    so

タ   チ   ツ   テ   ト
ta    chi   tsu  te    to

ナ   ニ   ヌ   ネ   ノ
na   ni     nu   ne   no

ハ   ヒ   フ   ヘ   ホ
ha   hi     fu    he   ho

マ   ミ   ム   メ   モ
ma  mi   mu  me  mo

ヤ          ユ           ヨ
ya           yu           yo

ラ   リ   ル   レ   ロ
ra    ri     ru    re    ro

ワ                         ヲ
wa                         wo
               ン
                n

Contoh penggunaannya yaitu kata serapan seperti テレビ terebi (TV), yaitu serapan dari bahasa Inggris "television".

_____________________________
🇯🇵 Belajar Nihon-go
29-10-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "7") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Huruf Katakana* ⭐
_Tanda tenten (``) dan maru (°)_
_____________________________
🚗 Sama dengan hiragana, huruf katakana juga mempunyai tanda ini dan penggunaannya cukup sama:

カキクケコ   --> ガギグゲゴ
ka ki ku ke ko --> ga gi gu ge go

サシスセソ   --> ザジズゼゾ
sa shi su se so --> za ji zu ze zo

タチツテト    --> ダヂヅデド
ta chi tsu te to --> da ji dzu de do

ハヒフヘホ    --> バビブベボ
ha hi fu he ho --> ba bi bu be bo
                       --> パピプペポ
                       --> pa pi pu pe po
_____________________________
🇯🇵 Belajar Nihon-go
6-11-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "8") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Huruf Katakana* ⭐
_Tanda tsu kecil (ッ) dan garis (ー)_
_______________________
🎈 Seperti huruf hiragana, tanda ッ tsu kecil ini (atau disebut dengan tanda *sokuon*) gunanya untuk menggandakan huruf mati setelahnya, dan berbeda dengan huruf tsu biasa (ツ). *Contoh:*
☆ カ    -->    ッカ 
     ka                 kka
☆ ピ    -->     ッピ
      pi                 ppi
☆ チ    -->      ッチ
     chi                cchi

🏮 Sedangkan tanda garis ー atau disebut dengan *chouon* gunanya untuk memanjangkan huruf hidup sebelumnya. *Contoh:*
☆ カ   -->    カー
     ka              kaa
☆ ピ   -->    ピー
      pi               pii
☆ チ   -->    チー
    chi               chii

*Catatan:* Dalam tulisan menurun, tanda garis dituliskan menurun juga (tegak  | )
_______________________
🇯🇵 Belajar Nihon-go
16-10-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "9") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Huruf Katakana* ⭐
_Huruf Gabungan_
_______________________
Huruf katakana juga memiliki huruf gabungan seperti hiragana menggunakan huruf kecil, tetapi katakana mempunyai lebih banyak gabungan daripada hiragana.

Huruf kecil dalam katakana:
• ャュョ (ya, yu, yo)
• ァィゥェォ (a, i, u, e, o)

⚽ Pada dasarnya kegunaannya yaitu untuk mengubah bunyi vokal (huruf hidup) dari huruf sebelumnya.

キャ  キュ  キェ  キョ
 kya     kyu     kye     kyo
ギャ  ギュ  ギェ  ギョ
 gya    gyu     gye    gyo
シャ  シュ  シェ  ショ
 sha     shu     she    sho
ジャ  ジュ  ジェ  ジョ
  ja        ju        je       jo
チャ  チュ  チェ  チョ
 cha    chu    che    cho
ツァ  ツィ  ツェ  ツォ
  tsa     tsi       tse     tso
ティ  トゥ  ディ  ドゥ
   ti        tu       di       du
ニャ  ニュ  ニェ  ニョ
 nya    nyu     nye     nyo
ヒャ  ヒュ  ヒェ  ヒョ
 hya     hyu    hye     hyo
ファ  フィ  フェ  フォ
  fa        fi         fe        fo
ビャ  ビュ  ビェ  ビョ
 bya    byu     bye     byo
ピャ  ピュ  ピェ  ピョ
 pya     pyu    pye    pyo
ミャ  ミュ  ミェ  ミョ
 mya    myu   mye   myo
リャ  リュ  リェ  リョ
 rya      ryu     rye      ryo
       ウィ        ウェ
         wi             we
ヴァ  ヴィ  ヴ  ヴェ  ヴォ
 va       vi       vu     ve      vo
_______________________
🇯🇵 Belajar Nihon-go
27-11-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "10") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Kosakata Umum* ⭐
_______________________
1) 行く _iku_         = pergi
2) 見る _miru_      = melihat
3) 多い _ooi_         = banyak
4) 家     _ie_           = rumah
5) これ _kore_      = ini
6) それ _sore_      = itu
7) 私     _watashi_ = saya
8) 仕事 _shigoto_ = pekerjaan
9) いつ _itsu_        = kapan
10) する _suru_    = melakukan
_______________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "11") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KANJI* ⭐
人 木 水 火 本 山 空 上 
_______________________
🚙 Kanji adalah salah satu jenis aksara atau huruf yang digunakan di dalam bahasa Jepang. Diambil dari tulisan Cina.

Fungsinya untuk memperlancar bacaan hanya dengan melihat bentuk kanji tersebut, karena jika tanpa kanji banyak kata-kata yang mirip dan lebih sulit dibedakan.

🚔 Cara membaca kanji tergantung di dalam kata apa kanji itu berada, jadi umumnya satu kanji lebih dari satu bacaan. *Contoh:*

人間 = _ningen_ [manusia]
日本人 = _nihonjin_ [orang Jepang]

Ini menunjukkan bahwa kanji 人 setidaknya dapat dibaca *nin* maupun *jin*, tergantung di dalam kata apa ia berada.

Sebagai permulaan, pelajarilah bentuk kanji angka berikut ini.

1) 一 ichi         6) 六 roku
2) 二 ni            7) 七 nana
3) 三 san         8) 八 hachi
4) 四 yon         9) 九 kyuu
5) 五 go        10) 十 juu
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "12") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *ANGKA* ⭐
_1-10_
_______________________
🍋 Penyebutan angka dalam bahasa Jepang bergantung pada penggunaannya.

🍉 Ada 2 jenis penyebutannya:
• Penyebutan bahasa Jepang
• Penyebutan bahasa Cina

Penyebutan angka dengan bahasa Jepang asli, umumnya dipakai untuk menghitung jumlah benda dan tanggal 1-10 saja, selain itu lebih sering menggunakan penyebutan dari bahasa Cina.

Berikut ini angka-angkanya untuk 1 sampai 10:

*Angka/       Penyebutan*
*Kanji       Jepang     Cina*
1/一       hitotsu      ichi
2/二       futatsu      ni
3/三       mittsu       san
4/四       yottsu       shi/yon
5/五       itsutsu      go
6/六       muttsu     roku
7/七      nanatsu   shichi/nana
8/八       yattsu       hachi
9/九    kokonotsu   kyuu/ku
10/十         too        juu
_______________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "13") {
		conn.sendMessage(
			m.chat,
			{
				text: `*⭐ Materi tentang Kanji ⭐*

📋 *Daftar Isi:*
A) Apa itu Kanji? 
B) Mengapa menggunakan Kanji?
C) Cara membaca Kanji
D) Cara mempelajari Kanji

🈷 A) *APA ITU KANJI?*
☆ Kanji [漢字] adalah huruf-huruf Jepang yang diadaptasi dari huruf Cina _hanzi_. Kanji sering dijumpai dalam tulisan baik formal maupun informal. Kanji digunakan sebagai pengganti hiragana (sebagian).

🅰️ *Contoh tulisan dengan hiragana saja:*
きょうわたしはははとちちといっしょにうみにいきます。

🅱️ *Tulisan yang sama menggunakan kanji:*
今日私は母と父と一緒に海に行きます。
=======================

💡 B) *MENGAPA MENGGUNAKAN KANJI?*
☆ Belajar kanji memang sulit bagi pemula, tetapi jika kita mulai memahami bahasa Jepang, maka kita akan tahu pentingnya kanji itu.

*1⃣ Kanji membuat kita membaca lebih cepat.*
Jika kita lihat contoh di atas, pada kalimat 🅰️ kita masih harus mengeja satu persatu hiragana yang ada dan kita harus berpikir untuk membedakan yang mana huruf pertama suatu kata dan yang mana huruf terakhirnya, bahkan kita harus membedakan mana partikel (kata tugas dan penghubung) dan mana yang bukan partikel. Sedangkan pada kalimat 🅱️ hanya dengan melihat bentuknya kita bisa membedakan kata-kata itu.

*2⃣ Kanji membuat kita lebih mudah memahami isi kalimat.*
Bahasa Jepang adalah bahasa yang *homonim*, artinya banyak kata-kata yang sama pengucapannya, bahasa Jepang hanya mempunyai sedikit suku kata karena huruf hiragana tidak berubah cara bacanya jika digabung dengan huruf lain. Jadi karena kakunya bahasa Jepang ini maka memahami makna tulisan dengan full hiragana akan sulit.
*Contoh kata-kata yang sama bunyinya, dengan kanji kita bisa membedakan maknanya:*
• 恋 koi (cinta)
• 濃い koi (gelap warna)
• 故意 koi (niat)
• 鯉 koi (nama ikan)
• 来い koi (datanglah)
========================

📖 C) *CARA MEMBACA KANJI*
☆ Biasanya satu kanji mempunyai lebih dari satu cara baca, itu karena memahami maknanya lebih penting daripada tulisannya. Satu kanji bisa dipakai untuk beberapa kata yang masih terkait maknanya. Misalnya kanji 上 (atas).
*Contohnya:*
• *上* ue = atas
• *上げる* ageru = menaikkan
• *上手* jouzu = mahir (keterampilan yang tinggi)
• *上る* noboru = mendaki
• *上着* uwagi = pakaian atas

Dari kosakata tersebut kita bisa simpulkan bahwa kanji 上 (yang berarti "atas") bisa dibaca _ue, a, jou, nobo, uwa_ tergantung di dalam kata apa kanji itu. Tetapi jangan khawatir karena kanji umumnya punya dua atau tiga cara baca saja.

💬 *Kanji ada 2 jenis bacaan:*
1. *Bacaan Kunyomi* : yaitu bacaan dari bahasa Jepangnya.
2  *Bacaan Onyomi* : yaitu bacaan dari bahasa Mandarinnya.

Misalnya kanji 月 (bulan)
• *Kunyomi* : tsuki
• *Onyomi* : getsu, gatsu

Kanji 日 (hari / matahari)
• *Kunyomi:* hi
• *Onyomi:* nichi, jitsu

Kanji 今 (sekarang)
• *Kunyomi:* ima
• *Onyomi* : kon, kin

🤔 *Kapankah kanji dibaca dengan cara kunyomi atau onyomi?*
☆ Biasanya jika kosakata yang terdiri dari 1 kanji saja dibaca menggunakan bacaan *kunyomi*-nya.
• Misalnya :
   月 tsuki   (bulan)
   日 hi        (hari)
   今 ima     (sekarang)

☆ Dan jika kosakatanya terdiri dari gabungan kanji maka dibaca dengan cara *onyomi*-nya.
• Misalnya :
   来月 rai-getsu  (bulan depan)
   四月 shi-gatsu (April)
   休日 kyuu-jitsu (hari libur)
   今月 kon-getsu (bulan ini)

☆ Ada beberapa kanji yang tidak menggunakan bacaan kunyomi maupun onyomi, dan sudah menjadi satu makna.
• Misalnya : *今日 kyou (hari ini)*
   Terdiri dari kanji 今 (sekarang) dan 日 (hari). Tetapi jika diperhatikan tidak dibaca secara kunyomi maupun onyomi. Untungnya kanji yang seperti ini tidak banyak jumlahnya.

☆ Untuk kata kerja dan kata sifat -i semuanya dibaca secara *kunyomi*:
• 食べる : *ta*-beru (makan)
• 寒い : *samu*-i (dingin)
• 新しい : *atara*-shii (baru)
• 走る : *hashi*-ru (berlari)
====================

📝 D) *CARA MEMPELAJARI KANJI*
☆ Beberapa orang yang baru memulai mempelajari biasanya kebingungan karena terlalu memikirkan banyaknya kanji dan banyaknya cara baca kanji itu. Namun di situlah yang memperlambat seseorang belajar kanji, mempelajari kunyomi dan onyomi saja tidak akan mempercepat mempelajari kanji.

☆ Cara mempelajari kanji yang benar (menurut penulis) adalah yaitu dengan mempelajari kosakatanya langsung dan juga makna masing-masing kanji, tidak perlu memikirkan kunyomi maupun onyomi. 

Sederhananya, kanji adalah simbol, setiap simbol punya makna, maka pelajari makna tiap kanji. Caranya bisa dengan membayangkan gambar yang terbentuk dari kanji itu. Misalnya
山 = gunung. Kita bisa membayangkan segitiga yang terbentuk di bagian atasnya (berbentuk gunung). Jika sulit membayangkan, maka belajarlah lewat *flashcard* (kartu-kartu belajar) bisa berupa flashcard asli (dibuat sendiri atau dibeli) atau flashcard digital (lewat aplikasi-aplikasi belajar kanji).

Selain itu, kata adalah suatu bagian bahasa, dan kata itu menggunakan simbol-simbol yaitu kanji. Maka pelajari kata-kata itu dan lihatlah simbol apa yang digunakan untuk kata itu.
Misalnya: kata 音楽 (ongaku) yang berarti "musik"
Tersusun dari kanji 音 (bunyi) dan kanji 楽 (nyaman). Maka kita bisa kaitkan kedua kanji ini sehingga membentuk kata "musik". Misalnya

音 bunyi yang membuat 楽 nyaman 
*= 音楽 musik (ongaku)*

Sekali lagi untuk melatih mengingat kosakata juga bisa gunakan flashcard.
_______________________________
3 Mar 2020 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "14") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KATA GANTI* ⭐
_______________________

私 (わたし) - *watashi*
= saya

貴方/貴女 (あなた) - *anata*
= kamu

彼 (かれ) - *kare*
= dia (laki-laki)

彼女 (かのじょ) - *kanojo*
= dia (perempuan)

私達 (わたしたち) - *watashitachi*
= kami/kita

あなた達 - *anatatachi*
= kalian

彼ら (かれら) - *karera*
= mereka

*Catatan*: Orang Jepang lebih sering mengucapkan nama lawan bicaranya di akhiri dengan さん (-san) ketimbang menggunakan あなた (anata) karena dengan menyebut nama maka akan terdengar sopan. (Misalnya: Yamada san)
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "15") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KOSAKATA* ⭐
_Alam_
_______________________
*hana* _bunga_ 🌺 花
*ki* _pohon_ 🌳 木
*hayashi* _hutan kecil_ 🌳 林
*mori* _hutan besar_ 🌳 森
*eda* _ranting_ 枝
*kusa* _rumput_ 草
*ha* _daun_ 🍃 葉
*mizu* _air_ 💧 水
*hi* _api_ 🔥 火
*kaze* _angin_ 🌬️ 風
*koori* _es_ ❄️ 氷
*tsuchi* _tanah_ 🌎 土
*sora* _langit_ 🏞️ 空
*yama* _gunung_ 🏔️ 山
*kawa* _sungai_ 🌊 川
*kumo* _awan_ ☁️ 雲
*ame* _hujan_ 🌧️ 雨
*yuki* _salju_ 🌨️ 雪
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "16") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KOSAKATA* ⭐
_Alat Tulis_
_______________________
*enpitsu* ✏️ pensil 鉛筆
*pen/boorupen* 🖊️ pulpen ペン•ボールペン
*keshigomu* penghapus 消ゴム
*tsukue* meja tulis 机
*e* 🖼️ gambar 絵
*nooto* 📒 buku catatan ノート
*kami* 📄 kertas 紙
*hocchikisu* stapler ホッチキス
*hasami* ✂️ gunting 鋏
*enpitsukezuri* rautan pensil 鉛筆削り
*hon* 📚 buku 本
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "17") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KALIMAT* ⭐
_______________________
🚗 Kalimat dalam bahasa Jepang terdiri dari dua bagian besar:
 Topik + Predikat

🚥 *Topik* yaitu apa yang sedang dibicarakan, bisa orang, hewan, benda, tempat, waktu dll. Topik biasanya diikuti dengan partikel は wa (tulisannya menggunakan huruf HA, tetapi dibaca WA jika sebagai partikel). *Contoh:*
• これは ... (kore wa ...)
   _Ini ..._
• 私は ...     (watashi wa ...)
   _Saya ..._
• この本は (kono hon wa ...)
   _Buku ini ..._

🚥 *Predikat* yaitu yang menjadi isi utama kalimat, bisa berupa kata kerja, kata benda maupun kata sifat. Yang berhubungan dengan topik tadi. *Contoh:*

*Topik                Predikat*
*==================*
私は                元気。
_watashi wa     genki_
Saya                sehat

それは            いい。
_sore wa           ii_
Itu                     bagus.

これは           本。
_kore wa           hon_
Ini                    buku.

お母さんは  料理した。
_okaasan wa ryouri shita_
Ibu                  memasak.

🚙 *Topik* tidak wajib disebutkan jika sudah jelas apa yang dibicarakan. Jadi kita tidak perlu mengulangi lagi menyebut topik.
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "18") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *PARTIKEL* ⭐
_Kata Tugas_
_______________________
💽 *Partikel* adalah kata-kata pendek yang menandakan posisi atau peran kata di dalam kalimat.
*Contoh:*
• は wa : (penanda topik kalimat)
• で de : di, dengan
• に ni : di, ke, pada
• を o : (penanda objek kalimat)
• が ga : (penanda subjek)
• へ e : ke, ke arah

💾 Partikel diletakkan di belakang kata yang ditunjuk.
☆ これは       kore wa
☆ 学校に       gakkou ni
☆ 家で           ie de
☆ テレビを   terebi o

*Contoh dalam Kalimat:*
☆ 私は     学校へ    行く。
     watashi wa  gakkou e  iku
= _Saya pergi ke sekolah._
• watashi = saya
• gakkou = sekolah
• iku = pergi

💿 Ada banyak jumlah partikel dalam bahasa Jepang, contoh di atas merupakan partikel yang umum dijumpai. Dan satu partikel bisa saja punya fungsi yang berbeda-beda.
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "19") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KATA です [DESU]* ⭐
_______________________
🌎 Kata *desu* dapat digunakan untuk membuat kalimat lebih sopan, jika predikatnya berupa kata benda atau kata sifat.

🌑 Bahasa yang sopan digunakan kepada orang yang bukan teman dekat atau keluarga.

🌕 *Contoh:*
☆ 私は学生。
     _watashi wa gakusei_
     Saya seorang siswa.

=> 私は学生 *です。*
      _watashi wa gakusei *desu*_
      Saya seorang siswa.
      (lebih sopan)

☆ ここは寒い。
      _koko wa samui_
      Di sini dingin.

=> ここは寒い *です。*
      _koko wa samui *desu*_
      Di sini dingin.
      (Lebih sopan)
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "20") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KATA TUNJUK* ⭐
_______________________

👉 *これ _kore_* = ini
Untuk menunjuk ke benda yang berada di dekat kita.

👉 *それ _sore_* = itu 
Untuk menunjuk ke benda yang berada di dekat lawan bicara kita.

👉 *あれ _are_* = itu (di sana)
Untuk menunjuk ke benda yang jauh dari kita dan juga lawan bicara kita.

*Contoh:*
☆ *これは本です。*
     *kore wa hon desu*
     Ini adalah buku.

☆ *それは鉛筆です。*
     *sore wa enpitsu desu*
     Itu adalah pensil.

☆ *あれは猫です。*
     *are wa neko desu*
     Itu (di sana) adalah kucing.
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "21") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KOSAKATA* ⭐
_Orang_
_______________________
*hito* 👤 orang 人
*kodomo* 👦🏻👧🏻 anak(-anak) 子供
*akachan* 👶🏻 bayi 赤ちゃん
*otoko no hito* 👨🏻 pria 男の人
*onna no hito* 👩🏻 wanita 女の人 
*otoko no ko* 👦🏻 anak laki-laki 男の子
*onna no ko* 👧🏻 anak perempuan 女の子
*otona* 🕺🏻 orang dewasa
*tomodachi* 👥 teman 友達
*kazoku* 👨‍👩‍👧‍👦 keluarga 家族
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "22") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KOSAKATA* ⭐
_Nama Negara_
_______________________
🇺🇸 *amerika* Amerika アメリカ
🇦🇷 *aruzenchin* Argentina アルゼンチン
🇻🇳 *betonamu* Vietnam ベトナム
🇧🇷 *burajiru* Brazil ブラジル
🇨🇱 *chiri* Chile チリ
🇨🇳 *chuugoku* Cina 中国
🇩🇰 *denmaaku* Denmark デンマーク
🇩🇪 *doitsu* Jerman ドイツ
🇪🇬 *ejiputo* Mesir エジプト
🇪🇨 *ekuadoru* Ekuador エクアドル
🇵🇭 *firipin* Filipina フィリピン
🇫🇷 *furansu* Prancis フランス
🇬🇭 *gaana* Ghana ガーナ
🇬🇷 *girisha* Yunani ギリシャ
🇭🇹 *haichi* Haiti ハイチ
🇬🇧 *igirisu* Inggris イギリス
🇮🇩 *indoneshia* Indonesia インドネシア
🇯🇲 *jamaika* Jamaika ジャマイカ
🇿🇼 *jinbabue* Zimbabwe ジンバブエ
🇨🇦 *kanada* Kanada カナダ
🇰🇷 *kankoku* Korea 韓国
🇲🇾 *mareeshia* Malaysia マレーシア
🇲🇽 *mekishiko* Meksiko メキシコ
🇳🇬 *naijeria* Nigeria ナイジェリア
🇯🇵 *nihon* Jepang 日本
🇦🇺 *oosutoraria* Australia オーストラリア
🇳🇱 *oranda* Belanda オランダ
🇵🇰 *pakisutan* Pakistan パキスタン
🇵🇹 *porutogaru* Portugal ポルトガル
🇱🇦 *raosu* Laos ラオス
🇷🇺 *roshia* Rusia ロシア
🇸🇬 *shingapooru* Singapura シンガポール
🇪🇸 *supein* Spanyol スペイン
🇹🇭 *tai* Thailand タイ
🇹🇷 *toruko* Turki トルコ
🇺🇦 *ukuraina* Ukraina ウクライナ
🇺🇾 *uruguai* Uruguay ウルグアイ
🏴󠁧󠁢󠁷󠁬󠁳󠁿 *weeruzu* Wales ウェールズ
🇯🇴 *yorudan* Yordania ヨルダン 
🇿🇲 *zanbia* Zambia ザンビア
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "23") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 文法 • TATA BAHASA ⭐
☆ 動詞 ☆
◇ Kata Kerja ◇

《🔍 Pengertian 》-------------------
Kata kerja yaitu kata yang menunjukkan kegiatan atau kejadian apa yang terjadi. Contoh:
• 行く     _iku_       = pergi
• 見る     _miru_    = melihat
• 食べる _taberu_ = makan
• 寝る     _neru_     = tidur

Semua kata kerja berarkhiran bunyi U, dalam bentuk dasarnya. Tetapi kata kerja bisa berubah bentuknya untuk memberi makna baru. Misalnya:

• 食べる _taberu_ = makan
• 食べた _tabeta_ = sudah makan
• 食べない _tabenai_ = tidak makan
• 食べられる _taberareru_ = bisa makan
• 食べよう _tabeyou_ = ayo makan
• 食べろ _tabero_ = makan! 
Dll...

Perubahan ini tidak sama untuk semua kata kerja. Maka, kata kerja dibagi menjadi 3 kelompok:

1️⃣ Kata Kerja う (U)
Yaitu kata kerja yang berakhiran bunyi akhir U secara umum. 
Contoh:
• 買う _kau_   = membeli
• 呼ぶ _yobu_ = memanggil
• 書く _kaku_ = menulis
• 帰る _kaeru_ = pulang
• 乗る _noru_ = naik (kendaraan)
Dll...

2️⃣ Kata Kerja る (RU)
Yaitu kata kerja yang bunyi akhirnya berupa *-ERU* atau *-IRU*.
Contoh:
• 食べる _taberu_ = makan
• 見る     _miru_     = melihat
• 着る     _kiru_      = mengenakan
• 教える _oshieru_ = mengajarkan
Dll...

*Catatan:* Ada beberapa kata kerja yang bunyi akhirnya *-eru/-iru* tetapi masuk dalam kelompok 1 di atas. Contohnya 帰る _kaeru_ (pulang). Ini perlu diingat.

3️⃣ Kata Kerja Tak Beraturan
Yaitu terdiri dari dua saja:
• する _suru_ = melakukan
• 来る _kuru_ = datang

《📺  Contoh》-----------------------
Berikut ini contoh perubahan pada masing-masing kelompok agar kita bisa melihat perbedaan tiap kelompoknya:

[Bentuk Sekarang          Berlalu]
1️⃣ yomu (membaca)   yonda
1️⃣ kaku (menulis)        kaita

2️⃣ taberu (makan)       tabeta
2️⃣ miru (melihat)         mita

3️⃣ kuru (datang)          kita
3️⃣ suru (melakukan)    shita
______________________________
20-10-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "24") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 文法 • TATA BAHASA ⭐
☆ マスけい ☆
◇ Bentuk -MASU ◇

[ 🔍 PENGERTIAN ]______________
Adalah bentuk kata kerja bahasa Jepang yang digunakan dalam bahasa sopan *(teineigo)*. Dapat digunakan ketika berbicara kepada yang bukan teman dekat kita.

[ ⚙️ POLA ]____________________
*akar kata kerja + ます (masu)*

Apa itu akar kata kerja?
Akar kata kerja bisa kita dapatkan dengan cara berikut sesuai kelompok kata kerja:

1️⃣ Kelompok Kata Kerja う (u)
Ubah huruf akhir menjadi bunyi い (i) -nya (sesuai dalam susunan huruf hiragana).

う u    --> い i        む mu --> み mi
つ tsu --> ち chi    く ku  --> き ki
る ru   --> り ri       ぐ gu --> ぎ gi
ぶ bu  --> び bi      す su --> し shi
ぬ nu  --> に ni

Contoh:        読む yomu (membaca)
Akar katanya: 読み yomi
Bentuk MASU: 読みます yomimasu

2️⃣ Kelompok Kata Kerja る (ru)
Untuk memperoleh akar kata kerjanya tinggal dihapus saja る ru di akhir katanya.

Contoh:        食べる taberu (makan)
Akar:             食べ     tabe
Bentuk MASU: 食べます tabemasu

3️⃣ Kelompok Pengecualian
Hanya terdiri dari dua kata kerja:
• する suru (melakukan)
Akar:                 し shi
Bentuk MASU:  します shimasu

• 来る kuru (datang)
Akar:                  き ki
Bentuk MASU:   来ます kimasu

[ 📺 CONTOH KALIMAT ]_________
🇯🇵 学校へ *行く。*
       _gakkou e *iku*_
🇮🇩 Saya *pergi* ke sekolah.
(Biasa)

🇯🇵 学校へ *行きます。*
       _gakkou e *ikimasu*_
🇮🇩 Saya *pergi* ke sekolah.
(Sopan)
______________________________
26-10-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "25") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 文法 • TATA BAHASA ⭐
☆ た形 ☆
◇ Bentuk -TA (Lampau) ◇

🔍 PENGERTIAN _______________
Bentuk TA adalah bentuk lampau atau yang terjadi sebelum sekarang.

⚙️ POLA ______________________
Untuk membentuk kata kerja TA, maka tergantung pada kelompok kata kerjanya:

1️⃣ Kelompok Kata Kerja う (u)
Ubah huruf akhir kata kerja dengan aturan berikut:
うu / つtsu / るru     ==>  ったtta
ぶbu / ぬnu / むmu  ==>  んだnda
                        くku   ==> いた ita
                        ぐgu   ==> いだ ida
                        す su  ==> した shita

Contoh:
• 書く     kaku (menulis)
   書いた kaita (telah menulis)

• 話す      hanasu    (berbicara)
   話した hanashita (telah bicara)

Catatan:
Khusus 行く      iku (pergi)
          = 行った *itta* (telah pergi)

2️⃣ Kelompok Kata Kerja る (ru)
Ubah huruf るru nya langsung menjadi たta.

Contoh:
• 食べる taberu (makan)
  食べた tabeta  (telah makan)

• 見る miru  (melihat)
   見た mita  (telah melihat)

3️⃣ Kelompok Pengecualian
1) する suru (melakukan)
  = した shita (telah melakukan)

2) 来る kuru (datang)
  = 来た kita (telah datang)

🌸 BENTUK SOPAN _____________
Jika sudah belajar bentuk -MASU, maka untuk membentuk bentuk sopan pada kata kerja lampau yaitu cukup mengganti ~ます -MASU menjadi ~ました -MASHITA.

Contoh:
• 行きます ikimasu          (pergi)
• 行きました ikimashita (telah pergi)
______________________________
30-10-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "26") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 文法 • TATA BAHASA ⭐
☆ ない形 ☆
◇ Bentuk -NAI (Negatif) ◇

🔍 *PENGERTIAN*______________
Bentuk NAI adalah bentuk kata kerja negatif atau sangkalan (tidak dilakukan).

⚙️ *POLA*____________________
Untuk membentuk kata kerja NAI, tergantung pada kelompok kata kerjanya:

1️⃣ Kelompok Kata Kerja う (u)
Ubah huruf akhir kata kerjanya ke huruf bunyi -A nya seperti berikut:

ぶbu --> ばba     くku --> かka
ぬnu --> なna     ぐgu --> がga
むmu --> まma   すsu --> さsa

うu    --> *わwa* (khusus)
つtsu -->  たta
るru   -->  らra

Kemudian tambahkan ない (nai).

*Contoh:*
読む          yomu     (membaca)
読まない yomanai (tdk membaca)

会う         au          (bertemu)
会わない awanai (tdk bertemu)

2️⃣ Kelompok Kata Kerja る (ru)
Ubah akhiran るru nya langsung menjadi ないnai.
Contoh:
• 食べる     taberu   (makan)
   食べない tabenai (tidak makan)

• 見る     miru   (melihat)
   見ない minai (tidak melihat)

3️⃣ Kelompok Pengecualian
1) する suru       (melakukan)
    しない shinai (tidak melakukan)

2) 来る kuru       (datang)
    来ない *konai* (tidak datang)

🌸 *BENTUK SOPAN*____________
Bentuk sopan adalah kata kerja bentuk -MASU. Untuk bentuk negatifnya hanya dengan mengubah -MASU menjadi -MASEN.

Contoh:
• 分かります wakarimasu (mengerti)
• 分かりません wakarimasen (tidak mengerti)
______________________________
3-11-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "27") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 語彙 • Kosakata ⭐
☆ 数 • Angka ☆

🔵 *ANGKA SATUAN*
零      rei/zero           nol
一      ichi                  satu
二      ni                     ni
三      san                  tiga
四      yon/shi            empat
五      go                    lima
六      roku                 enam
七      shichi/nana     tujuh
八      hachi               delapan
九      kyuu                 sembilan
十      juu                   sepuluh

🔴 *ANGKA PULUHAN*
十          juu             sepuluh
二十      ni juu         dua puluh
三十      san juu      tiga puluh
四十      yon juu      empat puluh
五十      go juu        lima puluh
Dst...

🟢 *ANGKA RATUSAN*
百        hyaku           seratus
二百    ni hyaku       dua ratus
三百    *sanbyaku*     tiga ratus
四百    yon hyaku    empat ratus
五百    go hyaku      lima ratus
六百    *roppyaku*      enam ratus
七百    nana hyaku  tujuh ratus
八百    *happyaku*     delapan ratus
九百    kyuu hyaku   sembilan ratus

🟠 *ANGKA RIBUAN*
千        sen           seribu
二千    ni sen       dua ribu
三千    *sanzen*    tiga ribu
四千    yon sen    empat ribu
五千    go sen      lima ribu
六千    roku sen   enam ribu
七千    nana sen  tujuh ribu
八千    *hassen*  delapan ribu
九千    kyuu sen   sembilan ribu

🌀 *MENYUSUN ANGKA*
Menyusun angka caranya disusun dari angka yang paling besar (ribuan>ratusan>puluhan>satuan)
Contoh:

☆ *12*   》 十二
                    (10 + 2)
_juu ni_

☆ *67*  》 六十七
                    六十      七
                    (60    +   7)
_rokujuu nana_

☆ *428* 》 四百二十八
                     四百     二十    八
                     (400  +   20   +  8)
_yonhyaku nijuu hachi_

☆ *8253* 》 八千二百五十三
                  (8000 + 200 + 50 + 3)
_hassen nihyaku gojuu san_
______________________________
7-11-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "28") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 文法 • TATA BAHASA ⭐
☆ 関係節 ☆
◇ Klausa Relatif ◇

*Memberi Keterangan Lebih Lanjut pada Kata Benda*
Di bahasa Indonesia kita bisa gunakan kata "yang" untuk menjelaskan sesuatu lebih rinci agar pendengar tahu maksud kita.
Contoh:
• Saya membaca *buku*.

Misalnya di kalimat ini kita ingin menjelaskan tentang buku itu, kita bisa tambahkan kata-kata seperti ini, diawali dengan kata "yang".

• Saya membaca *buku yang saya beli kemarin*.

Di dalam bahasa Jepang tidak ada terjemahan kata "yang" secara langsung, tapi kita bisa mengungkapkan menjelaskan suatu kata seperti ini dengan cara tersendiri di bahasa Jepang.

• *本* を読んでいます。
   *Hon* o yonde imasu.
   Saya sedang membaca *buku.*

Bagaimana cara kita beri penjelasan seperti contoh kalimat bahasa Indonesia di contoh sebelumnya? Caranya pikirkan kalimat yang menjadi penjelasnya

_"yang *saya beli kemarin*"_

"Saya beli kemarin" adalah kalimat penjelasnya, jika diterjemahkan:

私は昨日買いました
watashi wa kinou kaimashita

Tetapi ada aturan dalam membuat kalimat penjelas:
1) Ganti は wa dengan が ga atau の no
    私が / 私の
    watashi ga / watashi no 
(がga lebih umum digunakan)

2) Gunakan kata kerja bentuk biasa. (Tetapi tetap ikuti lampau/tidaknya)
     買いました --> 買った
     kaimashita    --> katta

Sehingga kalimat penjelas kita menjadi:
私が昨日買った
watashi ga kinou katta

Sekarang, di manakah kita letakkan kalimat penjelas ini?
Cukup letakkan *sebelum* kata benda yang dijelaskan.

*私が昨日買った* 本
*watashi ga kinou katta* hon
buku *yang saya beli kemarin*

Sekarang seluruh kalimat kita menjadi:
*私が昨日買った本* を読んでいます。
_*watashi ga kinou katta hon* o yonde imasu_
Saya sedang membaca *buku yang saya beli kemarin*.

❓ *が ga atau の no ?*
Walaupun kita bisa mengganti がga menjadi のno di kalimat itu, ini tidak selamanya berlaku, apabila maknanya berubah tidak seperti yang kita inginkan.

Di kalimat penjelas tersebut:
私が昨日買った本
_watashi ga kinou katta hon_
Buku yang saya beli kemarin

Jika menggunakan のno:
私の昨日買った本
_watashi no kinou katta hon_
Buku saya yang dibeli kemarin

Perbedaan maknanya tidak jauh. Jadi tidak apa-apa menggunakan のno. Tetapi jika ada kalimat penjelas seperti ini:

_Kue yang Tanaka buat di rumah_

Maka dalam bahasa Jepang:

田中さんが家で作ったケーキ
tanakasan ga ie de tsukutta keeki
kue yang Tanaka buat di rumah

Jika menggunakan のno maka:
田中さんの家で作ったケーキ
tanakasan no ie de tsukutta keeki
kue yang dibuat di rumah tanaka

Karena のno sekarang menyambungkan 田中さんtanakasan dengan 家ie (rumah) maka maknanya menjadi *"rumah Tanaka"*. 
Ini maknanya sedikit melenceng karena bisa bermakna orang lain yang yang membuat kue itu di rumah Tanaka.

📺 *CONTOH KALIMAT LAIN*
• お父さんが乗る自転車は壊れた。
   Otousan ga noru jitensha wa kowareta.
   Sepeda yang ayah naiki sudah rusak.

• 猫が飛んでいる鳥を追いかけています。
   Neko ga tonde iru tori o oikakete imasu.
   Kucing sedang mengejar burung yang sedang terbang.
______________________________
11-11-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "29") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 文法 • Tata Bahasa ⭐
☆ Partikel はwa ☆

🔍 *PENGERTIAN*
Partikel はwa yaitu kata yang menunjukkan topik (sesuatu yang menjadi pembahasan di kalimat).

⚙️ *PENGGUNAAN*
Partikel wa ditulis dengan huruf hiragana HA (は), namun untuk pengucapannya dibaca WA.

☆ *姉は* 台所に います。
     _*Ane wa* daidokoro ni imasu._
  = *Kakak* ada di dapur.

Pada kalimat di atas, partikel はwa melekat pada kata 姉ane (kakak perempuan), sehingga topik kalimat yang sedang dibicarakan adalah "kakak".

Topik kalimat tidak selalu perlu disebutkan jika sudah jelas apa topiknya.

• あの方はヘリです。
    _Ano kata wa Heri desu._
   Orang itu adalah Heri.

• 学生です。
   _Gakusei desu._
   (Dia) seorang siswa.

Di kalimat kedua topik tidak disebutkan lagi, langsung ke predikat (gakusei desu) karena sudah jelas topiknya masih sama seperti kalimat pertama (あの方ano kata = orang itu).
______________________________
15-11-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "30") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ Kalimat Pengandaian dengan Partikel とto ☆

Kalimat pengandaian bahasa Jepang dapat menggunakan beberapa jenis partikel atau bentuk kata kerja: とto, ならnara, たらtara, ばba.

Untuk materi ini mari fokus pada partikel とto.

Partikel とto dapat digunakan untuk membentuk pengandaian yang pasti terjadi/berlaku jika syaratnya terpenuhi menurut si pembicara. Maknanya seperti "kalau" dan "ketika" digabungkan.
Partikel とto nya diletakkan setelah kalimat bentuk biasa (bukan masu/desu).

📚 *Contoh:*

• 電気を *消すと*、暗くなります。
_denki o *kesu to*, kuraku narimasu_
*Kalau* kamu *matikan* lampu, jadi gelap.

• *暑いと*、眠れないよ。
_*atsui to,* nemurenai yo_
*Kalau panas,* aku tidak bisa tidur!

Untuk kata sifat NA atau kata benda, gunakan *だとdato*.
• *先生だと*、頭がいいですね。
_*sensei dato*, atama ga ii desu ne_
*Kalau* dia *guru*, dia pintar, kan?

Karena juga bisa berarti "ketika", partikel とto bisa juga digunakan untuk menceritakan syarat yang sudah berlalu.
• *質問すると*、先生はすぐに教えてくれました。
_*shitsumon suru to,* sensei wa sugu ni oshiete kuremashita_
*Ketika* saya *bertanya,* guru langsung memberitahu saya. 
(Kejadian yang sudah berlalu)
______________________________
3-12-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "31") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ Kalimat Pengandaian dengan Partikel ならNARA ☆

Partikel ならNARA adalah salah satu partikel yang dapat digunakan untuk membuat pengandaian.

Untuk menggunakannya dalam kalimat hanya perlu diletakkan setelah kalimat biasa (bukan berbentuk masu/desu). Untuk kata sifat I dan kata kerja kita bisa tambahkan のNO untuk memberi penekanan.

Kata benda   + なら
Kata sifat NA + なら
Kata sifat I     + (の)なら
Kata kerja      + (の)なら

Kita bisa pakai kata ならばNARABA sebagai bentuk yang lebih formal.

💡 *Fungsi*
Fungsi ならNARA umumnya adalah menunjukkan permisalan mengenai apa yang sedang dipikirkan atau apa yang mungkin terjadi.

📚 *Contoh:*
1️⃣ Menunjukkan sesuatu yang kita akan beri pendapat/saran. Maknanya seperti gabungan topik dan permisalan. (Kalau)
• *ハナちゃん* なら出来るよ！
   _*hanachan nara* dekiru yo_
   *Kalau Hana* pasti bisa!
(Berpendapat tentang kemampuan si Hana)

• *遊園地なら* ディズニーランドがいい。
   _*yuuenchi nara* diizunirando ga ii_
   *Kalau taman hiburan,* yang bagus itu Disneyland.

• 私の兄は、 *パソコンのことなら* 何でもわかります。
   _watashi no ani wa, *pasokon no koto nara* nandemo wakarimasu_
   Kakak saya *kalau masalah komputer* apapun dia tahu.

2️⃣ Untuk memastikan apa yang sedang dimaksud orang lain. (Kalau, kalau soal)
• *あのドラマなら* まだ見ていない。
   _*ano dorama nara* mada miteinai_
   *Kalau drama itu,* aku belum pernah nonton.
(Misalnya setelah ditanya)

• *夜なら* いつでも家にいます。
   _*yoru nara* itsudemo ie ni imasu_
   *Kalau malam,* saya selalu di rumah.
(Setelah ditanya kemana dia akan pergi kalau malam)

• *それなら* なぜ辞めないんですか
   _*sore nara* naze yamenain desu ka_
   *Kalau itu (masalahnya)*, mengapa kamu tidak berhenti saja?

3️⃣ Untuk menyatakan syarat/batasan
• *バクソなら* ほしい。
   _*bakuso nara* hoshii_
   *Kalau bakso* aku mau.
   (Aku maunya bakso)

• *明日なら* 付き合ってもいいよ
   _*ashita nara* tsukiatte mo ii yo_
   *Kalau besok* kita bisa jalan-jalan.
(Kalau sekarang belum bisa)

• 甘い食べ物は食べられませんが、 *少しなら*...
  _amai tabemono wa taberaremasen ga, *sukoshii nara*..._
   Saya tidak bisa makan yang manis-manis, tapi *kalau sedikit...* (mungkin tidak apa-apa)

4️⃣ Untuk menekankan keadaan yang sedang atau akan terjadi. Ini bisa dipakai dengan saran atau permintaan. (Kalau, kalau memang)
• *もし冬に日本に行くなら*、コートを持っていった方がいいよ。
   _*moshi fuyu ni nihon ni iku nara*, kooto o motte itta hou ga ii yo_
   *Kalau kamu mau pergi ke Jepang di musim dingin*, sebaiknya bawa mantel.

• *困っているなら* 相談してください。
   _*komatte iru nara* soudan shite kudasai_
   *Kalau kamu memang lagi dalam masalah* marilah kita bicarakan.

• *結婚してくれないなら* 別れます。
   _*kekkon shite kurenai nara* wakaremasu_
   *Kalau kamu tidak mau menikah denganku* kita putus.

5️⃣ Untuk perumpamaan (sesuatu yang tidak nyata). (Kalau saja, jika saja). 
(Menggunakan kalimat lampau)
• *もし父がここにいたならば*、何と言うだろう。
   _*moshi chichi ga koko ni ita naraba*, nanto iu darou_
   *Kalau saja ayahku ada di sini*, dia akan bilang apa ya...
______________________________
10-12-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "32") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ Bentuk Kata Kerja -BA ☆

Bentuk kata kerja ばBA adalah bentuk yang dipakai untuk membuat pengandaian selain dengan bentuk たらTARA atau partikel とTO dan ならNARA.

⚙️ *Rumus*
Cukup ubah huruf terakhir kata kerja menjadi bunyi E lalu tambahkan ばBA.

📟 *Contoh:*
• 読む yomu --> 読めば yomeba
   membaca         jika membaca

• 行く iku     --> 行けば ikeba
   pergi                 jika pergi

• 勝つ katsu --> 勝てば kateba
   menang            jika menang

• 食べる taberu --> 食べれば tabereba
   makan                     jika makan

• する suru --> すれば sureba
   melakukan      jika melakukan

Untuk kata kerja negatif (bentuk ないNAI) maka ubah akhiran I-nya menjadi ければKEREBA.

• 知らない --> 知らなければ
   shiranai           shiranakereba
   tidak tahu       jika tidak tahu

• 頑張らない --> 頑張らなければ
   ganbaranai        ganbaranakereba
 tidak berusaha   jika tidak berusaha

Kata sifat I juga berlaku aturan yang sama dengan di atas.
• 寒い --> 寒ければ
   samui      samukereba
   dingin      jika dingin

• 悪い --> 悪ければ
   warui       warukereba
   buruk       jika buruk

Begitu juga dengan bentuk negatifnya (くないKUNAI)
• 寒くない --> 寒くなければ
   samukunai      samukunakereba

Untuk kata benda dan kata sifat NA, tambahkan であればDE AREBA, atau なら(ば) NARA(BA).
• 先生 --> 先生であれば
   sensei      sensei de areba
   guru        jika ... adalah guru
(atau 先生なら sensei nara/naraba)

• きれい --> きれいであれば
   kirei              kirei de areba
   indah           jika indah
(atau きれいなら kirei nara/naraba)

Untuk bentuk negatifnya gunakan でなければ DE NAKEREBA, atau じゃなければ JANAKEREBA (bahasa sehari2).
• きれいでなければ
    kirei de nakereba
    jika tidak indah

💡 *Fungsi:*
Bentuk BA digunakan untuk menyatakan syarat, yang harus terpenuhi dulu baru pernyataannya bisa benar atau terjadi. 
• *タクシーで行けば*、6時の電車に乗れるでしょう。
   _*takushii de ikeba*, rokuji no densha ni noreru deshou_
   *Jika kamu pergi naik taksi*, mungkin kamu bisa naik kereta jam 6.

• *雨が降れば*、散歩に行きません。
   _*ame ga fureba*, sanpo ni ikimasen_
   *Jika hujan turun*, saya tidak akan pergi jalan-jalan.

• *春になれば*、もっと暖かくなる。
   _*haru ni nareba*, motto atatakaku naru_
   *Jika musim semi tiba*, akan menjadi lebih hangat.

• *時間があれば*、ケーキを作るよ。
   _*jikan ga areba*, keeki o tsukuru yo_
   *Jika saya punya waktu*, saya akan buat kue.

⏱️ *Batasan:*
Jika menggunakan kalimat syarat dengan BA dengan permintaan atau perintah, kalimat syaratnya harus berupa keadaan (bukan berupa selesainya suatu aksi atau kejadian).
• *時間があれば*、来てください。
   _*jikan ga areba*, kite kudasai_
   *Jika kamu ada waktu*, tolong datang.
(Selama dia ada waktu: berupa keadaan)

• *空港に着けば*、電話しなさい。❌
   _*kuukou ni tsukeba*, denwa shinasai_
   *Jika kamu tiba di bandara*, telpon saya
(Tiba ke bandara bukan berupa keadaan tapi suatu aksi yang telah selesai dilakukan. Untuk kalimat ini lebih cocok menggunakan bentuk たらTARA: 空港に着いたらkuukou ni tsuitara). 
______________________________
14-12-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "33") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ Bentuk Kata Kerja -TARA ☆

Bentuk kata kerja たらTARA adalah bentuk kata kerja yang dipakai untuk membuat kalimat syarat selain dengan bentuk ばBA, dan partikel とTO dan ならNARA.

⚙️ *Rumus*
Pertama ubahlah kata kerja ke bentuk たTA (bentuk lampau) lalu tambahkan らRA. Ini juga berlaku untuk kata sifat dan kata benda.

📟 *Contoh:*
• 帰る kaeru --> 帰ったら kaettara
   pulang              kalau pulang

• 来る kuru --> 来たら kitara
   datang            kalau datang

• 書く kaku --> 書いたら kaitara
   menulis            kalau menulis

• する suru --> したら shitara
   melakukan      kalau melakukan

• 呼ぶ yobu --> 呼んだら yondara
   memanggil      kalau memanggil

Kata sifat I:
• 寒い --> 寒かったら
   samui      samukattara
   dingin      kalau dingin

Kata sifat NA dan kata benda:
• 上手 --> 上手だったら
   jouzu       jouzu dattara
   mahir       kalau mahir

• 学生 --> 学生だったら
   gakusei   gakusei dattara
   siswa       kalau siswa

Untuk bentuk negatif juga diubah ke bentuk negatif lampau terlebih dahulu lalu tambahkan らRA.

• 買わない --> 買わなかったら 
   kawanai          kawanakattara
   tidak beli         kalau tidak beli

• 安くない --> 安くなかったら
   yasukunai       yasukunakattara
   tidak murah    kalau tidak murah

Untuk kata sifat NA dan kata benda gunakan で(は)なかったら DE(WA)NAKATTARA. Atau yang lebih biasa diucapkan sehari-hari じゃなかったら JANAKATTARA
• 元気で(は)なかったら
   genki de(wa)nakattara
   kalau tidak sehat

• 私で(は)なかったら
   watashi de(wa)nakattara
   kalau bukan saya

💡 *Fungsi*
Untuk membuat kalimat syarat yang berupa perkiraan umum. Syarat yang diberikan punya kemungkinan akan terjadi sehingga bisa berarti "kalau", "kalau sudah", "ketika"...
• もし明日晴れたら、ゴルフに行きます。
   _moshi ashita haretara, gorufu ni ikimasu_
   Kalau besok cerah, saya akan pergi main golf.

• それ美味しかったら私も食べたい。
   _sore oishikattara watashi mo tabetai_
   Kalau itu enak aku juga mau makan

• 日本に来たら連絡してね。
   _nihon ni kitara renraku shite ne_
   Kalau sudah datang ke Jepang hubungi saya ya.

• お酒を飲んだら、運転してはいけません。
   _osake o nondara, unten shite wa ikemasen_
   Kalau sudah minum sake jangan berkendara
______________________________
18-12-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "34") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *語彙* • Kosakata ⭐
☆ Kata Tanya ☆

💬 *何* nani/nan  = apa
💬 *誰* dare  = siapa
💬 *どなた* donata = siapa (lebih sopan)
💬 *誰の* dare no = milik siapa
💬 *どこ* doko = di mana
💬 *どちら* dochira = sebelah mana/yang mana (biasanya antara 2 pilihan)
💬 *どう* dou   = bagaimana
💬 *いかが* ikaga = bagaimana (biasanya untuk tawaran)
💬 *どれ* dore  = yang mana
💬 *どっち* docchi = yang mana
💬 *どの...* dono... = .... yang mana
💬 *いくつ* ikutsu = berapa
💬 *いくら* ikura = berapa harga
💬 *どうして* doushite = mengapa
💬 *なぜ* naze = mengapa (lebih formal)
💬 *いつ* itsu = kapan
💬 *何時* nanji = jam berapa
💬 *何人* nannin = berapa orang
💬 *どんな* donna = yang seperti apa
💬 *どのくらい* dono kurai = berapa lama
______________________________
26-12-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "35") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *語彙* • Kosakata ⭐
☆ Keterangan Waktu ☆

⏰ 今 ....... ima .............. sekarang
⏰ 後で ... ato de ......... nanti
⏰ さっき sakki ........... tadi
/ 先程 sakihodo (lebih formal)

⏰ 朝 ....... asa ............. pagi
⏰ 今朝 ... kesa ........... pagi ini
⏰ 昼 ....... hiru ............ siang
⏰ 夕方 ... yuugata .... sore
⏰ 夜 ....... yoru ........... malam
⏰ 今晩 ... konban ..... malam ini
/ 今夜 kon'ya (lebih formal)
⏰ 夕べ ... yuube ....... tadi malam
/ 昨夜 sakuya (lebih formal)

⏰ 今日 ... kyou ............ hari ini
⏰ 明日 ... ashita .......... besok
/ 明日 asu (lebih formal)
⏰ 明後日 asatte .......... lusa
⏰ 昨日 ... kinou ........... kemarin
⏰ 一昨日 ototoi ....... kemarin dulu
⏰ 先日 ... senjitsu ....... tempo hari

⏰ 今週 ... konshuu ..... minggu ini
⏰ 来週 .. raishuu .. minggu depan
⏰ 再来週 saraishuu ... dua minggu yang akan datang
⏰ 先週 ... senshuu ..... minggu lalu

⏰ 今月 ... kongetsu ...... bulan ini
⏰ 来月 ... raigetsu .... bulan depan
⏰ 再来月 saraigetsu ... dua bulan yang akan datang
⏰ 先月 ... sengetsu ...... bulan lalu

⏰ 今年 ... kotoshi ........ tahun ini
⏰ 来年 ... rainen ...... tahun depan
⏰ 再来年 sarainen ... dua tahun yang akan datang
⏰ 去年 ... kyonen ...... tahun lalu

⏰ 毎日 mainichi ... tiap hari
⏰ 毎朝 maiasa ..... tiap pagi
⏰ 毎晩 maiban .... tiap malam
⏰ 毎週 maishuu ... tiap minggu
⏰ 毎月 maigetsu ... tiap bulan
⏰ 毎年 maitoshi ... tiap tahun
______________________________
30-12-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "36") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *言葉* • Kata-Kata ⭐
☆ Ungkapan Memberi Semangat ☆

📣 頑張ってください！
       Ganbatte kudasai!
       Berjuanglah!

📣 頑張れ！
       Ganbare!
       Berjuang! 

📣 出来るよ！
       Dekiru yo!
       Kamu pasti bisa!

📣 諦めないで！
       Akiramenaide!
       Jangan menyerah!

📣 もう少し！
       Mou sukoshi!
       Sedikit lagi!

📣 大丈夫
       Daijoubu
       Tidak apa-apa

📣 遅すぎることはない！
       Ososugiru koto wa nai!
       Tidak ada kata terlambat!

📣 きっと上手くいくよ！
       Kitto umaku iku yo!
       Semuanya akan lancar!

📣 最高！
       Saikou!
       Kamu yang terbaik!
______________________________
3-1-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "37") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *漢字* • Kanji ⭐
              
教育漢字
Kyouiku Kanji
(Kanji Pendidikan)

Kelas 1

1. 一 ichi : satu
2. 二 ni : dua
3. 三 san : tiga
4. 四 shi/yon : empat
5. 五 go : lima
6. 六 roku : enam
7. 七 shichi/nana : tujuh
8. 八 hachi : delapan
9. 九 kyuu : sembilan
10. 十 juu : sepuluh

11. 百 hyaku : seratus
12. 千 sen : seribu
13. 上 ue : atas
14. 下 shita : bawah
15. 左 hidari : kiri
16. 右 migi : kanan
17. 中 naka : dalam
18. 大 oo(kii)/dai : besar
19. 小 chii(sai)/shou : kecil
20. 月 tsuki/getsu : bulan

21. 日 hi/nichi : hari
22. 年 toshi/nen : tahun
23. 早 haya(i)/sou : cepat (awal)
24. 木 ki : pohon
25. 林 hayashi : hutan kecil
26. 山 yama : gunung
27. 川 kawa : sungai
28. 土 tsuchi : tanah
29. 空 sora : langit
30. 田 ta : sawah

31. 天 ten : langit, surga
32. 生 i(kiru)/u(mu)/sei : hidup, lahir
33. 花 hana : bunga
34. 草 kusa : rumput
35. 虫 mushi : serangga
36. 犬 inu : anjing
37. 人 hito/jin/nin : orang
38. 名 na/mei : nama
39. 女 onna : perempuan
40. 男 otoko : laki-laki

41. 子 ko : anak
42. 目 me : mata
43. 耳 mimi : telingan
44. 口 kuchi : mulut
45. 手 te : tangan
46. 足 ashi : kaki
47. 見 mi(ru)/ken : melihat
48. 音 oto : bunyi
49. 力 chikara : kekuatan
50. 気 ki/ke : udara/ruh/jiwa/pikiran

51. 円 en : yen
52. 入 hai(ru)/i(reru)/nyuu : masuk
53. 出 de(ru)/da(su)/shutsu : keluar
54. 立 ta(tsu)/ritsu : berdiri
55. 休 yasu(mu)/kyuu : istirahat
56. 先 saki : tadi, sebelumnya
57. 夕 yuu/seki : sore
58. 本 hon : buku
59. 文 bun : kalimat
60. 字 ji : karakter (tulisan)

61. 学 gaku/mana(bu) : belajar
62. 校 kou : sekolah
63. 村 mura : desa
64. 町 machi : kota
65. 森 mori : hutan lebat
66. 正 tada(shii)/sei : benar
67. 水 mizu/sui : air
68. 火 hi/ka : api
69. 玉 tama : bola
70. 王 ou : raja

71. 石 ishi : batu
72. 竹 take : bambu
73. 糸 ito : benang
74. 貝 kai : kerang
75. 車 kuruma/sha : mobil
76. 金 kane/kin : uang, emas
77. 雨 ame/u : hujan
78. 赤 aka : merah
79. 青 ao : biru
80. 白 shiro/haku : putih
_________________________
7-1-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "38") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *KOSAKATA* ⭐
_Hewan_
_______________________
*doubutsu* hewan 動物
*hebi* 🐍 ular へび
*inu* 🐕 anjing 犬
*ahiru* 🦆 bebek アヒル
*uma* 🐎 kuda 馬
*ushi* 🐄 sapi 牛
*neko* 🐈 kucing 猫
*zou* 🐘 gajah 象
*raion* 🦁 singa ライオン
*wani* 🐊 buaya ワニ
*sakana* 🐟 ikan 魚
*tori* 🦜 burung 鳥
*nezumi* 🐭 tikus ネズミ
*usagi* 🐰 kelinci ウサギ
*kirin* 🦒 jerapah キリン
*kame* 🐢 kura-kura カメ
*kaeru* 🐸 katak 蛙
*buta* 🐖 babi 豚
_______________________
🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "39") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *語彙* • Kosakata ⭐

☆ Buah dan Sayur ☆
🍎 林檎 *ringo* apel
🍊 オレンジ *orenji* jeruk (orange)
🍊 蜜柑 *mikan* jeruk mandarin
🍒 桜桃 *sakuranbo* ceri
🍓 苺 *ichigo* stroberi
🍉 西瓜 *suika* semangka
🍑 桃 *momo* persik
🍌 バナナ *banana* pisang
🍇 葡萄 *budou* anggur
🍅 トマト *tomato* tomat
🍋 レモン *remon* lemon
🥕 人参 *ninjin* wortel
🧅 玉ねぎ *tamanegi* bawang bombai
🍆 なす/なすび *nasu/nasubi* terong
🥒 胡瓜 *kyuuri* mentimun
🧄 大蒜 *ninniku* bawang putih
🎃 南瓜 *kabocha* labu
🫑 ピーマン *piiman* paprika
🥭 マンゴー *mangoo* mangga
🍍 パイナップル *painappuru* nanas
🥥 ココナッツ *kokonattsu* kelapa
🥔 じゃが芋 *jagaimo* kentang
🥦 ブロッコリー *burokkorii* brokoli
🌶️ 唐辛子 *tougarashi* cabai
🌽 玉蜀黍 *toumorokoshi* jagung
_________________________
11-1-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "40") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ ~による ☆
◇ ... ni yoru ◇

Pola *ni yoru* digunakan untuk menunjukkan suatu sebab, cara, ketergantungan, atau sumber.
Dapat diartikan: akibat, disebabkan, dengan cara, oleh, menurut, tergantung ...

⚙️ *Penggunaan*
Untuk menggunakannya sebagai keterangan yang berdiri sendiri, maka bentuknya dijadikan *~によって* [ni yotte], atau lebih formalnya *~により* [ni yori]. Bisa juga ditambahkan はwa buat penekanan, (によっては ni yotte wa).

1 - Menunjukkan Sebab/Cara
• 彼は *火災によって* 怪我しました。
_Kare wa *kasai ni yotte* kega shimashita._
Dia terluka *akibat kebakaran.*

• *インターネットによって*、あの人の情報をたくさん得られます。
_*Intaanetto ni yotte*, ano hito no jouhou wo takusan eraremasu._
*Dengan (menggunakan) internet*, saya bisa banyak mendapatkan informasi mengenai orang itu.

2 - Menunjukkan Pelaku/Pembuat
Biasanya dalam pekerjaan yang berkaitan dengan pembuatan.
• この建物は *リドワン•カミルによって* 設計された。
_Kono tatemono wa *ridowan kamiru ni yotte* sekkei sareta._
Gedung ini dirancang *oleh Ridwan Kamil.*

• 『坊ちゃん』は *夏目漱石によって* 書かれた。
_"Botchan" wa *natsume soseki ni yotte* kakareta._
"Botchan" (novel) ditulis *oleh Natsume Soseki.*

3 - Menunjukkan Ketergantungan
Biasanya untuk menunjukkan sesuatu yang berbeda tergantung sesuatu.
• *場合によって*、答え方が違います。
_*Baai ni yotte*, kotaekata ga chigaimasu._
Cara menjawabnya berbeda *tergantung pada situasi.*

• *お父さんのアドバイスによって*、犬を飼うかどうか決めます。
_*Otousan no adobaisu ni yotte*, inu o kau ka dou ka kimemasu._
Saya akan memutuskan untuk memelihara seekor anjing atau tidak *tergantung saran ayah saya.*

4 - Menunjukkan Sumber
Untuk ini gunakan bentuk *~によると* [ni yoru to], atau *~によれば* [ni yoreba.]
• *私の発見によれば*、幸福は伝染するものです。
_*Watashi no hakken ni yoreba*, koufuku wa densen suru mono desu._
*Menurut pengamatanku*, kebahagiaan adalah sesuatu yang menular.

• *医者の話によると*、あの女性に重い心臓障害があるのだそうです。
_*Isha no hanashi ni yoru to*, ano josei ni omoi shinzou shougai ga aru no da sou desu._
*Menurut kata dokter*, perempuan itu katanya mempunyai masalah jantung yang serius.

⚙️ *Penggunaan 2*
Untuk menerangkan suatu kata benda, tetap gunakan bentuk *~による* [ni yoru].

Contoh:
• ここは *津波による被害* が大きい。
  _Koko wa *tsunami ni yoru higai* ga ookii._
  Di sini *kerusakan akibat tsunaminya* itu besar.

• 彼女は *火災による怪我* で入院しました。
_Kanojo wa *kasai ni yoru kega* de nyuuin shimashita._
Dia masuk rumah sakit karena *cidera akibat kebakaran.*
_________________________
18-1-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "41") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ Ringkasan Partikel ☆

1️⃣ *Partikel Penunjuk Peran Kata*
• が ga : Penunjuk subjek
• の no : Penunjuk pemilik
• を o/wo : Penunjuk objek atau penunjuk sesuatu yang dilalui
• に ni : Penunjuk target/tujuan, penunjuk lokasi kata kerja keberadaan, penunjuk waktu
• へ e : Penunjuk arah
• と to : Penunjuk pendamping
• で de : Penunjuk alat/bahan, penunjuk lokasi kegiatan, penunjuk alasan, penunjuk jangka waktu
• から kara : Penunjuk titik awal waktu/tempat, penunjuk bahan 
• より yori : Penunjuk pembanding, penunjuk asal

*2️⃣ Partikel Penyambung*
• と to = dan
• や ya (+などnado) = dan ... dan lain-lain
• か ka = atau
• とか toka = versi yang lebih informal dari や ya
• も mo = dan juga
• に ni = dan/ditambah
• だの dano = dan ... dan semacamnya (biasanya dengan nada mengkritik atau mengeluh)
• やら yara = seperti ... dan ... dan lain-lain (dengan ketidakpastian)
• なり nari = misalnya ... atau ...

3️⃣ *Partikel Akhir Kalimat*
• か ka, の no = untuk membuat kalimat tanya
• わ wa = biasanya digunakan oleh perempuan di akhir kalimatnya, dan terdengar halus
• ぞ zo, ぜ ze = biasanya digunakan oleh laki-laki di akhir kalimatnya, dan terdengar lebih kasar
• よ yo = untuk menekankan kalimat dan meyakinkan lawan bicara
• ね ne = untuk meminta pendapat (seperti _kan?_)
• ね ne (2) = untuk menghaluskan permintaan, untuk menunjukkan kalau kita mempertimbangkan kata lawan bicara
• な na = versi dari ね ne yang lebih sering dipakai laki-laki
• な na (2) = untuk melarang
• な(あ) na(a) = memberi kesan penasaran
• さ(あ) sa(a) = memberi kesan percaya diri
• とも tomo = memberi kesan setuju (tentu saja)
• かな kana / かしら kashira = menunjukkan kesan bertanya-tanya atau penasaran

4️⃣ *Partikel Keterangan*
• ばかり bakari = baru (saja)
• ばかり bakari (2) = hanya
• まで made = sampai
• だけ dake = saja
• ほど hodo = sampai, seperti
• くらい kurai / ぐらい gurai = kira-kira
• など nado = dan lain-lain

5️⃣ *Partikel Pengikat Kalimat*
• は wa = menunjukkan topik kalimat
• も mo = menunjukkan topik tambahan (juga)
• こそ koso = menekankan sesuatu (justru, -lah)
• でも demo = menunjukkan sesuatu yang juga berlaku (pun)
• しか shika = membatasi sesuatu yang berlaku, di dalam kalimat negatif (hanya, cuma)
• さえ sae / だに dani = menekankan sesuatu yang tak kalah pentingnya (bahkan)

6️⃣ *Partikel Penghubung Kalimat*
• が ga = tapi
• のに noni = padahal
• ので node, から kara = karena
• ところが tokoroga = ternyata, rupanya, kenyataannya
• けれども keredomo/けれど keredo/けど kedo = tapi

7️⃣ *Partikel Frasa*
• の no = mengubah kata kerja menjadi kata benda
• から kara = menunjukkan setelah
_____________________________
25-1-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "42") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *語彙* • Kosakata ⭐
☆ Hobi ☆

Hobi = 趣味 shumi

趣味は何ですか?
_Shumi wa nan desu ka?_
Apa hobimu?

*KATA BENDA HOBI*
Untuk menyebutkan hobi sendiri dengan kata benda maka gunakan pola kalimat:

(私の)趣味は______です。
_(Watashi no) shumi wa ....... desu._
Hobi saya adalah ........

_______ が好きです。
_...... ga suki desu._
Saya suka ........

*supootsu* ⛹🏻‍♂️ olahraga スポーツ
*kaimono* 🛍️ belanja 買い物
*dokusho*  📖 membaca 読書
*konpyuuta* 🖥️ komputer コンピュータ
*saafin* 🏄🏻‍♀️ selancar サーフィン
*jogingu* 🏃🏻‍♂️ jogging ジョギング
*origami* 📄 origami (seni melipat kertas)  折り紙
*ryouri*     👨🏻‍🍳 masak 料理
*jouba*     🏇🏼 berkuda 乗馬
*gitaa*      🎸 gitar ギター
*sakkaa* ⚽ sepakbola サッカー
*suiei*      🏊🏻‍♀️ renang 水泳
*piano*    🎹 piano ピアノ
*doramu* 🥁 drum ドラム
*sukii*      ⛷️ ski        スキー
*sukeetoboodo* 🛹 skateboard スケートボード
*tsuri*   🎣 memancing 釣り
*tenisu* 🎾 tenis テニス
*geemu* 🎮 game ゲーム
*ongaku* 🎼 musik 音楽
*dansu* 💃🏻 tari ダンス
*basukettobooru* 🏀 bola basket バスケットボール
*futtobooru* 🏈 sepakbola Amerika フットボール
*yakyuu* ⚾ bisbol 野球
*eiga* 📽️ film 映画
*sanpo* 🚶🏻‍♂️ jalan-jalan 散歩
*gaadeningu* 🌺 berkebun ガーデニング
*ryokou* ✈️ traveling 旅行
*doraibu* 🚗 berkendara ドライブ
*shashin* 📸 foto 写真
*karaoke* 🎤 karaoke カラオケ
*manga* 📘 komik 漫画

*Contoh:*
趣味は野球です。
_Shumi wa yakyuu desu._
Hobi saya bisbol.

音楽が好きです。
_Ongaku ga suki desu._
Saya suka musik.

=======================

*KATA KERJA HOBI*
Untuk menyebutkan hobi sendiri dengan menggunakan kata kerja maka polanya:

(私の)趣味は______ことです。
_Watashi no shumi wa ..... koto desu._

______の/ことが好きです。
_....... no/koto ga suki desu._
Saya suka ..........

*• e o kaku* 👩🏻‍🎨 menggambar 絵を描く
*• oyogu* 🏊🏼‍♂️ berenang 泳ぐ
*• nihongo o benkyou suru* 🇯🇵 belajar bahasa Jepang 日本語を勉強する
*• eiga o miru* 📺 menonton film 映画を観る
*• ryouri suru* 🍳 memasak 料理する
*• okashi o tsukuru* 🥞 membuat kue お菓子を作る
*• hon o yomu* 📖 membaca buku 本を読む
*• karaoke de utau* 🎤 menyanyi karaoke カラオケで歌う
*• ongaku o kiku* 🎧 mendengarkan musik 音楽を聴く
*• gitaa o hiku* 🎸 bermain gitar ギターを弾く
*• sakkaa o suru* ⚽ bermain sepakbola サッカーをする
*• gaishoku o suru* 🍜 makan di luar 外食をする
*• skyuuba daibingu o suru* 🤿 scuba diving スキューバダイビングをする

Contoh:
サッカーをすることが好きです。
_Sakkaa o suru koto ga suki desu._
Saya suka main bola.
_______________________
29-1-21 | 🇯🇵 *Belajar Nihon-go*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "43") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ ~通す ☆
◇ ~toosu ◇

Kata ini biasanya disambungkan dengan bentuk akar dari kata kerja untuk memberi makna melakukan sampai habis/selesai, atau melakukan sesuatu sampai jauh, sampai tingkatan yang jauh.

⚙️ *Pola*
Kata Kerja bentuk akar + 通す
Contoh kata:
• 読み通す yomitoosu = membaca sampai habis / menghabiskan membaca

• 見通す mitoosu = melihat jauh

📺 *Contoh Kalimat*
• やると決めたことは最後まで *やり通す* べきだ。
_Yaru to kimeta koto wa saigo made *yaritoosu* beki da._
= Sesuatu yang telah kamu putuskan untuk dilakukan, seharusnya kamu *terus melakukannya* sampai akhir.

• 足が痛かったが、最後まで諦めずに、 *走り通した。*
_Ashi ga itakatta ga, saigo made akiramezu ni, *hashiritooshita.*_
= Kakiku terasa sakit tetapi aku *terus berlari* tanpa menyerah sampai akhir.

• 夜中ずっと *泣き通されて*、一睡もすることができなかった。
_Yonaka zutto *nakitoosarete*, issui mo suru koto ga dekinakatta._
= Ia sampai *terus menangis* semalaman dibuatnya, tidur sedikitpun tidak bisa.

📝 *Contoh Kata Kerja dengan 通す*
• 見通す mitoosu = melihat jauh
• 押し通す oshitoosu = memaksa, bersikeras
• やり通す yaritoosu = menyelesaikan, melakukan sampai selesai
• 貫き通す tsuranukitoosu = menembus, terus maju (dengan prinsipnya)
• 突き通す tsukitoosu = menusuk sampai tembus
• 射通す itoosu = menembus
• 読み通す yomitoosu = membaca habis
• 働き通す hatarakitoosu = terus bekerja
• 透き通す sukitoosu = menembus (cahaya)
• 切り通す kiritoosu = memotong (jalan)
• 言い通す iitoosu = memaksakan berkata
• 吹き通す fukitoosu = terus berhembus
• 歩き通す arukitoosu = terus berjalan
• 勝ち通す kachitoosu = menang berturut-turut
• 泣き通す nakitoosu = terus menangis
_____________________________
2-1-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "44") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ まま ☆
◇ "mama" ◇

Kata まま [mama] dapat berarti 'suatu keadaan yang dibiarkan apa adanya', atau 'keadaan yang tetap sama'.

⚙️ *Penggunaan*
1) Dengan kata benda lain
......のまま 
...... no mama
= Bermakna 'keadaan yang sama seperti sesuatu'
   Contoh:
• 昔のまま mukashi no mama = sama seperti dulu

2) Dengan kata sifat
[kata sifat I] + まま mama
[kata sifat NA] + なまま na mama
= Bermakna 'tetap dalam keadaan sesuai kata sifatnya'
   Contoh:
• 若いまま wakai mama = tetap muda
• 便利なまま benri na mama = tetap praktis

3) Dengan kata tunjuk
• このまま kono mama = tetap seperti ini
• あのまま ano mama = tetap seperti itu

4) Dengan kata kerja
[kata kerja] + まま mama
= Bermakna 'tetap dalam keadaan dibiarkan dilakukan sesuatu sesuai kata kerjanya'
   Contoh:
• 開けたまま aketa mama = dalam keadaan dibiarkan terbuka
• しないまま shinai mama = dalam keadaan dibiarkan tidak dikerjakan
• 言われるまま iwareru mama = sama seperti apa yang kita telah diberitahukan
• 思うまま omou mama = seperti yang seseorang pikirkan (inginkan)

*Catatan:
Dalam percakapan sehari-hari bisa menggunakan まんま manma (cara bacanya _mamma_)

📺 *Contoh-contoh Kalimat*
• これ、生のまま食べられますか?
   _Kore, nama no mama taberaremasu ka?_
= Apakah ini bisa dimakan (dalam keadaan) mentah?

• そのまま食べてください。
   _Sono mama tabete kudasai._
= Silakan makan dalam keadaan begitu.

• このまままっすぐ進んでください。
   _Kono mama massugu susunde kudasai._
= Tolong terus maju lurus kedepan (seperti ini.)

• この村は昔のままだ。
   _Kono mura wa mukashi no mama da._
= Desa ini masih sama seperti dulu.

• いつまでも若いままでいたい。
   _Itsumademo wakai mama de itai._
= Aku ingin terus menjadi muda.

• パジャマを着たまま朝食を食べた。
   _Pajama o kita mama choushoku o tabeta._
= Saya makan pagi dalam keadaan memakai baju piyama.

• 電気をつけたままで寝てはいけません。
   _Denki o tsuketa mama de nete wa ikemasen._
= Jangan tidur dalam keadaan lampu dinyalakan.

• 自分の思うまま生きたらいい。
   _Jibun no omou mama ikitara ii._
= Kau boleh hidup seperti yang dirimu pikirkan (=inginkan).

• 彼女に別れを言わないまま日本に来てしまった。
  _Kanojo ni wakare o iwanai mama nihon ni kite shimatta._
= Aku pergi ke Jepang tanpa (dalam keadaan tidak) mengucapkan perpisahan kepada pacarku.

• はっきり説明がないまま工事が始まった。
   _Hakkiri setsumei ga nai mama kouji ga hajimatta._
= Tanpa penjelasan yang jelas pekerjaan konstruksi itu dimulai.

• どうぞ靴のまま、お入りください。
   _Douzo kutsu no mama, ohairi kudasai._
= Silakan masuk dengan (memakai) sepatu.

• 勉強しないままそのテストを受けた。
  _Benkyou shinai mama sono tesuto o uketa._
= Saya mengikuti tes itu tanpa belajar.
_____________________________
9-2-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "45") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ 文法 • Tata Bahasa ⭐
☆ Partikel がga ☆
(Penunjuk Subjek)

🔨 *Fungsi*
Partikel が (ga) adalah partikel yang menunjukkan subjek dari kalimat, lebih tepatnya apa/siapa persisnya yang menjadi pelaku kata kerja, atau siapa/apa yang keadaannya/sifatnya sedang dijelaskan.

Subjek bisa sama dengan topik (yang biasanya ditandai dengan partikel はwa) dan kadang juga tidak sama.

🟢 *Ketika Topik = Subjek*
Contoh kalimat ketika topiknya sama dengan subjek:

*ディマスさんは* ミルクを飲みました。
_*Dimasu san wa* miruku o nomimashita._
*Dimas* meminum susu.

Di sini topik kalimat adalah "Dimas" (karena diikuti はwa) dan kebetulan menjadi subjek atau pelaku dari kata kerja "meminum".

🔴 *Ketika Topik ≠ Subjek*
ぞうは *鼻が* 長いです。
_Zou wa *hana ga* nagai desu._
Gajah *hidungnya* panjang.

Topik kalimatnya adalah "gajah". Sedangkan subjeknya adalah "hidung" karena yang panjang hidungnya, bukan gajahnya.

🔵 *Ketika Topik tidak disebutkan*
Terkadang kita akan jumpai kalimat yang menggunakan penunjuk subjek (がga) tanpa adanya penunjuk topik (はwa). Biasanya jika topik belum ada, kalimat ini menunjukkan informasi baru.

*猫が* 飛びました。
_*Neko ga* tobimashita._
*Seekor kucing* telah melompat.

Berarti "kucing" di sini baru dikenalkan dalam percakapan/cerita karena tidak diketahui kucing yang mana. Misalnya jika percakapan/ceritanya dilanjutkan, maka partikel はwa sudah dapat digunakan pada kata 猫neko, karena kita sudah 'diperkenalkan' dengan si kucing.

あの *猫は* 高く飛びました。
_Ano *neko wa* takaku tobimashita._
*Kucing* itu melompat dengan tinggi.

Selain itu, menggunakan がga juga dapat memberi penekanan siapa/apa yang dimaksudkan melakukan sesuatu/sedang dijelaskan keadaannya.

*何が* 落ちた?
_*Nani ga* ochita?_
*Apa* yang jatuh?
(Dengan kata tanya seperti 何nani [apa] / 誰dare [siapa] partikel がga yang digunakan.)

*お皿が* 落ちた。
_*Osara ga* ochita._
*Piring lah* yang jatuh.
_____________________________
15-2-21 | 🇯🇵 Belajar Nihongo`,
			},
			{ quoted: fverif },
		);
	} else if (text === "46") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ Pola Kalimat: を通して / を通じて ☆
(o tooshite/o tsuujite)

📖 *Makna:* melalui ..., via ..., lewat ...

Bedanya, _wo tooshite_ cenderung digunakan jika sesuatu yang dilalui itu secara aktif dan sengaja dilakukan, misalnya mencari informasi melalui internet.

Sedangkan _o tsuujite_ cenderung mengarah kepada hal yang dilalui tanpa sengaja, atau tanpa usaha, bukan secara aktif kita melaluinya. Misalnya mendengar kabar lewat televisi.

Contoh:
• *学生のアンケートを通して*、留学生活の様子が分かる。
_*Gakusei no ankeeto o tooshite*, ryuugaku seikatsu no yousu ga wakaru._
= *Melalui angket siswa*, kita memahami keadaan kehidupan pelajar luar negeri.

• *自分の仕事を通じて* 人を幸せにするのが、心から好きなのです。
_*Jibun no shigoto o tsuujite* hito o shiawase ni suru no ga, kokoro kara suki na no desu._
= Saya menyukai sepenuh hati membuat orang bahagia *melalui pekerjaan saya.*

• そのことは *新聞を通じて* 知った。
_Sono koto wa *shinbun o tsuujite* shitta._
= Saya tahu hal itu *lewat koran*.

• 私は *友人を通して* 彼女と知り合いました。
_Watashi wa *yuujin o tooshite* kanojo o shiriaimashita._
= Saya mengenal dia *melalui teman saya.*

Selain itu jika digunakan dengan durasi waktu maka maknanya menjadi "selama" atau "di sepanjang".

Contoh:
• バンドンは *一年を通して*、気候が涼しい。
_Bandon wa *ichinen o tooshite*, kikou ga suzushii._
= Di Bandung, *sepanjang tahun* cuacanya sejuk.
_____________________________
19-2-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "47") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 BUNPOU* • Tata Bahasa ⭐
☆ 敬語 Keigo ☆
◇ Bahasa Hormat ◇

*敬語 Keigo* adalah jenis tingkatan bahasa dalam bahasa Jepang yang menunjukkan rasa hormat kepada lawan bicara. Mirip seperti bahasa Jawa yang memiliki tingkatan kasar dan halus, Jawa yang halus digunakan agar terdengar lebih sopan.

Keigo digunakan umumnya oleh pegawai toko kepada pelanggannya, bawahan kepada atasannya, atau suatu kelompok misalnya perusahaan kepada kelompok perusahaan tamu.

🈁 *Pembagian*
Keigo dibagi menjadi tiga jenis secara umum:

*☆ 丁寧語 Teineigo - Bahasa Sopan*
Adalah bahasa sopan yang digunakan secara umum dalam kehidupan sehari-hari. Jenis bahasa ini sering diajarkan pertama kali pada pembelajar bahasa Jepang. Ciri-cirinya adalah adanya kata-kata seperti ですdesu dan akhiran kata ~ますmasu.

*☆ 尊敬語 Sonkeigo - Bahasa Hormat*
Adalah bahasa yang digunakan untuk meninggikan lawan bicara atau orang yang sedang kita tunjukkan rasa hormat padanya.

*☆ 謙譲語 Kenjougo - Bahasa Merendah*
Adalah bahasa yang digunakan untuk berbicara soal diri kita sendiri atau orang yang menjadi
 kelompok kita yang sedang memberi hormat.

Dalam materi ini kita akan fokus pada dua bahasa hormat: sonkeigo dan kenjougo.

🔵 *Kata-Kata Sopan*
Di dalam keigo, beberapa kata biasanya digantikan dengan versi yang lebih formal. Contoh:
• besok: 明日 ashita ---> 明日 asu
• hari ini: 今日 kyou ---> 本日 honjitsu
• sebentar: ちょっと chotto ---> 少々 shoushou
• di mana: どこ doko ---> どちら dochira
• orang: 人 hito ---> 方 kata
• tadi: さっき sakki ---> 先ほど sakihodo

Beberapa kata hanya perlu tambahan 御 (o atau go). Aturan umumnya gunakan o jika kata itu dibaca secara kunyomi, dan gunakan go jika kata itu dibaca secara onyomi (kunyomi/onyomi adalah cara baca kanjinya, dibahas dalam materi kanji). Tetapi tidak semua kata mengikuti aturan ini. Oleh karena itu ikuti saja yang umum diucapkan orang.
• sushi: 寿司 sushi ---> お寿司 osushi
• pekerjaan: 仕事 shigoto ---> お仕事 oshigoto
• asal: 出身 shusshin ---> ご出身 goshusshin
• keluarga: 家族 kazoku ---> ご家族 gokazoku
• nama: 名前 namae ---> お名前 onamae

Selain itu akhiran pada nama orang (yang biasanya さんsan) menggunakan akhiran 様 -sama.

🛂 *Kata Kerja Hormat*
Di dalam keigo, kata-kata kerja tertentu memiliki bahasanya tersendiri baik itu untuk mengungkapkan sonkeigo maupun kenjougo.
Contoh:

Ket:
T = teineigo
S = sonkeigo
K = kenjougo

*いる iru (ada)*
T: います imasu
S: いらっしゃいます irasshaimasu / おいでになります oide ni narimasu
K: おります orimasu

*行く iku (pergi)*
T: 行きます ikimasu
S: いらっしゃいます irasshaimasu / おいでになります oide ni narimasu
K: 参ります mairimasu

*来る kuru (datang)*
T: 来ます kimasu
S: いらっしゃいます irasshaimasu / おいでになります oide ni narimasu / おこしになります okoshi ni narimasu / 見えます miemasu
K: 参ります mairimasu

*思う omou (berpikir)*
T: 思います omoimasu
S: 思いになります omoi ni narimasu
K: 存じます zonjimasu

*食べる taberu (makan) / 飲む nomu (minum)*
T: 食べます tabemasu / 飲みます nomimasu
S: 召し上がります meshiagarimasu
K: いただきます itadakimasu

*言う iu (berkata)*
T: 言います iimasu
S: おしゃいます oshaimasu
K: 申し上げます moushiagemasu / 申します moshimasu (untuk menyebut nama)

📶 *Pola Kata Kerja Keigo*
Untuk kata-kata kerja lain yang tidak memiliki versi sonkeigo dan kenjougonya tersendiri maka bisa menggunakan suatu pola khusus.

Sebenarnya ada pola yang lebih mudah, yaitu dengan menggunakan bentuk pasif, tetapi untuk menggunakannya harus hati-hati agar pendengar tidak salah paham.
(Bentuk pasif di bahas dalam materi tersendiri)
Contoh:
☆ 日本では何を *食べられますか?*
     _Nihon de wa nani o *taberaremasenka?*_
= Anda *makan* apa di Jepang?

Untuk sekarang mari kita fokus pada pola khusus sonkeigo/keigo.

*Akar Kata Kerja*
Keduanya menggunakan _akar kata kerja_ sebagai dasarnya. Akar kata kerja yaitu bentuk kata kerja yang disambungkan dengan akhiran ~ます -masu. Jadi akar kata kerja bisa didapatkan dengan menghapus -masu nya.
Misalnya: 読みます yomimasu (membaca)
--> 読み yomi

*🌺 Pola Kata Kerja Sonkeigo*
お o + Akar + になります ni narimasu
Contoh:
お読みになります
Oyomi ni narimasu

*🌼 Pola Kata Kerja Kenjougo*
おo + Akar + します shimasu
Contoh:
お読みします
Oyomi shimasu

Contoh Kalimat:
☆ 何時間 *お待ちになりましたか?*
     _Nanjikan *omachi ni narimashita ka?*_
= Berapa lama Anda *sudah menunggu?*
_____________________________
1-3-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "48") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ ~おきに ~oki ni ☆

Pola kalimat *~おきに ~oki ni* digunakan untuk menunjukkan interval waktu/jarak yang berulang.

Makna: setiap, tiap

Rumus:
• [selang waktu/interval jarak] + おきに

📺 *Contoh Kalimat*
電車は *５分おきに* 走っています。
_Densha wa *go-fun oki ni* hashitte imasu._
= Keretanya jalan *tiap 5 menit.*

*１０メートルおきに* 木を植えました。
_*Juu meetoru oki ni* ki o uemashita._
= Kami menanam pohon *setiap 10 meter*.

試験のとき *１５分おきに* 経ったと先生は報告します。
_Shiken no toki *juugo-fun oki ni* tatta to sensei wa houkoku shimasu._
= Ketika ujian, guru akan melapor *setiap 15 menit* berlalu.

=======================
Jika digunakan pada hitungan waktu yang dapat dihitung satu per satu misalnya jumlah hari, maka maknanya adalah menyisakan jumlah hari tersebut di antara setiap kejadian.
Contoh: 
*３日おきに*
_mikka oki ni_

Ini bukan berarti setiap 3 hari: Hari ke-3, 6, 9, dst...

1,2,3️⃣,4,5,6️⃣,7,8,9️⃣,10,11

Melainkan *setiap lewat 3 hari*: Hari ke-4, 8, 12
Dengan kata lain, "setiap 4 hari"

1,2,3,4️⃣,5,6,7,8️⃣,9,10,11,...
(menyisakan 3 hari di antaranya)

📺 *Contoh Kalimat:*
この用紙には *１行おきに* 書いてください。
_Kono youshi ni wa *ichi-gyou oki ni* kaite kudasai._
= Tolong tulis *setiap 2 baris* di kertas ini.
(Menyisakan 1 baris di antaranya)

彼はうちで *一日おきに* お酒を飲みます。
_Kare wa uchi de *ichinichi oki ni* osake o nomimasu._
= Dia minum sake *tiap dua hari* di rumah.

そね会議は *二年おきに* 開かれます。
_Sono kaigi wa *ni-nen oki ni* akaremasu._
= Rapat itu dibuka *setiap tiga tahun*.
_____________________________
7-3-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "49") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ ~ごとに goto ni ☆

Makna: setiap, tiap, setiap kali

Pola kalimat *~ごとに goto ni* digunakan untuk menunjukkan waktu yang berulang, atau menunjuk ke tiap sesuatu, atau menunjukkan keterangan tiap kali sesuatu terjadi.

Rumus:
• [rentang waktu] + ごとに
• [kata benda] + ごとに
• [kata kerja] + ごとに

📺 *Contoh Kalimat*
オリンピックは *4年ごとに* 開催される。
_Orimpikku wa *4-nen goto ni* kaisai sareru._
= Olimpiade diadakan *tiap 4 tahun.*

彼女は *一分ごとに* 時計をチェックする。
_Kanojo wa *ippun goto ni* tokei o chekku suru._
= Dia selalu memeriksa jamnya *tiap satu menit.*

彼は彼女に *土曜日ごとに* 会っている。
_Kare wa kanojo ni *doyoubi goto ni* atte iru._
= Dia bertemu pacarnya *tiap Sabtu.*

彼は会う *人ごとに* 話しかけた。
_Kare wa au *hito goto ni* hanashikaketa._
= Dia berbincang dengan/menyapa *setiap orang* yang ia temui.

*列車が到着するごとに* ホームは人で溢れている。
_*Ressha ga touchaku suru goto ni* hoomu wa hito de afurete iru._
= *Setiap kali kereta tiba*, peronnya dibanjiri orang.

*僕に会うごとに* あの子は嬉しそうに挨拶します。
_*Boku ni au goto ni* ano ko wa ureshisou ni aisatsu shimasu._
= *Setiap kali bertemu denganku* anak itu menyapaku dengan tampang bahagia.
_____________________________
12-3-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "50") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel の No ☆
◇ Penunjuk Kepemilikan ◇

*Partikel の (no)* dapat digunakan untuk menunjukkan kepemilikan.
Rumusnya yaitu:
_pemilik の yang dimiliki_

Jadi terbalik di dalam bahasa Indonesia dimana yang dimiliki dulu yang disebutkan lalu pemiliknya, dan di antaranya diletakkan partikel の no.

*Contoh:*
*私の* 本
_*watashi no* hon_
= buku *saya*

*彼女の* 猫
_*kanojo no* neko_
= kucing *nya* (miliknya)

*お父さんの* 車
_*otousan no* kuruma_
= mobil *ayah*

Partikel の No dapat menghubungkan lebih dari 2 kata untuk menunjukkan kepemilikan. Contoh:

彼の友達の家
_Kare no tomodachi no ie_
= Rumah temannya
_______________________
22-3-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "51") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Kata Kerja Pasif ☆

*Bentuk pasif* adalah bentuk kata kerja yang menunjukkan suatu aksi dilakukan terhadap subjekya.
Contohnya di bahasa Indonesia adalah kata kerja yang berawalan di-.
(dimakan, ditutup, dilempar, dll...)

Di dalam bahasa Jepang, untuk membuat bentuk kata kerja pasif kita mengikuti pola, yang tergantung pada tiap kelompok kata kerja.

1️⃣ *Kata Kerja U*
Ubah huruf terakhir kata kerja ke bunyi A. Lalu tambahkan れるreru.

• 読む yomu (membaca)
[ 読ま yoma + れるreru ]
*= 読まれる yomareru (dibaca)*

• 書く kaku (menulis)
*= 書かれる kakareru (ditulis)*

• 待つ matsu (menunggu)
*= 待たれる matareru (ditunggu)*

Khusus kata kerja yang berakhiran うu diubah menjadi わwa.
• 買う kau (membeli)
*= 買われる kawareru (dibeli)*

2️⃣ *Kata Kerja RU*
Ubah akhiran るru menjadi られるrareru.

• 食べる taberu (memakan)
*= 食べられる taberareru (dimakan)*

• 教える oshieru (mengajar)
*= 教えられる oshierareru (diajar)*

3️⃣ *Kata Kerja Pengecualian*
• する suru (melakukan)
*= される sareru (dilakukan)*

• 来る kuru (datang)
*= 来られる korareru*

❇️ Bentuk pasif sendiri termasuk kelompok kata kerja RU, jadi adapun perubahan bentuk selanjutnya mengikuti kata kerja RU.
• 飲まれる nomareru (diminum)
》飲まれた nomareta (bentuk lampaunya)

📺 *Contoh Kalimat*
Untuk kata kerja pasif, dapat menggunakan partikel にni  untuk menunjuk ke pelakunya (dapat diterjemahkan jadi "oleh")

• 私は彼女に見られた。
  _Watashi wa kanojo ni mirareta._
= Aku dilihat oleh dia.

• 弟は蜂に刺された。
  _Otouto wa hachi ni sasareta._
= Adik saya disengat lebah.

• ウサギはトラに食べられる。
   _Usagi wa tora ni taberareru._
= Kelinci akan dimakan oleh harimau.

*Pasif Tak Langsung*
Kata kerja pasif masih bisa mempunyai objek langsung yang ditandai dengan partikel をo/wo. Ini menunjukkan bahwa si subjek bukan mendapat perlakuan langsung, tetapi tetap kena dampaknya.

• 外国人に質問を聞かれました。
  _Gaikokujin ni shitsumon o kikaremashita._
= Saya ditanyakan sebuah pertanyaan oleh orang asing.
[Yang ditanyakan adalah "pertanyaan", tetapi "saya" di sini tetap ikut menerima perlakuan tersebut, karena kepada "saya" pertanyaan tersebut ditanyakan]

• 私は誰かに足を踏まれた。
   _Watashi wa dareka ni ashi o fumareta._
= Kaki saya diinjak seseorang.
("Saya" mendapat perlakuan "diinjak di kaki")
_____________________________
27-3-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "52") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ ~たびに Tabi Ni ☆

Makna: setiap, setiap kali

Pola kalimat *~たびに tabi ni* digunakan untuk membuat keterangan setiap kali sesuatu terjadi.

⚙️ *Rumus*
[kata kerja] + たびに
[kata benda] + の no + たびに

📺 *Contoh Kalimat*
*この曲を聞くたびに* 家族を思い出す。
_*Kono kyoku o kiku tabi ni* kazoku o omoidasu._
= *Setiap kali aku mendengarkan lagu ini* aku teringat dengan keluargaku.

*買い物のたびに* 袋をたくさんもらう。
_*Kaimono no tabi ni* fukuro o takusan morau._
= *Setiap belanja* saya selalu dapat banyak kantong belanja.

彼らは *顔をあわせるたびに* 喧嘩する。
_Karera wa *kao o awaseru tabi ni* kenka suru._
= Mereka *setiap kali berhadapan satu sama lain* selalu berkelahi.

*誕生日のたびに* 盛大なパーティーをやります。
_*Tanjoubi no tabi ni* seidai na paatii o yarimasu._
= *Setiap kali ulang tahun* aku selalu merayakan pesta yang meriah.

*帰国するたびに* 日本にいる友達にプレゼントを買ってあげます。
_*Kikoku suru tabi ni* nihon ni iru tomodachi ni purezento o katte agemasu._
= *Tiap kali pulang ke negaraku* saya membelikan hadiah untuk teman-teman saya di Jepang.

*健康診断のたびに* 太りすぎだと言われる。
_*Kenkoushinda no tabi ni* futorisugi da to iwareru._
= *Setiap kali periksa kesehatan* katanya dia kegemukan.
_____________________________
16-3-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "53") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *会話 Kaiwa* • Percakapan ⭐
☆ Bahasa Singkat ☆

Di dalam percakapan bahasa Jepang terutama perkataan yang diucapkan cepat terkadang ada kata-kata yang terdengar menjadi lebih pendek karena diucapkan cepat. Berikut ini beberapa contoh di antaranya:

• これは kore wa
   --> こりゃ korya

• すみません sumimasen
  --> すいません suimasen

• それは sore wa 
    --> そりゃ sorya

• ~ていく -te iku
   --> ~てく -teku

• ~ています -te imasu
   --> ~てます -temasu

• ~ている -te iru
   --> ~てる -teru

• ~ていった -te itta
   --> ~てった -tetta

• ~ておいた -te oita
   --> ~といた -toita

• ~ておきます -te okimasu
   --> ~ときます -tokimasu

• ~ておく -te oku
   --> ~とく -toku

• ~てしまう -te shimau
   --> ~ちゃう -chau

• ~てしまった -te shimatta
   --> ~ちゃった -chatta

• ~ては -te wa --> ~ちゃ -cha

• といえば to ieba
    --> ってば tteba

• という to iu 
    --> って tte/っつ ttsu

• ~なければ nakereba
  --> ~なきゃ -nakya

• 何か nanika 
   --> なんか nanka

• のだ/のです no da/no desu 
   --> んだ/んです nda/ndesu

• ~らない -ranai 
   --> ~んない -nnai

• ~られる -rareru (bentuk potensial)
   --> ~れる -reru

• ~るの -runo --> ~んの -nno

• じゃない janai (di akhir kalimat)
   --> じゃん jan

• じゃない janai
   --> じゃねえ janee

• ~でしまう -de shimau
   --> ~じゃう -jau

• ~でしまった -de shimatta
   --> ~じゃった -jatta

• です desu --> っす ssu

• では de wa --> じゃ ja
_____________________________
1-4-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "54") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *言葉の違い Kotoba No Chigai* • Perbedaan Kata ⭐
☆ 勉強する、学ぶ、習う ☆
◇ Benkyou Suru, Manabu, Narau ◇

Ketiga kata ini bermakna "belajar". Namun apakah perbedaannya?

🍀 *習う Narau* yang paling dapat dibedakan dari dua lainnya. Narau berarti belajar dari seseorang dengan cara diajari. Dengan kata lain *narau = berguru*.
Contoh Kalimat:
• 来年私はフランス語を習います。
   _Rainen watashi wa furansu-go o *naraimasu.*_
= Tahun depan saya *belajar* (ikut kursus/berguru) bahasa Prancis.

🍀 *勉強する Benkyou Suru* adalah kata yang bermakna "belajar" yang biasanya dipelajari pertama di bahasa Jepang. Benkyou suru  bermakna kegiatan belajar yang konteknya bisa berarti mempelajari suatu mata pelajaran, atau belajar untuk ujian.
Contoh Kalimat:
• 多くの学生が図書館で *勉強している。*
   _Ooku no gakusei ga toshokan de *benkyou shite iru.*_
= Banyak siswa yang *sedang belajar* di perpustakaan.

🍀 *学ぶ Manabu* juga bermakna "belajar" tetapi maknanya lebih luas. Biasanya berkaitan dengan ilmu, wawasan, keterampilan, pengalaman atau informasi baru yang sedang dipelajari.
Contoh Kalimat:
• 人は経験から *学ぶ。*
  _Hito wa keiken kara *manabu.*_
= Orang *belajar* dari pengalamannya.

• 生け花を *学び* 始めたばかりです。
   _Ikebana o *manabi* hajimeta bakari desu._
= Saya baru mulai *belajar* _ikebana_ (seni merangkai bunga).

• 諸君は英語を *学ぶ* ところですか。
   _Shokun wa eigo o *manabu* tokoro desu ka._
= Apakah kalian baru akan *belajar* bahasa Inggris?

_____________________________
6-4-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "55") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ 形容詞 ☆
◇ Kata Sifat ◇

Kata sifat yaitu kata yang memberi keterangan sifat dari suatu kata benda. Contoh:
• 長い _nagai_ = panjang
• 上手 _jouzu_ = pandai/mahir
• 寒い _samui_ = dingin
• ばか _baka_  = bodoh
• いい _ii_         = baik/bagus
• 静か _shizuka_ = sepi
Dan lain-lain...

Kata sifat ada 2 jenis: *kata sifat i* dan *kata sifat na*

🔵 *Kata Sifat I*
Yaitu yang berakhiran い (i). Contoh di atas adalah *長い nagai* (panjang), *寒い samui* (dingin) dan *いいii* (bagus).

🔴 *Kata Sifat NA*
Yaitu selain yang berakhiran I, contoh di atas *上手 jouzu* (mahir), *ばか baka* (bodoh), dan *静か shizuka* (sepi).

⚠️ Catatan
Pengecualian: Ada beberapa  kata sifat NA yang berakhiran い (i), tetapi tetap masuk dalam kata sifat NA. Misalnya: *きれい kirei* (cantik), *嫌い kirai* (dibenci).

🧩 *Penggunaan*
● Jika digunakan sebagai predikat kalimat, yaitu ketika menjelaskan sifat sesuatu, maka kata sifatnya hanya tinggal digunakan.

Contoh:
• この部屋は *静か*
   _kono heya wa *shizuka*_
   Ruangan ini *sepi.*
• あの鞄は *白い*
   _ano kaban wa *shiroi*_
   Tas itu *(berwarna) putih.*

● Kata sifat NA penggunaannya sama dengan kata benda. Contoh:
• Positif: 
   上手(だ) jouzu (da)
   上手です jouzu desu
• Negatif: 
   上手ではない jouzu dewa nai
   上手ではありません jouzu dewa arimasen
• Lampau:
   上手だった jouzu datta
   上手でした jouzu deshita
• Negatif Lampau:
   上手ではなかった jouzu dewa nakatta
   上手ではありませんでした jouzu dewa arimasen deshita

● Untuk Kata Sifat I ada aturan bentuknya. Contoh:
• Positif: 
  寒い samui
• Negatif: Ubah akhiran *-i* menjadi *-kunai*.
  寒くない samukunai
• Lampau: Ubah akhiran *-i* menjadi *-katta*.
  寒かった samukatta
• Negatif Lampau: Ubah akhiran *-i* menjadi *-kunakatta*.
  寒くなかった samukunakatta

_*Khusus* kata sifat いい ii (baik), untuk mengubah bentuknya harus gunakan bentuk aslinya yaitu 良い yoi. Sehingga jika diubah akan menjadi 良くない yokunai, 良かった yokatta, 良くなかった yokunakatta._

Bentuk sopan kata sifat i hanya perlu menambahkan です desu.

● Jika disambung ke kata benda, kata sifat i hanya perlu disambungkan sebelum kata benda.
• 長い 鉛筆
  _*nagai* enpitsu_
   pensil yang *panjang*
• 寒い 天気
  _*samui* tenki_
  cuaca yang *dingin*

● Untuk kata sifat NA, perlu menambahkan な (na) setelah kata sifatnya, untuk yang bentuk positif saja.
• 上手 な 人
   *jouzu na* hito
   orang yang *mahir*
• ばか な 人
   *baka na* hito
   orang yang *bodoh*

Ketika menghubungkan kata sifat dan kata benda seperti ini jangan gunakan bentuk sopan.
❌ ~上手ではありません人~
~jouzu dewa arimasen hito~

✅ 上手ではない人
jouzu dewa nai hito

_____________________________
11-4-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "56") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ ~ていく dan ~てくる ☆

Di dalam bahasa Jepang ada pola kalimat ~ていく te iku dan ~てくる te kuru.

いく iku sendiri berarti "pergi", dan くる kuru berarti "datang".

Makna dari pola-pola tersebut yaitu:

💥 *Melakukan sesuatu kemudian pergi/datang*
Pola kalimat ini tidak menunjukkan makna khusus dari keseluruhan kata ていくte iku / てくる te kuru. Hanya bermakna urutan kata kerja menggunakan bentuk てte.
Contoh:
• シャワーを *浴びて行く。*
_Shawaa o *abite iku.*_
= *Mandi* (shower) *lalu pergi.*

• 食べ物を *買って来る。*
_Tabemono o *katte kuru*._
= *Beli* makanan *lalu datang.*

💥 *Menunjukkan arah gerakan menjauh/mendekat*
Pola kalimat ini dapat digunakan untuk memberi arah suatu gerakan, jika menggunakan いくiku  artinya menjauh (karena pergi), dan jika menggunakan くるkuru artinya mendekat (karena datang).
Contoh:
• カラスが *飛んでいく。*
_Karasu ga *tonde iku.*_
= Burung gagak *terbang.* (menjauh)

• 彼は教室から *出てくる。*
_Kare wa kyoushitsu kara *dete kuru*._
= Dia *keluar* dari kelas. (menuju kemari)

💥 *Menunjukkan perubahan*
Penggunaan pola ini adalah yang paling rumit dipahami para pelajar. Pola ini dapat menunjukkan perubahan yang terjadi (biasanya menggunakan kata "semakin") dan berdampak tertentu dari sudut pandang kita.
• ていく te iku : jika kita melihat dampak suatu perubahan secara objektif (tidak melibatkan perasaan pribadi dan tidak menekankan dampaknya kepada kita sendiri)
Contoh:
• アンディは日本語が上手に *なっていく。*
_Andi wa nihongo ga jouzu ni *natte iku*._
= Andi *jadi semakin* mahir berbahasa Jepang.
(kita melihat hal ini secara objektif, tidak ada dampak tertentu bagi diri kita)

• てくる te kuru sebaliknya, yaitu jika kita melihat suatu perubahan secara subjektif (melibatkan perasaan pribadi dan menekankan dampaknya ke kita)
Contoh:
• 天気がだんだん 暑く *なってくる。*
_Tenki ga dandan atsuku *natte kuru.*_
= Cuacanya secara bertahap *semakin menjadi* panas.
(Kita melihat ini secara subjektif dan merasakan dampaknya, yaitu kita merasa kepanasan)

Jika menggunakan bentuk lampau maka perubahannya terjadi di mulai dari waktu yang lalu hingga sekarang.
• 上手に *なっていった。*
_Jouzu ni *natte itta.*_
*Semakin jadi* pandai.
(mulai dulu hingga sekarang)

• 暑く *なってきた。*
_Atsuku *natte kita.*_
= *Semakin jadi* panas.
(mulai dulu hingga sekarang)

_____________________________
16-4-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "57") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel を o/wo ☆
◇ Penanda Objek ◇

Di dalam kalimat, biasanya kata kerja ada yang menggunakan *objek*. Objek adalah sesuatu yang dikenai suatu pekerjaan atau aksi. Misalnya: _Saya makan *apel*._ Kata "apel" di sini berperan sebagai objek dari kata kerja "makan".

Di dalam bahasa Jepang, kata yang menjadi objek diberi tanda objek, yaitu dengan partikel を o (atau "wo") setelah objek itu. Ingat, kata kerja bahasa Jepang normalnya diletakkan di akhir, sehingga objek pun disebutkan lebih dulu baru kata kerjanya.

📺 Contoh:
• 私は *リンゴを* 食べます。
  _Watashi wa *ringo o* tabemasu._
= Saya makan *apel*.

• 母は *手紙を* 書いた。
   _Haha wa *tegami o* kaita._
= Ibu menulis *surat*.

💡 *Partikel を Untuk Kata Kerja Pergerakan*
Kata kerja yang berupa pergerakan seperti 行く iku (pergi), 歩く aruku (berjalan), 登る noboru (mendaki), 飛ぶ tobu (terbang), dll... dapat menggunakan objek, dengan makna objek ini dilewati/dilalui dengan gerakan tersebut.

Contoh:
• 鳥が *空を* 飛びました。
  _Tori ga *sora o* tobimashita._
= Burung terbang melintasi *langit*.

• *町を* 散歩する。
   _*Machi o* sanpo suru._
= Jalan-jalan di sepanjang *kota*.

_____________________________
20-4-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "58") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Pola Kalimat: 上で Ue De ☆

上 ue sendiri berarti "atas" dan 上で ue de berarti "di atas", namun kata ini bisa digunakan dalam konteks lain selain untuk makna "di atas".

🌍 *Makna 1:* Yang terutama/terpenting dalam/ketika/sebelum ...

Makna ini yang paling dekat dengan kata "atas" karena menunjukkan sesuatu yang penting atau utama (di atas sesuatu)

Biasanya cukup diartikan *ketika* / *sebelum* / *untuk* / *dalam*, dan menunjukkan sesuatu yang penting dilakukan ketika/sebelum/untuk/dalam melakukan sesuatu yang lain.

Rumus:
• kata kerja + 上で ue de
• kata benda + の上で no ue de

Contoh:
• *外国語を勉強する上で* 辞書はなくてはならないものだ。
_*Gaikokugo o benkyou suru ue de* jisho wa nakute wa naranai mono da._
= *Untuk belajar bahasa asing,* kamus adalah sesuatu yang harus dimiliki. 

• *生きる上で*、一番大切なものはなに?
_*Ikiru ue de,* ichiban taisetsu na mono wa nani?_
= *Dalam hidup*, hal apa yang terpenting?

• コミュニケーションは *仕事の上で* 重要です。
_Komyunikeeshon wa *shigoto no ue de* juuyou desu._
= Komunikasi itu penting *dalam pekerjaan.*

• テレビは *外国語の勉強の上で* かなり役に立つ。
_Terebi wa *gaikokugo no benkyou no ue de* kanari yaku ni tatsu._
= Televisi cukup berguna *untuk pembelajaran bahasa asing.*
=======================

🌏 *Makna 2:* Setelah ..., jika sudah ...
Makna ini kelihatannya berkebalikan dengan makna 1, karena sesuatu itu dilakukan setelah sesuatu yang lain.
Tetapi dalam konteks ini, ada kesan seperti "persyaratan", atau sesuatu yang perlu dilakukan lebih dulu, untuk menentukan sesuatu setelahnya bisa dilakukan atau tidak.

Rumus:
• kata kerja たta + うえで ue de
• kata benda + のうえで no ue de

Catatan:
Makna yang ini tidak dituliskan dengan kanji, hanya hiragana (うえで)
Partikel でde nya kadang-kadang tidak disebutkan. (Hanya うえ ue)

Contoh:
• この薬は *説明書を読んだうえで*、ご使用ください。
_Kono kusuri wa *setsumeisho o yonda ue de*, goshiyou kudasai._
= Silakan gunakan obat ini *setelah membaca petunjuk pemakaiannya.*

☆ アパートは *部屋の中をみたうえで* 買うかどうかを決めたい。
_Apaato wa *heya no naka o mita ue de* kau ka dou ka o kimetai._
= Saya ingin memutuskan membeli atau tidak apartemen ini *setelah saya melihat isi ruangannya.*

• *家族と相談のうえで*、決めます。
_*Kazoku to soudan no ue de*, kimemasu._
= Saya akan memutuskan itu *setelah berdiskusi dengan keluarga.*

• *この書類に署名のうえ*、窓口に提出してください。
_*Kono shorui ni shomei no ue,* madoguchi ni teishutsu shite kudasai._
= *Jika sudah menandatangani dokumen ini,* silakan bawa ke konter.
_____________________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "59") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *単語 Tango* • Kosakata ⭐
☆ Kata Sifat NA berakhiran I ☆

Seperti yang kita ketahui bahwa tidak semua kata sifat yang berakhiran い i dapat dikategorikan ke dalam kata sifat i. Beberapa masuk dalam kata sifat なna.

Sebenarnya untuk membedakannya, kita hanya perlu melihat kanjinya. Jika dituliskan dalam full kanji, tidak akan tertulis akhiran いi dengan hiragana jika dia adalah kata sifat NA. Tetapi beberapa ada juga yang tetap berakhiran いi hiragana.

Berikut adalah contoh-contohnya:

• 曖昧 aimai     - ambigu
• 安易 an'i - mudah, sederhana
• 安静 ansei     - tenang
• 安定 antei      - stabil
• 案外 angai - tak terduga, mengejutkan
• 一定 ittei        - tetap
• 一生懸命 isshoukenmei - sekuat tenaga, sebisa mungkin
• 意外 igai        - tak terduga
• 偉大 idai        - agung
• 一杯 ippai     - penuh
• 寛大 kandai - toleran, open-minded
• 嫌い kirai       - dibenci
• 綺麗 kirei       - indah, cantik
• 軽快 keikai   - ringan
• 賢明 kenmei - bijak
• 懸命 kenmai - bersemangat, bertekad
• 健在 kenzai  - sehat
• 光栄 kouei   - terhormat
• 公正 kousei   - adil
• 広範囲 kouhan'i = luas, mencakup banyak
• 公平 kouhei   - adil
• 広大 koudai  - luas
• 滑稽 kokkei  - lucu, lawak
• 巨大 kyodai   - raksasa
• 最低 saitei - terendah, terburuk
• 幸い saiwai - bahagia, beruntung
• 神聖 shinsei - suci
• 心配 shinpai  - khawatir
• 水平 suihei    - datar
• 盛大 seidai - berkekuatan besar
• 繊細 sensai - halus, lemah
• 壮大 soudai - mengagumkan
• 詳細 shousai - rinci
• 大抵 taitei     - biasanya
• 丁寧 teinei    - sopan
• 透明 toumei  - transparan
• 得意 tokui     - berhasil, sejahtera
• 多大 tadai   - sangat banyak
• 著名 chomei - diketahui dengan baik
• 反対 hantai    - berlawanan
• 不安定 fuantei - tidak stabil
• 不意 fui        - tiba-tiba
• 不快 fukai - tidak menyenangkan
• 不公平 fukouhei - tidak adil
• 不正 fusei     - tidak adil
• 不平 fuhei    - tidak puas
• 不明 fumei  - tidak jelas
• 不愉快 fuyukai - tidak menyenangkan
• 平静 heisei  - tenang
• 未定 mitei - tidak tetap, tidak pasti
• 無関係 mukankei - tidak berhubungan
• 厄介 yakkai - membebani, menjadi masalah
• 優勢 yuusei  - berkuasa
• 有名 yuumei  - terkenal
• 有害 yuugai  - berbahaya
• 雄大 yuudai - agung
• 愉快 yukai  - menyenangkan
• 容易 youi - sederhana, mudah
• 余計 yokei  - berlebihan
• 冷静 reisei  - tenang, sejuk
• 論外 rongai - tidak mungkin
• 自在 jizai     - sesuka hati
• 重大 juudai - serius, penting
• 純粋 junsui - murni
• 忠誠 chuusei - setia
• 莫大 bakudai - besar, kolosal
• 無礼 burei - kasar, tidak sopan
• 膨大 boudai - besar, luas, kolosal

_____________________________
27-4-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "60") {
		conn.sendMessage(
			m.chat,
			{
				text: `*文法 Bunpou* • Tata Bahasa
*Partikel に NI ࿐໋*
◇ Penanda Target/Tujuan ◇

Beberapa kata kerja dalam bahasa Jepang memerlukan kata target. Apa yang dimaksud target? Berikut penjelasannya:

*1) Lokasi Akhir Pergerakan*
Misalnya kata 行く iku (pergi), jika kita ingin memberi keterangan tempatnya, maka kita gunakan partikel に ni di belakang tempat tujuannya. Contoh:
• *学校に* 行く
   _*gakkou ni* iku_
  pergi *ke sekolah*

Kata kerja lain yang berupa pergerakan:
• 来る kuru (datang)
• 帰る kaeru (pulang)
• 歩く aruku (berjalan)
• 走る hashiru (berlari)
• 登る noboru (mendaki, menaiki)
• 飛ぶ tobu (terbang)
• 散歩する sanpo suru (jalan-jalan)

*2) Target Pemberian*
Ketika kata kerjanya berupa pemberian/pengiriman/penunjukkan tentunya untuk memperjelas ke mana arah pemberian/penunjukkannya kita gunakan juga partikel に NI.
Contoh:
• *弟に* お菓子をあげる
   _*otouto ni* okashi o ageru_
   memberi snack *kepada adik*

• *先生に* 聞く
   _*sensei ni* kiku_
   bertanya *kepada guru*

• *カバンに* 鉛筆を入れる
  _*kaban ni* enpitsu o ireru_
  memasukkan pensil *ke (dalam) tas*

*3) Lokasi Kata Kerja Keberadaan*
Kata kerja keberadaan contohnya いる iru / ある aru (ada), dan 住む sumu (tinggal). Untuk memberi keterangan lokasi keberadaannya kita gunakan partikel にni.
• 本は *本棚に* ある
  _hon wa *hondana ni* aru_
  buku ada *di rak buku*

• 母は *台所に* いる
  _haha wa *daidokoro ni* iru_
  ibu ada *di dapur*
 
_____________________________
2-5-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "61") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *単語 Tango* • Kosakata ⭐
☆ Angka Besar ☆

十        juu                puluh
百        hyaku          ratus 
千        sen               ribu

万        man             puluh ribu
十万    juuman        ratus ribu
百万    hyakuman   juta
千万    senman       puluh juta

億        oku              ratus juta
十億    juuoku         milyar
百億    hyakuoku    puluh milyar
千億    sen'oku       ratus milyar

兆        chou            triliun

_____________________________
3-5-21 | 🇯🇵 Belajar Nihongo`,
			},
			{ quoted: fverif },
		);
	} else if (text === "62") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *単語 Tango* • Kosakata ⭐
☆ Kata Kerja ☆
◇ Level JLPT N5 ◇

*Kelompok 1: Kata Kerja U*
会う au .......... bertemu
開く aku ......... terbuka
遊ぶ asobu ..... bermain
洗う arau ........ mencuci
歩く aruku ...... berjalan
言う iu ............ berkata
行く iku .......... pergi
要る iru ........... perlu
歌う utau ........ bernyanyi
売る uru ......... menjual
置く oku ......... menaruh
押す osu ......... menekan
泳ぐ oyogu ..... berenang
終わる owaru ... selesai
買う kau ......... membeli
返す kaesu .. mengembalikan
帰る kaeru ...... pulang
書く kaku ...... menulis
貸す kasu ...... meminjamkan
聞く kiku ......... bertanya
切る kiru ......... memotong
消す kesu .. menghapus/memadamkan
困る komaru ... kesulitan
曇る kumoru ... menggelap
咲く saku ....... mekar
差す sasu .. mengangkat (payung)
死ぬ shinu ...... mati
閉まる shimaru ... tertutup
知る shiru ....... tahu
吸う suu .. menghirup/mengisap
住む sumu ...... tinggal
座る suwaru ... duduk
立つ tatsu ....... berdiri
頼む tanomu ... memohon
違う chigau .... berbeda/lain
使う tsukau ... menggunakan
着く tsuku ...... tiba
作る tsukuru ... membuat
止まる tomaru ... berhenti
取る toru ......... mengambil
撮る toru .. mengambil (foto)
飛ぶ tobu .. terbang/melompat
鳴く naku .. berbunyi (hewan)
無くす nakusu ... kehilangan
習う narau ......... berguru
並ぶ narabu ....... berbaris
脱ぐ nugu .. melepaskan (pakaian)
飲む nomu ......... minum
乗る noru .. naik (kendaraan)
登る noboru .. mendaki/memanjat
入る hairu ....... masuk
走る hashiru ... berlari
働く hataraku ... bekerja
話す hanasu ... berbicara
貼る haru ....... menempelkan
始まる hajimaru ... mulai
引く hiku ......... menarik
弾く hiku ... memainkan (alat musik)
吹く fuku ........ bertiup
降る furu ........ turun (hujan)
待つ matsu ..... menunggu
曲がる magaru ... berbelok
磨く migaku ... menggosok
持つ motsu .. membawa, memegang, memiliki
休む yasumu ... istirahat
読む yomu ...... membaca
呼ぶ yobu ....... memanggil
分かる wakaru ... paham
渡す watasu .. mengoper, menyerahkan
渡る wataru .. menyeberang
出す dasu ...... mengeluarkan

*Kelompok 2: Kata Kerja RU*
開ける akeru .. membuka
上げる ageru .. memberi
いる iru .. ada (makhluk hidup)
入れる ireru .... memasukkan
生まれる umareru .. lahir
起きる okiru ... bangun
教える oshieru ... mengajar
降りる oriru .... turun
借りる kariru ... meminjam
消える kieru .... menghilang
着る kiru ......... mengenakan
答える kotaeru .. menjawab
閉める shimeru .. menutup
締める shimeru .. mengikat
食べる taberu ..... makan
疲れる tsukareru .. lelah
勤める tsutomeru .. melayani
並べる naraberu .. menyusun
晴れる hareru .... cerah
見える mieru ..... terlihat
見せる miseru .. menunjukkan/memperlihatkan
忘れる wasureru ... lupa
出かける dekakeru .. pergi keluar
出る deru ........ keluar

_____________________________
4-5-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "63") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel へ e ☆
◇ Penanda Arah ◇

Partikel へ e (dituliskan dengan huruf "he") adalah partikel yang digunakan untuk menunjukkan arah. Biasanya langsung di artikan "ke" atau "menuju".

Penggunaannya cukup jelas yaitu untuk kata kerja pergerakan.

📺 Contoh:
• *東京へ* 行く
   _*toukyou e* iku_
   pergi *ke Tokyo*

• *家へ* 帰る
  _*ie e* kaeru_
  pulang *ke rumah*

• *南へ* 向かう
  _*minami e* mukau_
  mengarah *ke selatan*

💡 *Perbedaan dengan Partikel に?*
Untuk menunjukkan arah pergerakan に ni dan へ e sama saja, jadi selain yang menunjukkan arah pergerakan, へ e tidak bisa dipakai. Adapun yang mana yang lebih umum dipakai, adalah partikel に ni, karena へ e ada kesan sedikit lebih formal. Jadi sering dipakai juga dalam judul (film/manga) atau lagu.

_____________________________
6-5-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "64") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel と TO ☆
◇ Penanda Kata Pendamping ◇

Partikel と salah satu fungsinya adalah menunjukkan suatu kata yang menjadi pendamping kata lain, atau biasa diterjemahkan menjadi "dengan", atau "bersama".

📺 *Contoh:*
• *友達と* 勉強する
  _*tomodachi to* benkyou suru_
= belajar *bersama teman*

• ユキは *イチロと* 結婚します。
  _Yuki wa *Ichiro to* kekkon shimasu._
= Yuki akan menikah *dengan Ichiro.*

• 太郎は *花子と* 遊んでいる。
  _Tarou wa *Hanako to* asonde iru._
= Tarou sedang bermain *bersama Hanako.*

• 彼女は *彼氏と* 話した。
  _Kanojo wa *kareshi to* hanashita._
= Dia berbicara *dengan pacarnya.*

_____________________________
11-5-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "65") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel で DE ☆
◇ Penunjuk Alat dan Lokasi  dan lain-lain ◇

Partikel で de memiliki beberapa fungsi. Di sini akan dijelaskan fungsi-fungsi seperti yang tertera di judul.

Fungsi partikel でde yang umum adalah penunjuk alat dan lokasi:

⚽ *Penunjuk Alat*
Partikel でde dapat dipakai untuk menunjukkan alat yang digunakan pada suatu kegiatan maupun bahan yang dipakai. Di sini dapat diartikan "dengan" atau "menggunakan".
Rumus:
[kata benda] + でde

Contoh:
• *お箸で* 食べる
  _*ohashi de* taberu_
  makan *dengan sumpit*

• *自転車で* 学校へ行く
  _*jitensha de* gakkou e iku_
  pergi ke sekolah *dengan sepeda*

• *鉛筆で* 書く
  _*enpitsu de* kaku_
  menulis *dengan pensil*

 🏀 *Penunjuk Lokasi*
Partikel で dapat dipakak untuk menunjukkan lokasi dilakukannya suatu kegiatan. Di sini dapat diartikan "di".
Rumus:
[lokasi] + でde

Contoh:
• *庭で* 遊ぶ
  _*niwa de* asobu_
  bermain *di kebun*

• *部屋で* 勉強する
   _*heya de* benkyou suru_
   belajar *di kamar*

• *レストランで* 食べる
   _*resutoran de* taberu_
   makan *di restoran*

Fungsi-fungsi lain partikel で yaitu menunjuk jangka waktu/harga barang/bahan/alasan/dll (mengikuti fungsi sebagai penunjuk alat atau bahan yang diperlukan untuk melakukan sesuatu atau untuk terjadinya sesuatu).

Untuk memudahkan pemahaman, bisa kita kaitkan dengan makna *"dengan".*

Jangka waktu:
*一週間で* できる
_*isshuukan de* dekiru_
bisa dilakukan *dalam seminggu* (dengan batas waktu seminggu)

Harga:
*１０ドルで* 買う
_*juudoru de* kau_
membeli *seharga 10 dolar* (dengan harga 10 dolar)

Bahan:
*粘土で* 作る
_*nendo de* tsukuru_
membuat *dari tanah liat* (dengan bahan tanah liat)

Sebab/Alasan:
*病気で* 行かない
_*byouki de* ikanai_
tidak pergi *karena sakit* (dengan alasan sakit)

Jumlah Orang:
*三人で* 働く
_*sannin de* hataraku_
bekerja *bertiga* (dengan pelaku tiga orang)

Cakupan (Batas):
*日本で* 一番いい
_*nihon de* ichiban ii_
terbaik *di Jepang* (dengan batas di dalam Jepang)

_____________________________
19-5-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "66") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Bentuk てte ☆
◇ Bentuk Sambung ◇

Bentuk てte adalah bentuk kata kerja yang berakhiran huruf てte (atau でde) yang fungsinya umumnya adalah untuk menyambungkannya ke kalimat berikutnya.

Bentuk てte sama cara membentuknya dengan bentuk たta.

⚙️ *Pembentukan*
Untuk membentuknya tergantung pada kelompok kata kerja:

*1) Kata Kerja うu*
==============
Ubahlah akhiran-akhiran kata kerjanya sesuai dengan di bawah ini:
• うu/つtsu/るru --> *ってtte*
• ぶbu/ぬnu/むmu --> *んでnde*
• くku --> *いてite*
• ぐgu --> *いでide*
• すsu --> *してshite*

Contoh:
• 書く kaku (menulis)
--> 書いて kaite
• 読む yomu (membaca)
--> 読んで yonde
• 待つ matsu (menunggu)
--> 待って matte

Khusus: 行く iku (pergi)
--> 行って itte

*2) Kata Kerja るru*
===============
Ubahlah akhiran るru pada kata kerja langsung menjadi てte.

Contoh:
• 食べる taberu (makan)
--> 食べて tabete
• 見る miru (melihat)
--> 見て mite

*3) Kata Kerja Khusus*
=================
Dua kata kerja ini punya bentuk てte khusus:
• する suru (melakukan)
--> して shite
• 来る kuru (datang)
--> 来て kite

🔧 *Fungsi*
Fungsi yang pertama dari bentuk てte ini adalah untuk menyambungkan kalimat ke kalimat lain.

*漫画を読んで* 音楽を聴く
_*manga o yonde* ongaku o kiku_
= *membaca komik dan* mendengarkan musik

*帰って* 休む
_*kaette* yasumu_
= *pulang dan* beristirahat

💡 *Info*
Mungkin Anda kenal dengan ungkapan いってきます _ittekimasu_ yang berarti "aku pergi dulu ya", ungkapan ini juga menggunakan bentuk てte dari いくiku (pergi). Jika diartikan per kata maka akan menjadi "saya akan pergi lalu datang (kembali)"

Selain itu bentuk てte digunakan pada berbagai pola kalimat. Beberapa contohnya yaitu:

☆ Menunjukkan kegiatan yang sementara berlangsung dengan pola ~ている ~te iru:
• 遊ぶ asobu (bermain)
--> 遊んでいる asonde iru (sedang bermain)

☆ Membuat kalimat permintaan dengan pola ~てください ~te kudasai:
• 説明する setsumei suru (menjelaskan)
--> 説明してください setsumei shite kudasai (tolong jelaskan)

☆ Meminta izin dengan pola ~てもいいですか ~te mo ii desu ka:
• 聞く kiku (bertanya)
--> 聞いてもいいですか kiite mo ii desu ka (bolehkah saya bertanya)

☆ Membuat kalimat larangan dengan pola ~ては行けません ~te wa ikemasen
• タバコを吸う tabako o suu (merokok)
--> タバコを吸っては行けません tabako o sutte wa ikemasen (tidak boleh merokok)
☆ Dan lain-lain

_____________________________
23-5-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "67") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *単語 Tango* • Kosakata ⭐
☆ Tempat Makan ☆

🧊 お冷 ohiya : air dingin
📝 注文 chuumon : pesanan
       注文する chuumon suru : memesan
🍽️ 取り皿 torizara : piring makan (untuk masing-masing)
🥂 飲み放題 nomihoudai : menu minum sepuasnya
🥧 お通し otooshi : snack pembuka
💵 お会計 okaikei : tagihan
______________________________
22-12-20 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "68") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel からkara ☆
◇ Dari ◇

Partikel からkara sering diartikan "dari", yaitu menunjukkan asal atau titik awal waktu/tempat.

Contoh:
• 家 *から*
_ie *kara*_
= *dari* rumah

• 東京 *から*
_toukyou *kara*_
= *dari* Tokyo

• ３時 *から*
_san-ji *kara*_
= *dari* jam 3

📺 *Contoh Kalimat:*
• 会議は *１０時から* です。
  _kaigi wa *juu-ji kara* desu_
= Rapatnya (dimulai) *dari jam 10.*

• *先生から* 本をもらいました。
   _*sensei kara* hon o moraimashita_
= Saya mendapat buku *dari guru.*

• *アメリカから* 来ました。
  _*amerika kara* kimashita_
= Saya datang *dari Amerika*

_____________________________
29-5-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "69") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa

☆ Partikel より YORI ☆
◇ Daripada/Dari ◇

Partikel よるyori biasanya diartikan "daripada" atau "dari", yang dapat digunakan untuk menunjukkan perbandingan, dan juga menunjukkan titik mulai tempat atau waktu.

⚖️ *Perbandingan*
Contoh:
• *金より* 高い
  _*kin yori* takai_
  lebih mahal *daripada emas*

• *車より* 大きい
  _*kuruma yori* ookii_
  lebih besar *daripada mobil*

Contoh Kalimat:
• 北海道は *沖縄より* 寒い。
  _hokkaidou wa *okinawa yori* samui_
  Hokkaido lebih dingin *daripada Okinawa.*

• 薔薇が *チューリップより* 好きです。
  _bara ga *chuurippu yori* suki desu_
  Saya lebih suka mawar *daripada tulip*.

🛫 *Titik Mulai Waktu/Tempat*
Partikel よりyori dapat juga digunakan untuk mengungkapkan "dari", yaitu titik awal tempat atau waktu, sama seperti からkara. Tetapi penggunaan ini tergolong formal dan tidak sering dipakai sehari-hari, seperti penggunaan kara.

Contoh Kalimat:
• *千歳より* 出発します。
  _*chitose yori* shuppatsu shimasu_
  Kita akan berangkat *dari Chitose.*

• 博物館の展示は *６月１０日より* 開催されます。
  _hakubutsukan no tenji wa *rokugatsu tooka yori* kaisai saremasu_
  Pameran museum akan diselenggarakan *dari tanggal 10 Juni*.

_____________________________
3-6-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "70") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐

☆ Partikel とTO ☆
◇ Penghubung Kata Benda (DAN) ◇

Salah satu fungsi partikel とto adalah untuk mengungkapkan "dan".

Tetapi ini hanya berlaku pada kata-kata benda. Partikel とto diletakkan di belakang setiap kata bendanya.

[本と]     [紙と]
[hon to] [kami to]
= buku dan kertas

猫と       犬と    鶏と
neko to inu to niwatori to
= kucing, anjing, dan ayam

Partikel とto yang paling belakang bisa juga dihilangkan.

本と紙
_hon to kami_
= buku dan kertas

猫と犬と鶏
_neko to inu to niwatori_
kucing, anjing, dan ayam

📺 *Contoh Kalimat:*
• 彼女は *英語とフランス語* が話せる。
  _kanojo wa *eigo to furansu-go* ga hanaseru_
= Dia bisa berbicara dalam *bahasa Inggris dan bahasa Prancis.*

• *犬と猫と鶏と* を飼っています。
   _*inu to neko to niwatori to* o katte imasu_
= Saya memelihara *anjing, kucing, dan ayam*

_____________________________
7-6-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "71") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Pola Kalimat はもちろん wa mochiron ☆

Kata もちろん (勿論) mochiron sendiri berarti "tentu saja" atau "sudah pasti".

Kita bisa gunakan pola berikut ini:

A はもちろん、B も ....
_A wa mochiron, B mo ..._

Untuk mengungkapkan:
"Tidak hanya A, tapi B juga ..."

atau
"Jangankan A, B pun ...."

Versi yang lebih formal: はもとより wa motoyori


📺 *Contoh Kalimat:*
=======================
• 私は、 *車はもちろん、自転車も* ありません。
  _Watashi wa, *kuruma wa mochiron, jitensha mo* arimasen._
= *Jangankan mobil, sepeda pun* saya tidak punya.

• 彼は *英語はもちろん、日本語も* 上手ですよ。
  _Kare wa *eigo wa mochiron, nihongo mo* jouzu desu yo._
= Dia *tidak hanya* pandai *bahasa Inggris, tetapi* pandai *juga bahasa Jepang.*

• 「ナルト」は *日本はもちろん、インドネシアでも* 人気がある。
  _"Naruto" wa *nihon wa mochiron, indoneshia de mo* ninki ga aru._
= "Naruto" *tidak hanya* terkenal *di Jepang, tetapi juga di Indonesia.*

• 私が生まれた村は、 *電車はもとより、バスも* 通っていない。
  _Watashi ga umareta mura wa, *densha wa motoyori, basu mo* tootte inai._
= Di desa kelahiranku, *kereta saja* tidak lewat, *apalagi* bus.

_____________________________
11-6-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "72") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel や YA ☆

*Partikel やya* dapat digunakan seperti partikel とto, yaitu untuk menghubungkan kata-kata benda, dan dapat diartikan "dan".

Bedanya, jika kita gunakan partikel やya, maka kita hanya menyebutkan hanya sebagian dari hal-hal yang disebutkan.

*Contoh:*
車とオートバイと飛行機
_Kuruma to ootobai to hikouki_
= Mobil, motor, dan pesawat

Di sini benda-bendanya sudah disebutkan lengkap.

アメリカやブラジルやフランス
_Amerika ya burajiru ya furansu_
= *seperti/misalnya* Amerika, Brazil, Prancis, ...

Jika kita gunakan partikel やya, maka apa yang kita sebutkan itu hanya sebagian contoh saja, sehingga kita bisa artikan dalam bahasa Indonesia dengan tambahan kata seperti kata "seperti" atau "misalnya". Atau tambahan kata "dan lain-lain".

💡 *Partikel など Nado*
Kita bisa tambahkan などnado di akhir susunan kata-kata tersebut untuk lebih menekankan "dan lain-lain"-nya. Dan ini lebih formal karena lebih lengkap.

ペンや鉛筆など
_pen ya enpitsu nado_
= Pulpen, pensil, dan lain-lain

Jika kata bendanya hanya satu kita bisa pakai などnado saja.

猫など neko nado
= kucing dan lain-lain

📚 *Contoh Kalimat*
☆ 私はとても *車など* 買えない。
_Watashi wa totemo *kuruma nado* kaenai._
= Saya sungguh tidak mampu membeli *mobil dan lain-lain.*

☆ 毎朝、 *パンや卵など* を食べています。
_Maiasa, *pan ya tamago nado* o tabete imasu._
= Tiap pagi, saya memakan *roti, telur, dan lain-lain.*

☆ 彼らは *希望や慰め* について語った。
_Karera wa *kibou ya nagusame* ni tsuite katatta._
= Mereka bercerita soal *hal-hal seperti harapan dan kenyamanan.*

☆ 私は *靴や帽子* を買いました。
_Watashi wa *kutsu ya boushi* o kaimashita._
= Saya membeli *sepatu, topi, dll.*

☆ 友達と一緒に *焼肉やキムチ* を食べました。
_Tomodachi to issho ni *yakiniku ya kimuchi* o tabemashita._
= Saya makan *yakiniku, kimchi, dll* bersama teman.

☆ 机の上に *ペンや本など* があります。
_Tsukue no ue ni *pen ya hon nado* ga arimasu._
= Di atas meja ada *pensil, buku, dan lain-lain.*

_____________________________
20-6-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "73") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法* • Tata Bahasa ⭐
☆ Transitif dan Intransitif ☆

Kata kerja memiliki pembagian jenis transitif dan intransitif.

🔨 *Transitif (Memerlukan Objek)*
Kata kerja ini berupa aksi yang dilakukan terhadap benda lain. Contoh:
• 手紙を書く
  _tegami o kaku_
  menulis surat

Di sini kata kerja 書く kaku (menulis) termasuk *transitif* karena ia memerlukan objek 手紙 tegami (surat). Objek ditandai dengan partikel をo/wo setelah objek itu.

⚙️ *Intransitif (Tidak Perlu Objek)*
Kata kerja intransitif berarti berupa aksi yang dilakukan sendiri bukan kepada benda lain, karena memang tidak mempunyai objek. Contoh:
• 起きる
  _okiru_
  bangun

Kata kerja 起きる okiru (bangun) termasuk intransitif karena ia tidak perlu objek apapun, karena pelakunya sendiri bangun tanpa mempengaruhi benda lain.

❇️ *Transitif + Intransitif (Bisa Perlu Objek, Bisa Tidak)*
Terdapat juga kata kerja yang bisa menjadi transitif maupun intransitif tergantung kondisi. Misalnya kata kerja 歌う utau (menyanyi) berikut ini:
• 歌を歌う
  _uta o utau_
  menyanyikan lagu
(Transitif)

• 歌う
  _utau_
  menyanyi/bernyanyi
(Intransitif)

🈁 *Pasangan Transitif-Intransitif*
Di dalam bahasa Jepang ada juga pasangan kata kerja transitif-intransitif dari akar kata yang sama, dan kanjinya pun sama, namun pemaknaannya cukup berbeda. Oleh karena itu ini perlu diperhatikan.
Biasanya yang transitif berakhiran *-eru* atau *-su*.

Ingat, transitif berarti aksi itu dilakukan terhadap benda lain, sedangkan intransitif bisa berarti aksi itu dilakukan sendiri.

Contoh:

*Trans. ............ Intrans.*
==================
開ける ............ 開く
_akeru ............. aku_
membuka ...... terbuka

閉める ............ 閉まる
_shimeru ......... shimaru_
menutup ....... tertutup

出す ................ 出る
_dasu .............. deru_
mengeluarkan ... keluar

動かす ................ 動く
_ugokasu ............ ugoku_
menggerakkan ... bergerak

止める ............... 止まる
_tomeru ............. tomaru_
menghentikan ... berhenti

つける ............... つく
_tsukeru ............ tsuku_
menyalakan ..... menyala

消す ................... 消える
_kesu .................. kieru_
memadamkan ... padam

変える ................ 変わる
_kaeru ................. kawaru_
mengubah ......... berubah

治す ................... 治る
_naosu ............... naoru_
menyembuhkan ... sembuh

始める ................. 始まる
_hajimeru ............. hajimaru_
memulai ............. dimulai

集める .................. 集まる
_atsumeru ............ atsumaru_
mengumpulkan ... berkumpul

並べる ................. 並ぶ
_naraberu ............ narabu_
menyusun .......... tersusun
/membariskan ... berbaris

こぼれる .............. こぼす
_koboreru ............. kobosu_
menumpahkan ... tumpah

割れる .................. 割る
_wareru ................ waru_
memecahkan ...... pecah

切る .................. 切れる
_kiru ...................... kireru_
memotong .......... terpotong
/memutus ........... putus
_____________________________
25-2-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "74") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Partikel か ka ☆
◇ Atau ◇

Kita dapat gunakan partikel かka untuk mengungkapkan "atau" dan menghubungkan kata benda, seperti partikel とto (dan).

Contoh:
• お母さんか お父さんか
  _okaasan ka otousan ka_
  = ibu atau ayah

• チョコレートかアイスか
  _chokoreeto ka aisu ka_
  = coklat atau es krim

Partikel かka yang paling belakang dapat dihilangkan.
• お母さんかお父さん
  _okaasan ka otousan_
• チョコレートかアイス
  _chokoreeto ka aisu_

Jika digunakan di dalam kalimat, kadang setelah susunan katanya terdapat partikel lain, misalnya がga atau をo. Maka kita bisa hilangkan かka yang terakhir:

• 私はは *猫か犬* を飼います。
  _Watashi wa *neko ka inu* o kaimasu._
= Saya akan memelihara *kucing atau anjing.*

Atau kita bisa tetap pakai かka yang paling belakang dan menghilangkan partikel lain tersebut:

• 私は *猫か犬か* 飼います。
  _Watashi wa *neko ka inu ka* kaimasu._
= Saya akan memelihara *kucing atau anjing*.

🏵️ *Ungkapan かどうか ka dou ka*
Kita bisa gunakan ungkapan "ka dou ka" untuk mengungkapkan "apakah ... atau tidak/atau bagaimana", dan dapat disambungkan dengan kata kerja.

• *行くかどうか* わからない。
  _*Iku ka dou ka* wakaranai._
= Aku tidak tahu apakah *aku akan pergi atau tidak.*

• 彼女は *私が好きかどうか* 知らない。
  _Kanojo wa *watashi ga suki ka dou ka* shiranai._
= Aku tidak tahu *apakah dia suka kepadaku atau tidak.*

_____________________________
24-6-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "75") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Kata なんて Nante ☆

Kata なんて nante adalah salah satu kata yang biasa diucapkan orang Jepang dan mempunyai beberapa kegunaan berkaitan dengan emosi si pembicara. Kata ini digunakan pada situasi tidak formal.

Agar memudahkan pemahaman, mari kita lihat kata berdasarkan asalnya.

=======================
🚗 *なんて Nante dari Kata 等とて Nadotote*
=======================
等とて nado to te berarti "hal semacam itu dan lain-lain", sehingga makna なんて nante yang akan kita bahas pertama adalah menunjukkan "hal semacam itu" atau "lain-lain". Penggunaan なんてnante yang ini digunakan untuk memberi kesan "remeh", atau meremehkan kata yang diikuti なんてnante, atau menunjukkan rasa tidak suka kita terhadap kata itu.

Ketika kita benci dengan pekerjaan:
☆ *仕事なんて* 行きたくない。
     _*Shigoto nante* ikitakunai._
= Aku gak mau pergi *kerja.*
(Menunjukkan ketidaksukaan kita pada kata 仕事shigoto)

Untuk lebih memahami kesannya, anggap saja kata なんてnante berarti "hal semacam itu", jadi *仕事なんて shigoto nante* berarti seperti "hal semacam pekerjaan", atau "pekerjaan atau apalah itu".

☆ *試験なんて* 嫌いだ！
     _*Shiken nante* kirai da!_
= Aku benci *ujian!*
(benci hal semacam ujian)

☆ *漢字なんて* 書けない。
     _*Kanji nante* kakenai._
= Ga bisa nulis *kanji.*

Karena juga berkesan "meremehkan", maka kita dapat gunakan dengan makna seperti kata sisipan "mah" di bahasa Indonesia.

☆ *日本語なんて* 簡単だ。
     _*Nihongo nante* kantan da._
= *Bahasa Jepang _mah_* gampang...

☆ *犬なんて* 怖くない。
     _*Inu nante* kowakunai._
= *Anjing* nggak menyeramkan, kok. (aku nggak takut)

Bahkan meremehkan diri sendiri juga bisa:
☆ *私なんて* そんなに上手にできない。
     _*Watashi nante* sonna ni jouzu ni dekinai._
= *Aku* (orang sepertiku) tidak bisa melakukannya sehebat itu.

Tidak hanya kata benda, なんて nante dapat mengikuti kata kerja:

☆ 彼が *あんなことをするなんて* 信じられない。
     _Kare ga *anna koto o suru nante* shinjirarenai._
= Sulit dipercaya dia *melakukan hal semacam itu.*

Biasanya kalimatnya terpotong sampai なんて nante nya saja dan makna terkejutnya tersirat.

☆ まだ６月なのに台風が *来る* なんて
     _Mada rokugatsu nanoni taifuu ga *kuru nante*_
= Mengejutkan bahwa angin topan *datang* padahal masih bulan Juni.

=======================
🚕 *なんて Nante dari Kata 何とNanto / 何と言う Nantoiu*
=======================
何とnan to / 何と言う nan to iu berarti "apa" / "disebut apa" / "macam apa". Penggunaan なんてnante yang ini bisa berarti untuk mengungkapkan reaksi terkejut dengan sesuatu; "sungguh sesuatu yang ...". Digunakan di awal kalimat.

☆ *なんて* 美しい美女だな。
     _*Nante* utsukushii bijo da na._
= *Sungguh* wanita yang sangat cantik.

☆ *なんて* つまらない本なんだろう。
     _*Nante* tsumaranai hon nan darou._
= *Benar-benar* buku yang sangat membosankan.

☆ *なんて* 上手に日本語を話すんだ。
     _*Nante* jouzu ni nihon-go o hanasu nda._
= *Sungguh* mahir berbahasa Jepang dia.

Selain itu, bisa juga digunakan seperti 何と nan to seperti biasa (berarti "apa", "bahwa apa"), untuk kata kerja ucapan seperti 言う iu:

• *なんて* 言った?
  _*Nante* itta?_
= Kamu bilang *apa* ?
(何と言った | nan to itta)

_____________________________
23-7-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "76") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *文法 Bunpou* • Tata Bahasa ⭐
☆ Pola Kalimat: ~てある -te aru ☆

Pola kalimat ini menunjukkan suatu keadaan yang telah dipersiapkan sebelumnya. Misalnya jendela yang sudah dibuka, lampu yang sudah dinyalakan, dll.

⚙️ *Rumus:*
Kata Kerja bentuk ~て -te + ある aru

📚 *Contoh:*
• 作る tsukuru (membuat)
-> 作ってある tsukutte aru (sudah dibuatkan)

• 開ける akeru (membuka)
-> 開けてある akete aru (sudah dibukakan)

📺 *Contoh Kalimat:*

明日の弁当はもう *作ってある。*
_Ashita no bentou wa mou *tsukutte aru.*_
= Bekal untuk besok *sudah dibuatkan.*

窓が *開けてあります。*
_Mado ga *akete arimasu.*_
= Jendela *sudah dibukakan.*

箱には日本語の文字が *印刷してある*。
_Hako ni wa nihongo no moji ga *insatsu shite aru.*_
= Di dalam kotak *sudah dicetak* dengan huruf Jepang.

ホテルは *予約してあります* から、心配しないでください。
_Hoteru wa *yoyaku shite arimasu* kara, shinpai shinaide kudasai._
= Hotelnya *sudah dibooking*, jadi jangan khawatir.

君の靴下も全部 *洗濯してある*。
_Kimi no kutsushita mo zenbu *sentaku shite aru.*_
= Kaos kakimu pun semuanya *sudah dicucikan.*

_____________________________
1-8-21 | 🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "77") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *単語 Kosakata* ⭐
Benda-benda sekitar
_____________________________
• AC エアコン eakon
• baju シャツ shatsu
• bantal 枕 makura
• botol ボトル botoru
• buku 本 hon
• buku catatan ノート nooto
• cangkir teh 茶碗 chawan
• celana ズボン zubon
• cermin 鏡 kagami
• dinding 壁 kabe
• garpu フォーク fooku
• gelas コップ koppu
• gelas (kaca) グラス gurasu
• gorden カーテン kaaten
• gunting 鋏 hasami
• handuk タオル taoru
• jam 時計 tokei
• jendela 窓 mado
• kalkulator 電卓 dentaku
• karpet 絨毯 juutan
• kipas angin 扇風機 senpuuki
• kipas tangan 扇子 sensu
• kompor ストーブ sutoobu
• kulkas 冷蔵庫 reizouko
• kursi 椅子 isu
• lampu 電灯 dentou
• langit-langit 天井 tenjou
• lantai 床 yuka
• lemari 戸棚 todana
• meja テーブル teeburu
• meja kerja 机 tsukue
• mobil 車 kuruma
• motor バイク baiku
• panci ポット
• pasta gigi 歯磨き hamigaki
• pensil 鉛筆 enpitsu
• pintu ドア doa
• piring お皿 osara
• pisau ナイフ naifu
• pulpen ボールペン boorupen
• rak buku 本棚 hondana
• ransel リュックサック ryukkusakku
• sabun 石鹸 sekken
• sapu 箒 houki
• sampo シャンプー shanpuu
• selimut 毛布 moufu
• sendal サンダル sandaru
• sendok スプーン supuun
• sepatu 靴 kutsu
• sepeda 自転車 jitensha
• sikat gigi 歯ブラシ haburashi
• sofa ソファー sofaa
• stapler ホッチキス hocchikisu
• taplak meja テーブルクロス teeburukurosu
• televisi テレビ terebi
• tempat sampah ゴミ箱 gomibako
• tempat tidur ベッド beddo
• toilet トイレ toire
• topi 帽子 boushi
• watafel 流し nagashi
_____________________________
🇯🇵 Belajar Nihon-go
5-12-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "78") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Kanji* ⭐
Pengenalan
_____________________________
Selain hiragana dan katakana, ada satu lagi jenis huruf yang dipakai dalam bahasa Jepang: *Kanji*.

Kanji adalah huruf yang diambil dari huruf Cina, sehingga sebagian sama dengan huruf Cina.
Berikut contohnya dari yang paling sederhana sampai yang paling rumit:
一 七 万 不 出 両 亜 並 乗 個 乾 傘 園 語 質 機 覧 難 願 競 魔 驚 鑑 鷹 鬱 驫 麤 䯂

Cara membaca kanji juga tidak sembarang, kita harus lihat dia di dalam kata apa.
Jumlah kanji ada ribuan, tetapi *jangan panik,* orang Jepang sendiripun kebanyakan hanya mengingat kanji yang paling sering dipakai sehari-hari.. yaitu sekitar 2000.

Belajar kanji adalah salah satu tantangan yang besar dalam bahasa Jepang. Kita tidak bisa belajar semua kanji dulu sebelum lanjut. Kita sebaiknya belajar kanji beriringan dengan bahasa Jepang itu sendiri. Oleh karena itu, di dalam tes bahasa Jepang seperti JLPT, kanji dikelompokkan jadi beberapa level. Untuk level pemula yaitu level N5, ada sekitar 70 - 100 saja.
_____________________________
🇯🇵 Belajar Nihon-go
11-12-21`,
			},
			{ quoted: fverif },
		);
	} else if (text === "79") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Ungkapan-Ungkapan Umum*
#N507

🍁🍁🍁🍁🍁🍁🍁🍁

おはようございます Ohayou gozaimasu
= Selamat pagi

おはよう Ohayou
= Selamat pagi (lebih casual/biasa dari yang atas, biasanya untuk teman atau orang yang sudah akrab)

こんにちは Konnichiwa
= Selamat siang/halo (huruf [wa] di kosakata ini menggunakan huruf hiragana [は] karena spesial)

こんばんは Konbanwa
= Selamat malam (ini juga sama)

おつかれさまです Otsukaresama desu
= Selamat bekerja

おつかれさまでした Otsukaresama deshita
= Terimakasih atas kerja Anda

おやすみなさい Oyasuminasai
= Selamat malam/Selamat tidur

おやすみ Oyasumi
= Selamat malam/Selamat tidur (biasa)

さようなら Sayounara
= Selamat tinggal

じゃまた(ね) Ja mata (ne)
= Sampai jumpa lagi

またあとで Mata ato de
= Sampai nanti

またあした Mata ashita
= Sampai jumpa besok

いってきます Itte kimasu
= Aku berangkat

いってらっしゃい Itte rasshai
= Selamat jalan

ただいま Tadaima
= Aku pulang

おかえりなさい Okaerinasai
= Selamat pulang

おげんき ですか Ogenki desu ka
= Apa kabar?

はい、おげんきです Hai, ogenki desu
= Iya, saya baik

おひさしぶりですね Ohisashiburi desu ne
= Lama tak jumpa ya

ありがとうございます Arigatou gozaimasu
= Terima kasih

どうも Doumo
= Terima kasih

どういたしまして Dou itashimashite
= Sama-sama

こちらこそ、ありがとうございます Kochira koso arigatou gozaimasu
= Saya juga terima kasih

すみません Sumimasen
= Maaf/Permisi

ごめんなさい Gomennasai
= Maaf (biasa)

もうしわけありません/ございません Moushi wake arimasen/gozaimasen
= Mohon maaf (hormat)

しつれいします Shitsurei shimasu
= Punten/Permisi

おめでとう Omedetou
= Selamat/Congratulation

がんばって Ganbatte
= Semangat!

はい、がんばります Hai, ganbarimasu
= Iya, saya akan bersemangat!

おだいじに Odaijini
= Semoga cepat sembuh

おくやみ もうしあげます Okuyami moushi agemasu
= Turut berduka cita

ようこそ Youkoso
= Selamat datang!

いらっしゃいませ Irasshaimase
= Selamat datang (ke toko)

どうぞ Douzo
= Silahkan

おさきに Osaki ni
= Aku duluan ya

おさきにしつれいします Osaki ni shitsurei shimasu
= Saya permisi dulu (lebih sopan)

おまたせ Omatase
= Maaf sudah membuat Anda menunggu

おじゃまします Ojama shimasu
= Permisi (masuk ke rumah orang/ruangan)

いただきます Itadakimasu
= Selamat makan

ごちそうさまでした  Gochisousama deshita
= Terima kasih atas hidangannya

☘☘☘☘☘☘☘☘
*Sanada*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "80") {
		conn.sendMessage(
			m.chat,
			{
				text: `KOSAKATA - MENCUCI
単語一覧：洗濯

*物干し竿* _(monohoshi zao)_ tiang jemuran
*ハンガー* _(han’gaa)_ gantungan
*洗濯ばさみ* _(sentaku-basami)_ jepitan baju
*洗濯機* _(sentakuki)_ mesin cuci
*洗濯物* _(sentakumono)_ cucian
*洗濯板* _(sentaku ita)_ papan penggilasan
*白いもの* _(shiroi mono)_ pakaian putih
*色もの* _(iro mono)_ pakaian berwarna
*生地* _(kiji)_ kain
*素材* _(sozai)_ bahan (pakaian)
*しわ* _(shiwa)_ kerutan/lecek (pada pakaian)
*襟* _(eri)_ kerah (pada pakaian)
*色落ち* _(iro-ochi)_ warnanya luntur
*縮んだ* _(chijinda)_ kusut
*洗濯カゴ* _(sentaku kago)_ keranjang cucian
*しみ* _(shimi)_ noda
*洗剤* _(senzai)_ deterjen
*液体洗剤* _(ekitai senzai)_ deterjen cair
*粉末洗剤* _(funmatsu senzai)_ deterjen bubuk
*柔軟剤* _(juunanzai)_ pelembut/softener
*加香剤／芳香剤* _(kakouzai/houkouzai)_ pewangi/pengharum
*消臭剤* _(shoushuuzai)_ penghilang bau
*漂白剤* _(hyouhakuzai)_ pemutih
*クレンザー* _(kurenzaa)_ pembersih/cleanser
*洗濯する* _(sentaku suru)_ mencuci
*洗う* _(arau)_ mencuci
*濡れる／湿る* _(nureru/shimeru)_ basah
*濯ぐ* _(susugu)_ membilas (pakaian)
*絞る* _(shiboru)_ memeras (pakaian)
*干す* _(hosu)_ menjemur
*つるす* _(tsurusu)_ menggantungkan (pakaian)
*乾かす* _(kawakasu)_ mengeringkan
*乾く* _(kawaku)_ kering/mengering
*取り込む* _(torikomu)_ mengambil (pakaian yang dijemur)
*畳む* _(tatamu)_ melipat
*片付ける* _(katadzukeru)_ merapikan
*ドライクリーニング* _(dorai kuriinin’gu)_ cuci kering tanpa air (dry cleaning)
*洗濯代* _(sentaku dai)_ biaya laundry
*乾燥機* _(kansouki)_ mesin pengering
*二槽式洗濯機* _(nisoushiki sentakuki)_ mesin cuci dua tabung
*ドラム式洗濯機* _(doramu shiki sentakuki)_ mesin cuci bukaan depan (front loading)
*コイン式洗濯機* _(koin shiki sentakuki)_ mesin cuci koin

2021年7月18日(日)・亜間留`,
			},
			{ quoted: fverif },
		);
	} else if (text === "81") {
		conn.sendMessage(
			m.chat,
			{
				text: `*KOSAKATA - FENOMENA ALAM*
_*TANGO ICHIRAN : SHIZEN GENSHOU*_
*単語一覧：自然現象*

*虹* _(niji)_ = pelangi
*オーロラ* _(oorora)_ = aurora
*蜃気楼* _(shinkirou)_ = fatamorgana
*雲海* _(unkai)_ = lautan awan
*樹氷* _(juhyou)_ = pohon berbalut es
*干潮* _(kanchou)_ = pasang surut
*満潮* _(manchou)_ = pasang naik
*日食* _(nisshoku)_= gerhana matahari
*月食* _(gesshoku)_= gerhana bulan
*自然災害* _(shizen saigai)_ = bencana alam
*天災* _(tensai)_ = bencana alam
*渇水* _(kassui)_ = kekeringan
*洪水* _(kouzui)_ = banjir
*大洪水* _(daikouzui)_ = banjir besar
*鉄砲水* _(teppoumizu)_ = banjir yang datang tiba-tiba 
*波* _(nami)_ = ombak
*大波* _(oonami)_ = ombak besar
*津波* _(tsunami)_ = tsunami
*地震* _(jishin)_ = gempa bumi
*震源* _(shin’gen)_ = pusat gempa
*侵食* _(shinshoku)_ = erosi
*海岸侵食* _(kaigan shinshoku)_ = abrasi/erosi pantai
*地滑り* _(jisuberi)_ = tanah longsor
*土砂崩れ* _(doshakuzure)_ = tanah longsor
*崖崩れ* _(gakekuzure)_ = tebing longsor
*山崩れ* _(yamakuzure)_ = gunung longsor
*雪崩* _(nadare)_ = salju longsor
*吹雪* _(fubuki)_ = badai salju
*砂嵐* _(suna arashi)_ = badai pasir
*台風* _(taifuu)_ = angin topan
*竜巻* _(tatsumaki)_ = tornado, puting beliung
*噴火* _(funka)_ = erupsi, letusan (gunung berapi)
*噴火口* _(funkakou)_ = kawah (gunung berapi)
*溶岩* _(yougan)_ = lava, lahar
*噴煙* _(fun’en)_ = asap vulkanik
*火山灰* _(kazanbai)_ = debu vulkanik
*火災* _(kasai)_ = kebakaran
*火事* _(kaji)_ = kebakaran`,
			},
			{ quoted: fverif },
		);
	} else if (text === "82") {
		conn.sendMessage(
			m.chat,
			{
				text: `*KOSAKATA - RASA*
*単語一覧：味 _(AJI)_*

*美味しい* _(oishii)_ enak/lezat
*うまい* _(umai)_ enak/lezat
*旨味* _(umami)_ rasa lezat/gurih
*甘い* _(amai)_ manis
*苦い* _(nigai)_ pahit
*塩辛い／しょっぱい* _(shio karai/shoppai)_ asin
*酸っぱい* _(suppai)_ asam/masam
*辛い* _(karai)_ pedas
*渋い* _(shibui)_ sepet
*濃い* _(koi)_ kuat/pekat/kental
*薄い* _(usui)_ tidak kuat/tawar/encer
*硬い* _(katai)_ keras
*やわらかい* _(yawarakai)_ empuk
*油っこい* _(aburakkoi)_ berminyak`,
			},
			{ quoted: fverif },
		);
	} else if (text === "83") {
		conn.sendMessage(
			m.chat,
			{
				text: `*DAFTAR KOSAKATA - BUMBU*
_*TANGO ICHIRAN : CHOUMIRYOU*_
*単語一覧：調味料*

*香辛料／スパイス* _(koushinryou/supaisu)_ = rempah-rempah
*香料* _(kouryou)_ = penyedap rasa
*味付け* _(ajitsuke)_ = pemberian bumbu
*塩* _(shio)_ = garam
*砂糖* _(satou)_ = gula
*パームシュガー* _(paamu syugaa)_ = gula merah
*酢* _(su)_ = cuka
*醤油* _(shouyu)_ = kecap asin
*胡椒* _(koshou)_ = lada/merica
*生姜* _(shouga)_ = jahe
*ウコン* _(ukon)_ = kunyit
*バンウコン* _(ban ukon)_ = kencur
*ガランガル* _(garan’garu)_ = lengkuas/laos
*たまねぎ* _(tamanegi)_ = bawang bombay
*エシャロット／赤たまねぎ* _(esharotto/aka tamanegi)_ = bawang merah
*にんにく* _(ninniku)_ = bawang putih
*タマリンド* _(tamarindo)_ = asam jawa
*コリアンダー* _(koriandaa)_ = ketumbar
*キャンドルナッツ／ククイ* _(kyandoru nattsu/kukui)_ = kemiri
*ナツメグ* _(natsumegu)_ = biji pala
*胡麻* _(goma)_ = wijen
*丁字／クローブ* _(chouji/kuroobu)_ = cengkeh
*シナモン* _(shinamon)_ = kayu manis
*カルダモン* _(karudamon)_ = kapulaga
*レモングラス* _(remon gurasu)_ = serai/sereh
*レモンバジル* _(remon bajiru)_ = daun kemangi
*ニオイタコノキ* _(nioi takonoki)_ = daun pandan
*コブミカンの葉* _(kobumikan no ha)_ = daun jeruk
*ネギ／長ネギ* _(negi/naganegi)_ = daun bawang
*セロリ* _(serori)_ = daun seledri
*しそ* _(shiso)_ = daun shiso/perilla
*唐辛子* _(tougarashi)_ = cabai/cabe
*チリパウダー* _(chiri paudaa)_ = bubuk cabe
*カレーパウダー* _(karee paudaa)_ = bubuk kari
*ベーキングパウダー* _(beekin’gu paudaa)_ = baking powder
*重曹／ベーキングソーダ* _(juusou/beekin’gu sooda)_ = baking soda
*トラシ* _(torashi)_ = terasi
*味噌* _(miso)_ = miso (pasta kedelai Jepang)
*味醂* _(mirin)_ = mirin (arak masak Jepang)
*出汁* _(dashi)_ = dashi (kaldu Jepang)
*山葵* _(wasabi)_ = wasabi (lobak pedas Jepang)
*ジャム* _(jamu)_ = selai
*ソース* _(soosu)_ = saus
*サンバル* _(sanbaru)_ = sambal
*ケチャップ* _(kechappu)_ = saus tomat
*ケチャップマニス／甘口醤油* _(kechappu manisu/amakuchi shouyu)_ = kecap manis
*マヨネーズ* _(mayoneezu)_ = mayones
*辛子* _(karashi)_ = mustard
*チリソース* _(chiri soosu)_ = saus cabe
*ピーナッツソース* _(piinattsu soosu)_ = saus/bumbu kacang
*ウスターソース* _(usutaa soosu)_ = kecap inggris
*バーベキューソース* _(baabekyuu soosu)_ = saus BBQ
*ココナッツミルク* _(kokonattsu miruku)_ = santan
*油* _(abura)_ = minyak
*揚げ油* _(age abura)_ = minyak goreng
*ラード* _(raado)_ = minyak babi
*マーガリン* _(maagarin)_ = margarin
*バター* _(bataa)_ = mentega`,
			},
			{ quoted: fverif },
		);
	} else if (text === "84") {
		conn.sendMessage(
			m.chat,
			{
				text: `*KOSAKATA - PENYAKIT PADA ANAK*
_*TANGO ICHIRAN : KODOMO NO BYOUKI*_
*単語一覧：子供の病気*

*あせも* _(asemo)_ biang keringat
*とびひ* _(tobihi)_ impetigo
*いぼ* _(ibo)_ kutil
*てんかん* _(tenkan)_ epilepsi/ayan
*水ぼうそう* _(mizubousou)_ cacar air
*おたふく風邪* _(otafuku kaze)_ gondokan
*はしか* _(hashika)_ campak
*風疹* _(fuushin)_ rubella/campak Jerman
*アトピー性皮膚炎* _(atopii-sei hifuen)_ dermatitis atopik
*じんましん* _(jinmashin)_ urtikaria
*嘔吐下痢症* _(outo gerishou)_ muntaber
*プール熱* _(puuru-netsu)_ infeksi adenovirus
*百日咳* _(hyakunichi zeki)_ pertusis/batuk rejan
*溶連菌感染症* _(yourenkin kansenshou)_ infeksi streptokokus
*ヘルペス性口内炎* _(herupesu-sei kounaien)_ stomatitis herpes
*りんご病* _(rin’go-byou)_ penyakit kelima
*川崎病* _(kawasakibyou)_ penyakit Kawasaki`,
			},
			{ quoted: fverif },
		);
	} else if (text === "85") {
		conn.sendMessage(
			m.chat,
			{
				text: `*KOSAKATA - HARI NASIONAL DI INDONESIA*
*単語一覧：インドネシアの祝祭日*

*（西暦）新年* _(seireki) shinnen_ = Tahun Baru Masehi

*旧暦新年* _kyuureki shinnen_ = Tahun Baru Imlek

*ムハンマド昇天祭* _muhanmado shoutensai_ = Isra Mi’raj Nabi Muhammad SAW

*釈迦暦新年（ニュピ）* _shakareki shinnen (nyupi)_ = Tahun Baru Saka (Nyepi)

*キリスト受難の日* _kirisuto junan no hi_ = Wafat Isa Al Masih

*メーデー* _meedee_ = May Day/Hari Buruh Internasional

*仏教祭* _bukkyousai_ = Hari Raya Waisak

*キリスト昇天祭* _kirisuto shoutensai_ = Kenaikan Isa Al Masih

*断食明け大祭* _danjiki ake taisai_ = Hari Raya Idul Fitri

*パンチャシラの日* _panchashira no hi_ = Hari Lahir Pancasila

*犠牲祭の日* _giseisai no hi_ = Hari Raya Idul Adha

*インドネシア独立記念日* _indoneshia dokuritsu kinenbi_ = Hari Kemerdekaan RI

*回教暦新年* _kaikyoureki shinnen_ = Tahun Baru Islam

*ムハンマド誕生の日* _muhanmado tanjou no hi_ = Maulid Nabi Muhammad SAW

*クリスマス* _kurisumasu_ = Hari Raya Natal`,
			},
			{ quoted: fverif },
		);
	} else if (text === "86") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Kosa Kata Jepang* 
日本語の語彙
Nihongo no goi

1. Selamat pagi = おはようございます= *Ohayōgozaimasu* 
2.selamat malam = おやすみ = *Oyasumi* 
3.selamat siang =こんにちは = *Kon'nichiwa* 
4.Apa kabar 
元気ですか
 *Genkidesu ka?* 
5.bagaimana kabar mu hari ini 
今日は元気ですか 
 *Kyō wa genkidesuka* 
6.saya baik 
私は元気です
 *Watashi wa genkidesu* 
7.Terimakasih
ありがとうございます *Arigatōgozaimasu* 
8.sama-sama 
どういたしまして
 *Dōitashimashite* 
9.sampai jumpa
また後で
 *Mataatode* 
10.sampai jumpa besok
明日まで
 *Ashita made* 
11.selamat tinggal
さようなら
 *Sayōnara* 
12.hi = やあ *Yā* 
13.halo = 
こんにちは
 *Kon'nichiwa*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "87") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Ungkapan* ⭐

_Meminta Maaf_

Ungkapan yang umum adalah:
🙇🏻‍♂️ *ごめんなさい。*
_Gomennasai._
(Maafkan saya)

Atau singkatnya:
• ごめん _gomen_
• ごめんね _gomen ne_ (sedikit lebih halus)

Bisa ditambah kata 本当に _hontou ni_ untuk lebih menekankan.
🙇🏻‍♀️ *本当にごめんなさい。*
_Hontou ni gomennasai._
(Saya sungguh minta maaf.)

Ada ungkapan maaf yang ringan, misalnya ketika tidak sengaja menyenggol orang:
🙇🏻‍♂️ *すみません。*
_Sumimasen._
(Maaf/Permisi)
Kata ini tidak hanya untuk meminta maaf tetapi juga untuk yang lainnya (seperti Permisi).

Ungkapan yang lebih santai:
🙇🏻‍♀️ *悪い*
_warui_
(Salahku)

Ungkapan yang sangat formal dan serius:
🙇🏻‍♂️ *申し訳ありません。*
_Moushiwake arimasen._
Biasanya digunakan kepada atasan atau yg lebih berkuasa.

🙇🏻‍♀️ *許して(ください)。*
_Yurushite (kudasai)._
(Tolong) maafkan.
Digunakan ketika telah membuat kesal seseorang.

🙇🏻‍♂️ *勘弁して(ください)。*
_Kanben shite (kudasai)._
(Tolong maafkan/ampuni aku.)
Ungkapan ini menunjukkan betapa bersalahnya seseorang yang telah melakukan kesalahan yang besar.

Ungkapan maaf lainnya dalam situasi khusus:
🙇🏻‍♂️ *お邪魔します*
_Ojama shimasu._
(Maaf mengganggu.)
Ketika masuk/datang ke ruangan/rumah orang.

🙇🏻‍♀️ *謝罪いたします。*
_Shazai itashimasu._
(Saya memohon maaf.)
Biasanya ketika tokoh besar seperti selebriti atau politisi meminta maaf secara publik.

🙇🏻‍♂️ *失礼します。*
_Shitsurei shimasu._
(Maaf lancang)
Walaupun terjemahan kasarnya seperti ini, ungkapan ini biasanya tidak terlalu serius dan digunakan mirip seperti すみません _sumimasen_ (permisi), yaitu ketika ingin lewat atau masuk ke ruangan.

Tetapi ungkapan ini lebih sedikit lebih serius dan biasanya digunakan ke rekan kerja yg tidak terlalu akrab dengan kita:
🙇🏻‍♀️ *(これは)失礼しました。*
_(Kore wa) shitsurei shimashita._

🙇🏻‍♂️ *ご面倒をおかけしてすみません。*
_Gomendou o okakeshite sumimasen._
(Maaf sudah merepotkan.)
Ungkapan ini biasanya digunakan dalam dunia kerja kepada rekan ketika kita telah dibantu olehnya.
_____________________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "88") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Ungkapan* ⭐

飛ぶ鳥を落とす
_Tobu tori o otosu_
(Menjatuhkan burung yang terbang)

Ini adalah kiasan (idiom) yang bermakna *sangat kuat*

📚 *Contoh Kalimat*
● 当時、その作家は *飛ぶ鳥を落とす* 勢いだった。
_Touji, sono sakka wa *tobu tori o otosu* ikioi datta._
= Pada masanya, sang penulis mempunyai daya pengaruh yang *sangat kuat*.

● 小さな町工場だったが、今や *飛ぶ鳥を落とす* ほどの会社に成長した。
_Chiisana machikouba datta ga, ima ya *tobu tori o otosu* hodo no kaisha ni seichou shita._
= Dulunya hanya pabrik lokal kecil, tapi sekarang sudah tumbuh menjadi perusahaan yang bisa *menjatuhkan burung yang sedang terbang* (= perusahaan yang sangat kuat)

____________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "89") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Tata Bahasa* ⭐

_Menyusun Kalimat_

1 - Kelas Kata

Dalam seri materi ini kita akan belajar menyusun kalimat dalam bahasa Jepang mulai dari yang sederhana. Pertama-tama mari kita belajar sekilas kelas kata (jenis kata) apa saja yang ada dalam bahasa Jepang.

⚽ *Kata Benda*
Kata benda berarti kata-kata yang menunjukkan nama orang, benda, hal, makhluk, atau tempat.
• リンゴ _ringo_ (apel)
• 猫 _neko_ (kucing)
• 日本 _nihon_ (Jepang)
• 愛 _ai_ (cinta)
• サトウさん _Satou-san_ (Satou)

🔥 *Kata Sifat*
Adalah kata yang menjelaskan sifat/kualitas suatu kata benda, atau keadaannya.
• 暑い _atsui_ (panas)
• きれい _kirei_ (indah)
• 元気 _genki_ (sehat, baik2)

⛹🏻‍♂️ *Kata Kerja*
Kata yang menunjukkan apa yang dilakukan atau apa yang terjadi.
• 遊ぶ _asobu_ (bermain)
• 食べる _taberu_ (makan)
• 考える _kangaeru_ (berpikir)

↔️ *Partikel*
Kata-kata pendek (biasanya terdiri dari satu atau dua huruf) yang menandai peran suatu kata di dalam kalimat (subjek, objek, topik, lokasi, dll). Ada juga partikel yang mengubah nada kalimat (misalnya mengubah jadi pertanyaan)
• は _wa_ (penanda topik)
• が _ga_ (penanda subjek)
• に _wo/o_ (penanda objek)
• か _ka_ (akhiran kalimat tanya)

🕘 *Keterangan*
Kata yang menunjukkan lebih rinci tentang suatu kejadian (waktu, cara, tingkat)
• 昨日 _kinou_ (kemarin)
• 早く _hayaku_ (dengan cepat)
• 一番 _ichiban_ (paling)

💬 *Kata Seru*
Yaitu seruan atau ungkapan perasaan. Tidak terikat di dalam kalimat.
• はい _Hai._ (Iya.)
• いいえ _iie._ (Tidak.)
• へえ _Hee._ (Wah!)

____________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "90") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Tata Bahasa* ⭐

_Menyusun Kalimat_

2 - Topik Kalimat

Dalam seri ini kita akan belajar menyusun kalimat dalam bahasa Jepang mulai dari yang sederhana.

Pada bagian ini kita akan belajar tentang *topik kalimat*.

Bahasa Jepang biasanya berfokus pada topik pembicaraan. Topik bisa disebutkan dengan menambahkan partikel *は (wa)*

*Catatan: Partikel wa menggunakan huruf は (HA) tetapi dibaca "wa"

✏️ *Membuat Topik dengan は WA*
Contoh:
• *私は* watashi wa
• *あなたは* anata wa
• *猫は* neko wa

Setelah menyebutkan topik, kita bisa lanjutkan dengan predikat (apa yang dilakukan/terjadi)

○ 私は    食べています。
_Watashi wa tabete imasu._
Saya sedang makan.

Topik: 私 watashi (saya)
Predikat: 食べています tabete imasu (sedang makan)

____________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "91") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Tata Bahasa* ⭐

_Menyusun Kalimat_

3 - Predikat

Dalam seri ini kita akan belajar menyusun kalimat dalam bahasa Jepang mulai dari yang sederhana.

Pada bagian ini kita akan belajar *predikat* kalimat bahasa Jepang.

Predikat yaitu apa yang terjadi di dalam kalimat. Bisa berupa tindakan atau kejadian, atau informasi tentang topik/subjek. Predikat biasanya terletak di akhir kalimat.

📚 *Contoh:*
A) Menunjukkan tindakan.
● お母さんは *料理をしています。*
○ _Okaasan wa *ryouri o shite imasu.*_
》 Ibu *sedang memasak.*

B) Menunjukkan kejadian.
● 雨が *降りました。*
○ _Ame ga *furimashita*._
》 Hujan *turun*.

C) Menunjukkan informasi (identitas/sifat) tentang si subjek atau topik.
● お父さんは *警察官です。*
○ _Otousan wa *keisatsukan desu.*_
》 Ayahku *adalah polisi.*

● この部屋は *狭いです。*
○ _Kono heya wa *semai desu.*_
》 Ruangan ini *sempit.*

____________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "92") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Tata Bahasa* ⭐

_Menyusun Kalimat_

4 - Susunan Kalimat Dasar

Dalam seri ini kita akan belajar menyusun kalimat dalam bahasa Jepang mulai dari yang sederhana.

Pada materi kali ini kita akan membahas struktur / susunan kalimat bahasa Jepang yang dasar.

Dasar dari sebuah kalimat bahasa Jepang yaitu predikatnya. Dengan predikat sendiri kita sudah bisa membuat kalimat. Informasi lainnya bisa dipahami sesuai dengan konteks atau situasi.

📚 Contoh:
● 食べます。
○ _Tabemasu._
= (Akan) makan.

Contoh tersebut sudah bisa disebut dengan kalimat. Kita sudah tahu bahwa seseorang akan makan. Dan itu yang terpenting karena sudah memberikan inti cerita/kalimatnya.

Dari situ kita bisa mengerti siapa yang akan makan, apa yang akan dimakan tergantung pada situasi ketika kalimat itu diucapkan.

Misalnya, perhatikan dialog sederhana berikut:

A: 何をしますか?
     _Nani o shimasu ka?_
    (Akan melakukan apa?)

B: 食べます。
    _Tabemasu._
    (Makan.)

Pada contoh di atas, kita  tahu bahwa kemungkinan besar A bertanya kepada B, sehingga orang yang akan melakukan aksi makan adalah B. Namun kembali lagi pada situasi sebenarnya, bisa jadi juga yang dimaksud bukan B melainkan orang lain (tentunya ini perlu konteks yang jelas)

📚 Contoh lain:
A: 元気ですか?
    _Genki desu ka?_
    (Sehat?) / sering diterjemahkan "Apa kabar?"
B: はい、元気です。
    _Hai, genki desu._
    (Iya, sehat) / "Saya baik-baik saja."

____________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "93") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Tata Bahasa* ⭐

_Menyusun Kalimat_

5 - Kata "Desu" (です)

Sebelumnya kita belajar mengenai bagaimana sebuah kalimat minimal terdiri dari predikat. Pada contoh kalimatnya kita melihat contoh kalimat yang menggunakan kata kerja:

● 食べます。
     _Tabemasu._
 = (Saya akan) makan.

Namun seperti yg kita ketahui predikat tidak hanya terbatas pada kata kerja saja, dia bisa juga berupa keadaan atau informasi lain.

Kali ini kita akan menunjukkan "informasi"/"identitas" dari subjek/topik menggunakan kata  です.

Susunannya:
[kata benda] + です
[kata sifat] + です

Misalnya ketika mengenalkan nama kita:
● *ハナです。*
     _*Hana desu.*_
  = (Saya) *adalah Hana.*

Atau memberitahu nama dari suatu benda:
● これは *ペンです。*
     _Kore wa *pen desu.*_
   = Ini *adalah pulpen.*

Atau menjelaskan sifat:
● この部屋は *きれいです。*
     _Kono heya wa *kirei desu.*_
  = Ruangan ini *rapi.*

● お父さんの車は *黒いです。*
     _Otousan no kuruma wa *kuroi desu.*_
  = Mobil ayah *berwarna hitam.*

____________________
🇯🇵 Belajar Nihon-go`,
			},
			{ quoted: fverif },
		);
	} else if (text === "94") {
		conn.sendMessage(
			m.chat,
			{
				text: `⭐ *Kata-Kata Yang Paling Sering Digunakan*
Part 1

🛂 の (no) [Partikel kepunyaan]
• 私 *の本* (watashi no hon)
》Buku *(milik) saya* / Buku *ku*

➡️ に (ni) [Partikel arah/tujuan]
• 学校 *に行く* (gakkou *ni iku*)
》Pergi *ke sekolah*

✍️ する/します (suru/shimasu) [Melakukan]
• 何にを *します* か?
  (Nani o *shimasu* ka?)
》Apa yg akan kamu *lakukan*?

💬 は (wa) [Partikel Topik]
• あの人 *は* 誰ですか?
   (Ano hito *wa* dare desu ka?)
》Orang itu siapa?

🏸 を (o/wo) [Partikel Objek]
• パン *を* 食べる (pan *o* taberu)
》Memakan roti

👨‍🍳 が (ga) [Partikel Subjek]
• この動物は *目が* 大きいです。
  (Kono doubutsu wa *me ga* ookii desu.)
》Hewan ini *matanya* besar.

➕ と (to) [Dan]
• 兄 *と* 私 (ani *to* watashi)
》Kakak *dan* aku

🌎 年 (toshi/nen) [Tahun]
• 今は *２０２３年* です。
  (Ima wa *nisen nijuu sannen* desu.)
》Sekarang adalah *tahun 2023.*

🏠 で (de) [Partikel Lokasi Kejadian (Di)]
• 部屋 *で* 寝る (heya *de* neru)
》Tidur *di* kamar

💡 だ/です (da/desu) [Adalah]
• これ、僕の帽子 *だ* よ。
   (Kore, boku no boushi *da* yo.)
》Ini *(adalah)* topiku, lho.


_Sumber: LTL Language School_`,
			},
			{ quoted: fverif },
		);
	} else if (text === "95") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Pengenalan Bahasa Jepang*
#N501

🍁🍁🍁🍁🍁🍁🍁🍁

Untuk mempelajari suatu bahasa yang pertama dipelajari adalah mengenal huruf-huruf nya terlebih dahulu jika hurufnya berbeda dengan bahasa kita. Di dalam bahasa Jepang terdapat 3 huruf yang digunakan, masing-masing huruf mempunyai fungsinya sendiri. Huruf-huruf tersebut adalah:

1. ひらがな (hiragana), digunakan untuk menulis kosakata asli bahasa Jepang. Contoh : くち kuchi → mulut.

2. カタカナ (katakana), digunakan untuk menuliskan kata-kata serapan dari bahasa asing. Contoh : ナイフ naifu → pisau, dari kata knife bahasa Inggris.

3. 漢字 (kanji), digunakan untuk menggambarkan makna dari setiap kata. (kata benda, akar kata kerja, akar kata sifat, dan kata keterangan). Contoh : 本 (ほん) hon → buku.

Romaji adalah huruf abjad atau latin yang juga digunakan untuk menuliskan kata-kata dari bahasa asing dan mempermudah orang yang tidak bisa membaca tulisan Jepang. Di Jepang romaji sering digunakan untuk menuliskan singkatan dari suatu kata. Contoh : CV → Curriculum Vitae.

Dalam bahasa Jepang terdapat 5 tingkat atau level dari N5, N4, N3, N2, dan N1. N5 dan N4 adalah level termudah yaitu tingkat dasar pemahaman bahasa Jepang, N3 adalah level menengah, sementara N2 dan N1 adalah level paling sulit.

N5 merupakan level dasar yang menguji pemahaman dan penggunaan kosakata, tata bahasa dasar, serta hiragana, katakana, dan kanji dasar.

Kita akan memulai belajar N5 dengan huruf hiragana.

☘️☘️☘️☘️☘️☘️☘️☘️
*Sanada*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "96") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Huruf Hiragana Dasar*
#N502

🍁🍁🍁🍁🍁🍁🍁🍁

Huruf hiragana biasanya untuk menulis kata-kata asli atau yang berasal dari bahasa Jepang sendiri. Huruf hiragana juga bisa digunakan untuk menggantikan huruf kanji yang seharusnya belum dipelajari. Karena untuk pemula yang belajar bahasa Jepang biasanya masih banyak menggunakan Hiragana.

Huruf-Huruf Hiragana Dasar

あ   い   う   え   お
 a     i     u     e     o

か   き   く   け   こ
ka   ki    ku   ke   ko

さ   し   す   せ   そ
sa  shi  su   se   so

た   ち   つ   て   と
ta   chi  tsu  te   to

な   に   ぬ   ね   の
na   ni   nu   ne   no

は   ひ   ふ   へ   ほ
ha   hi   fu   he   ho

ま   み   む   め   も
ma  mi  mu me  mo

や       ゆ        よ
ya       yu       yo

ら   り   る   れ   ろ
ra   ri    ru  re   ro

わ                      を
wa                    wo
            ん
            n

Untuk menyusun kata dari huruf hiragana cukup mudah yaitu hanya dengan menambah huruf satu dengan huruf lainnya.

Contoh:
• ね + こ → ねこ (neko) → kucing
• ほ + ん → ほん (hon) → buku
• さ + く + ら → さくら (sakura) → bunga Sakura

Untuk mengahafal huruf hiragana biasanya memerlukan waktu satu hingga dua minggu atau bahkan lebih cepat. Hafalan bisa mulai dengan 5 huruf perhari atau lebih tergantung kemampuannya. Jadi semuanya harus semangat menghafalnya^^.

☘️☘️☘️☘️☘️☘️☘️☘️
*Sanada*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "97") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Huruf Hiragana (Tanda Tenten dan Maru)*
#N503

🍁🍁🍁🍁🍁🍁🍁🍁

*○ Tenten atau Dakuten ["]*

Digunakan untuk mengubah kana (hiragana/katakana) yang diawali dengan konsonan bersuara ([s], [t], [k] dan [h]) menjadi konsonan bersuara ([z], [d], [g] dan [b])

Daftar huruf hiragana dengan tanda tenten:

か  き く け こ -->  が ぎ ぐ げ ご
ka ki ku ke ko --> ga gi gu ge go

さ し す せ そ -->  ざ じ ず ぜ ぞ
sa shi su se so --> za ji zu ze zo

た ち つ て と   -->  だ  ぢ  づ  で  ど
ta chi tsu te to --> da ji dzu de do

は ひ ふ へ ほ  -->  ば び ぶ べ ぼ
ha hi fu he ho --> ba bi bu be bo

*○ Maru atau Handakuten [°]*

Digunakan untuk mengubah kana dengan awalan fonem [h] menjadi [p].

Daftar huruf hiragana dengan tanda maru:

は  ひ ふ へ ほ  -->  ぱ  ぴ  ぷ ぺ  ぽ 
ha hi fu he ho --> pa pi pu pe po

Contoh Kosakata:
• ぶた (buta) → babi
• かぎ (kagi) → kunci

Ada istilah dakuon dan handakuon

Dakuten adalah tanda tenten ["] sementara dakuon adalah huruf yang sudah diberi tenten.
Contoh:
[が、ぜ、じ] itu dinamakan Dakuon.

Ingat ya dakuten adalah tandanya sementara dakuon adalah huruf yang diberi tanda ten2.

begitu juga 

Handakuten adalah tanda maru [°] sementara handakuon adalah huruf yang diberi tanda maru tersebut.
Contoh:
[ぱ、ぷ] ini dinamakan handakuon.

Handakuten adalah tandanya, sementara handakuon adalah huruf yang diberi tanda maru itu.

☘️☘️☘️☘️☘️☘️☘️☘️
Sanada`,
			},
			{ quoted: fverif },
		);
	} else if (text === "98") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Tanda Tsu Kecil (っ) atau Sokuon*
#N504

🍁🍁🍁🍁🍁🍁🍁🍁

Tanda ini berbeda dari huruf [Tsu] yang biasa (つ). Tanda ini disebut juga dengan tanda sokuon.

Kegunaan dari tanda ini yaitu menggandakan (mendobelkan) bunyi huruf mati setelah tanda itu.

Contoh:

             か   → っか
             ka         kka

             ぽ   → っぽ
             po         ppo

             ち   → っち
             chi        cchi

             つ   → っつ
             tsu        ttsu

Contoh kata:
• がっこう gakkou (sekolah)
• さっき     sakki (tadi)

☘️☘️☘️☘️☘️☘️☘️☘️
*Sanada*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "99") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Huruf Ya, Yu, dan Yo kecil (ゃ、ゅ、ょ) atau Youon*
#N505

🍁🍁🍁🍁🍁🍁🍁🍁

Huruf kecil ini digabung dengan huruf biasa yang bervokal [i] untuk menggabungkan bunyinya.
Contoh:
き ki → きゃ kya
              きゅ kyu
              きょ kyo

Perhatikan bedanya dengan huruf ya, yu dan yo yang biasa:

   きや   →   きゃ
    kiya      　  *kya (bergabung)*

Daftar lengkap:
きゃ  きゅ  きょ 
 kya   kyu   kyo

ぎゃ  ぎゅ  ぎょ
gya    gyu   gyo

しゃ  しゅ  しょ
 sha   shu   sho

じゃ  じゅ  じょ
  ja     ju     jo

ちゃ  ちゅ  ちょ
cha    chu   cho 

ぢゃ  ぢゅ  ぢょ
  ja     ju     jo

にゃ  にゅ  にょ 
nya   nyu   nyo

ひゃ  ひゅ  ひょ
 hya   hyu   hyo

びゃ  びゅ  びょ
bya    byu    byo

ぴゃ  ぴゅ  ぴょ
pya    pyu   pyo

みゃ  みゅ  みょ 
mya  myu  myo

りゃ  りゅ  りょ
 rya   ryu    ryo

Perhatikan, bahwa tanda tenten dan maru juga masih berlaku untuk huruf yang dapat diberi tanda itu.

Contoh kata:
• きょう (kyou) → hari ini
• かいしゃ (kaisha) → perusahaan
• じゅう (juu) → sepuluh
• びょうき (byouki) → sakit

☘️☘️☘️☘️☘️☘️☘️☘️
*Sanada*`,
			},
			{ quoted: fverif },
		);
	} else if (text === "100") {
		conn.sendMessage(
			m.chat,
			{
				text: `*Bunyi Panjang atau Chouon*
#N506

🍁🍁🍁🍁🍁🍁🍁🍁

Chouon atau bunyi/vokal panjang adalah sistem bunyi yang terjadi ketika huruf konsonan berakhiran bunyi huruf vokal bertemu dengan huruf vokal [a/i/u/e/o], maka dibunyikan panjang 1 vokal.

Ketentuan:
① Jika huruf konsonan akhiran vokal [a] bertemu dengan vokal [a/あ] maka diperpanjang menjadi *[ā]*.
Contoh : おかあさん (okaasan) dibaca *okaāsan* → ibu

② Jika huruf konsonan akhiran vokal [e] bertemu dengan vokal [i/い] atau [e/え] maka diperpanjang menjadi *[ē]*.
Contoh :
• がくせい (gakusei) dibaca *gakusē* → pelajar
• おねえさん (oneesan) dibaca *onēsan* → kakak perempuan

③ Jika huruf konsonan akhiran vokal [o] bertemu dengan vokal [u/う] atau [o/お] maka diperpanjang menjadi *[ō]*.
Contoh :
• がっこう (gakkou) dibaca *gakkō* → sekolah
• とおい (tooi) dibaca *tōi* → jauh

Untuk konsonan akhiran vokal [u] dan [i] diperpanjang jika bertemu dengan vokal yang suaranya sama dengan akhiran itu sendiri (sama seperti vokal a) *[ū],[ī]*.

Panjang pendeknya suara sangatlah berpengaruh karena perbedaan panjang vokal dalam bahasa Jepang bisa merubah arti dari kata bahkan bisa sangat beda jauh.
Contoh:
しゅじん shujin → tuan rumah
しゅうじん shuujin → tahanan

☘️☘️☘️☘️☘️☘️☘️☘️
*Sanada*`,
			},
			{ quoted: fverif },
		);
	}
};
handler.help = ["materijepang"];
handler.tags = ["materi"];
handler.command = /^(materijepang|materijapan|matja)$/i;

handler.limit = true;
handler.group = true;

module.exports = handler;

let fverif = {
      key: { 
        participant: '0@s.whatsapp.net', 
        remoteJid: "0@s.whatsapp.net" 
      }, 
      message: {
        conversation: "*Mans-Wabot Terverifikasi Oleh WhatsApp*"
      }
    }