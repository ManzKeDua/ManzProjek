const axios = require('axios')

let manz = async (m, { conn, usedPrefix, text, command }) => {

if (!text) return m.reply(`Example: ${usedPrefix + command} cat`)
async function photoleap(prompt) {
    try {
        let result = []
        for (let i = 0; i < 3; i++) {
            let {
                data
            } = await axios.get('https://tti.photoleapapp.com/api/v1/generate?prompt=' + prompt);
            result.push(data.result_url)
        }
        return result
    } catch (e) {
        return ({
            msg: 404
        })
    }
}

let tahu = await photoleap(text)
for (const x of tahu) {
conn.sendMessage(m.chat, {image: {url: x}, caption: `Done`}, {quoted: m})
}
}
manz.help = ['txt2img']
manz.tags = ['ai']
manz.command = ['txt2img']
module.exports = manz