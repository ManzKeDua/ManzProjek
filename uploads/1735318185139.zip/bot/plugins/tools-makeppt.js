const pptxgen = require('pptxgenjs');
const { writeFile } = require('fs/promises');
const path = require('path');

let handler = async (m, { conn, text }) => {
    if (!text && !m.quoted) return conn.reply(m.chat, 'Balas pesan media atau masukkan prompt menggunakan perintah ini', m);

    let prompt = text || (m.quoted && m.quoted.text);
    let contents = prompt.split('\n').filter(line => line.trim() !== ''); // Membagi konten menjadi array garis teks

    // Membuat presentasi baru
    let pptx = new pptxgen();
    pptx.author = "AI Generator";

    // Fungsi untuk menambahkan teks dan gambar ke slide
    const addContentToSlide = async (slide, content) => {
        slide.addText(content, { x: 1, y: 0.5, fontSize: 18 });
        if (m.quoted && /image/.test(m.quoted.mimetype)) {
            let media = await m.quoted.download();
            let imagePath = path.join('/tmp', `image_${Date.now()}.png`);
            await writeFile(imagePath, media);
            slide.addImage({ path: imagePath, x: 1, y: 2.5, w: 4, h: 3 });
        }
    };

    // Tambahkan konten ke slide, buat slide baru jika tidak cukup ruang
    let slide;
    for (let i = 0; i < contents.length; i++) {
        if (i % 5 === 0) { // Misalnya, buat slide baru setiap 5 baris konten
            slide = pptx.addSlide();
            slide.addText(`Slide ${Math.floor(i / 5) + 1}`, { x: 1, y: 0.5, fontSize: 24, bold: true });
        }
        await addContentToSlide(slide, contents[i]);
    }

    // Simpan presentasi ke file
    let fileName = `/tmp/presentation_${Date.now()}.pptx`;
    pptx.writeFile({ fileName }).then(filePath => {
        conn.sendMessage(m.chat, { document: { url: filePath }, mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', fileName: `presentation_${Date.now()}.pptx` }, { quoted: m });
    }).catch(e => {
        console.error('Error saving file:', e);
        conn.reply(m.chat, `Terjadi kesalahan saat membuat presentasi: ${e.message}`, m);
    });
};

handler.help = ['makeppt'];
handler.tags = ['tools'];
handler.command = /^(makeppt)$/i;
module.exports = handler;