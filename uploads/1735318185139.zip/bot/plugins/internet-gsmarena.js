const cheerio = require('cheerio');
const axios = require('axios');

let handler = async (m, { conn, text }) => {
    if (!text) throw `Silakan masukkan nama perangkat yang ingin dicari.`;
    
    async function gsmSearch(q) {
        try {
            const response = await axios({
                method: "get",
                url: `https://gsmarena.com/results.php3?sQuickSearch=yes&sName=${q}`
            });
            const $ = cheerio.load(response.data);
            const result = [];
            
            const device = $(".makers").find("li");
            device.each((i, e) => {
                const img = $(e).find("img");
                result.push({
                    id: $(e).find("a").attr("href").replace(".php", ""),
                    name: $(e).find("span").html().split("<br>").join(" "),
                    description: img.attr("title")
                });
            });
            return result;
        } catch (error) {
            console.error(error);
            throw error;
        }
    }

    const q = text; // Menggunakan text sebagai query
    gsmSearch(q).then(results => {
        if (results.length === 0) {
            m.reply('Tidak ada hasil yang ditemukan.');
            return;
        }
        
        let replyText = `Hasil pencarian untuk "${q}":\n\n`;
        results.forEach((device, index) => {
            replyText += `${index + 1}. ${device.name}\nDeskripsi: ${device.description}\nLink: https://gsmarena.com/${device.id}.php\n\n`;
        });
        
        m.reply(replyText);
    }).catch(error => {
        m.reply('Terjadi kesalahan saat mencari perangkat.');
        console.error(error);
    });
}

handler.help = ['gsmarena'];
handler.tags = ['internet'];
handler.command = ['gsmarena'];
module.exports = handler;