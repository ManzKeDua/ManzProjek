let { MessageType } = require('@adiwajshing/baileys')
const Hab = 20000
const Hag = 15000
const Hr = 15000
const Hs = 20000
const Hbp = 50000
const Hga = 15000
const Hoa = 15000
const Hv = 50000
const Hsu = 30000
const Hb = 20000
const Hg = 100000
const Hso = 50000
const Hro = 10000
const Hib = 15000
const Hlb = 15000
const Hnb = 15000
const Hbb = 15000
const Hub = 15000
const Hpb = 200000
const Hkb = 20000
let handler  = async (m, { conn, command, args, usedPrefix, DevMode }) => {
    const _armor = global.db.data.users[m.sender].armor
    const armor = (_armor == 0 ? 20000 : '' || _armor == 1 ? 49999 : '' || _armor == 2 ? 99999 : '' || _armor == 3 ? 149999 : '' || _armor == 4 ? 299999 : '')
    let type = (args[0] || '').toLowerCase()
    let _type = (args[1] || '').toLowerCase()
    let jualbeli = (args[0] || '').toLowerCase()
    let ManzUrl = 'https://pomf2.lain.la/f/rwfeh7ac.mp4'
    const Kchat = `━━━━━━━━━━━━━━━━━\n
╭──『 ғᴏᴏᴅ 』
│⬡ *AyamBakar* : ${Hab}
│⬡ *AyamGoreng* : ${Hag} 
│⬡ *Rendang* : ${Hr} 
│⬡ *Steak* : ${Hs} 
│⬡ *BabiPanggang* : ${Hbp} 
│⬡ *Gulaiayam* : ${Hga} 
│⬡ *Oporayam* : ${Hoa} 
│⬡ *Vodka* : ${Hv} 
│⬡ *Sushi* : ${Hsu} 
│⬡ *Bandage* : ${Hb} 
│⬡ *Ganja* : ${Hg} 
│⬡ *Soda* : ${Hso} 
│⬡  *Roti* : ${Hro}
│⬡ *Ikanbakar* : ${Hib}
│⬡ *Lelebakar* : ${Hlb}
│⬡ *Nilabakar* : ${Hnb}
│⬡ *Bawalbakar* : ${Hbb}
│⬡ *Udangbakar* : ${Hub}
│⬡ *Pausbakar* : ${Hpb}
│⬡ *Kepitingbakar* : ${Hkb}
╰───────────────
━━━━━━━━━━━━━━━━━

> *Contoh pembelian :*
#resto beli food jumlah
#resto beli ayambakar 2
`.trim()
    try {
        if (/resto/i.test(command)) {
            const count = args[2] && args[2].length > 0 ? Math.min(99999999, Math.max(parseInt(args[2]), 1)) : !args[2] || args.length < 4 ? 1 :Math.min(1, count)
            const sampah = global.db.data.users[m.sender].sampah
            switch (jualbeli) {
            case 'beli':
                switch (_type) {
                    case 'ayambakar':
                            if (global.db.data.users[m.sender].money >= Hab * count) {
                                global.db.data.users[m.sender].money -= Hab * count
                                global.db.data.users[m.sender].ayambakar += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Ayam Bakar dengan harga ${Hab * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'ayamgoreng':
                            if (global.db.data.users[m.sender].money >= Hag * count) {
                                global.db.data.users[m.sender].ayamgoreng += count * 1
                                global.db.data.users[m.sender].money -= Hag * count
                                conn.reply(m.chat, `Succes membeli ${count} Ayam Goreng dengan harga ${Hag * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'rendang':
                            if (global.db.data.users[m.sender].money >= Hr * count) {
                                global.db.data.users[m.sender].rendang += count * 1
                                global.db.data.users[m.sender].money -= Hr * count
                                conn.reply(m.chat, `Succes membeli ${count} Rendang dengan harga ${Hr * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'steak':
                            if (global.db.data.users[m.sender].money >= Hs * count) {
                                global.db.data.users[m.sender].steak += count * 1
                                global.db.data.users[m.sender].money -= Hs * count
                                conn.reply(m.chat, `Succes membeli ${count} Steak dengan harga ${Hs * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'babipanggang':
                            if (global.db.data.users[m.sender].money >= Hbp * count) {
                                global.db.data.users[m.sender].babipanggang += count * 1
                                global.db.data.users[m.sender].money -= Hbp * count
                                conn.reply(m.chat, `Succes membeli ${count} Babi Panggang dengan harga ${Hbp * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'gulaiayam':
                            if (global.db.data.users[m.sender].money >= Hga * count) {
                                global.db.data.users[m.sender].money -= Hga * count
                                global.db.data.users[m.sender].gulai += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Gulai Ayam dengan harga ${Hga * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'oporayam':
                            if (global.db.data.users[m.sender].money >= Hoa * count) {
                                global.db.data.users[m.sender].oporayam += count * 1
                                global.db.data.users[m.sender].money -= Hoa * count
                                conn.reply(m.chat, `Succes membeli ${count} Opor Ayam dengan harga ${Hoa * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'vodka':
                            if (global.db.data.users[m.sender].money >= Hv * count) {
                                global.db.data.users[m.sender].vodka += count * 1
                                global.db.data.users[m.sender].money -= Hv * count
                                conn.reply(m.chat, `Succes membeli ${count} Vodka dengan harga ${Hv * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'sushi':
                            if (global.db.data.users[m.sender].money >= Hsu * count) {
                                global.db.data.users[m.sender].sushi += count * 1
                                global.db.data.users[m.sender].money -= Hsu * count
                                conn.reply(m.chat, `Succes membeli ${count} Sushi dengan harga ${Hsu * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'bandage':
                            if (global.db.data.users[m.sender].money >= Hb * count) {
                                global.db.data.users[m.sender].bandage += count * 1
                                global.db.data.users[m.sender].money -= Hb * count
                                conn.reply(m.chat, `Succes membeli ${count} Bandage dengan harga ${Hb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'ganja':
                            if (global.db.data.users[m.sender].money >= Hg * count) {
                                global.db.data.users[m.sender].money -= Hg * count
                                global.db.data.users[m.sender].ganja += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Ganja dengan harga ${Hg * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'soda':
                            if (global.db.data.users[m.sender].money >= Hso * count) {
                                global.db.data.users[m.sender].soda += count * 1
                                global.db.data.users[m.sender].money -= Hso * count
                                conn.reply(m.chat, `Succes membeli ${count} Soda dengan harga ${Hso * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'roti':
                            if (global.db.data.users[m.sender].money >= Hro * count) {
                                global.db.data.users[m.sender].roti += count * 1
                                global.db.data.users[m.sender].money -= Hro * count
                                conn.reply(m.chat, `Succes membeli ${count} Roti dengan harga ${Hro * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'ikanbakar':
                            if (global.db.data.users[m.sender].money >= Hib * count) {
                                global.db.data.users[m.sender].ikanbakar += count * 1
                                global.db.data.users[m.sender].money -= Hib * count
                                conn.reply(m.chat, `Succes membeli ${count} Ikan Bakar dengan harga ${Hib * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'lelebakar':
                            if (global.db.data.users[m.sender].money >= Hlb * count) {
                                global.db.data.users[m.sender].lelebakar += count * 1
                                global.db.data.users[m.sender].money -= Hlb * count
                                conn.reply(m.chat, `Succes membeli ${count} Lele Bakar dengan harga ${Hlb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'nilabakar':
                            if (global.db.data.users[m.sender].money >= Hnb * count) {
                                global.db.data.users[m.sender].money -= Hnb * count
                                global.db.data.users[m.sender].nilabakar += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Nila Bakar dengan harga ${Hnb * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'bawalbakar':
                            if (global.db.data.users[m.sender].money >= Hbb * count) {
                                global.db.data.users[m.sender].bawalbakar += count * 1
                                global.db.data.users[m.sender].money -= Hbb * count
                                conn.reply(m.chat, `Succes membeli ${count} Bawal Bakar dengan harga ${Hbb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'udangbakar':
                            if (global.db.data.users[m.sender].money >= Hub * count) {
                                global.db.data.users[m.sender].udangbakar += count * 1
                                global.db.data.users[m.sender].money -= Hub * count
                                conn.reply(m.chat, `Succes membeli ${count} Udang Bakar dengan harga ${Hub * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'pausbakar':
                            if (global.db.data.users[m.sender].money >= Hpb * count) {
                                global.db.data.users[m.sender].pausbakar += count * 1
                                global.db.data.users[m.sender].money -= Hpb * count
                                conn.reply(m.chat, `Succes membeli ${count} Paus Bakar dengan harga ${Hpb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'kepitingbakar':
                            if (global.db.data.users[m.sender].money >= Hkb * count) {
                                global.db.data.users[m.sender].kepitingbakar += count * 1
                                global.db.data.users[m.sender].money -= Hkb * count
                                conn.reply(m.chat, `Succes membeli ${count} Kepiting Bakar dengan harga ${Hkb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    default:
                        return conn.reply(m.chat, Kchat, m)
                }
                break
            default:
                return conn.sendFile(m.chat, thumb, 'pasar.jpg', `${Kchat}`, m)
            }
        } else if (/beli/i.test(command)) {
            const count = args[1] && args[1].length > 0 ? Math.min(99999999, Math.max(parseInt(args[1]), 1)) : !args[1] || args.length < 3 ? 1 : Math.min(1, count)
            switch (type) {
                case 'ayambakar':
                            if (global.db.data.users[m.sender].money >= Hab * count) {
                                global.db.data.users[m.sender].money -= Hab * count
                                global.db.data.users[m.sender].ayambakar += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Ayam Bakar dengan harga ${Hab * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'ayamgoreng':
                            if (global.db.data.users[m.sender].money >= Hag * count) {
                                global.db.data.users[m.sender].ayamgoreng += count * 1
                                global.db.data.users[m.sender].money -= Hag * count
                                conn.reply(m.chat, `Succes membeli ${count} Ayam Goreng dengan harga ${Hag * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'rendang':
                            if (global.db.data.users[m.sender].money >= Hr * count) {
                                global.db.data.users[m.sender].rendang += count * 1
                                global.db.data.users[m.sender].money -= Hr * count
                                conn.reply(m.chat, `Succes membeli ${count} Rendang dengan harga ${Hr * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'steak':
                            if (global.db.data.users[m.sender].money >= Hs * count) {
                                global.db.data.users[m.sender].steak += count * 1
                                global.db.data.users[m.sender].money -= Hs * count
                                conn.reply(m.chat, `Succes membeli ${count} Steak dengan harga ${Hs * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'babipanggang':
                            if (global.db.data.users[m.sender].money >= Hbp * count) {
                                global.db.data.users[m.sender].babipanggang += count * 1
                                global.db.data.users[m.sender].money -= Hbp * count
                                conn.reply(m.chat, `Succes membeli ${count} Babi Panggang dengan harga ${Hbp * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'gulaiayam':
                            if (global.db.data.users[m.sender].money >= Hga * count) {
                                global.db.data.users[m.sender].money -= Hga * count
                                global.db.data.users[m.sender].gulai += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Gulai Ayam dengan harga ${Hga * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'oporayam':
                            if (global.db.data.users[m.sender].money >= Hoa * count) {
                                global.db.data.users[m.sender].oporayam += count * 1
                                global.db.data.users[m.sender].money -= Hoa * count
                                conn.reply(m.chat, `Succes membeli ${count} Opor Ayam dengan harga ${Hoa * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'vodka':
                            if (global.db.data.users[m.sender].money >= Hv * count) {
                                global.db.data.users[m.sender].vodka += count * 1
                                global.db.data.users[m.sender].money -= Hv * count
                                conn.reply(m.chat, `Succes membeli ${count} Vodka dengan harga ${Hv * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'sushi':
                            if (global.db.data.users[m.sender].money >= Hsu * count) {
                                global.db.data.users[m.sender].sushi += count * 1
                                global.db.data.users[m.sender].money -= Hsu * count
                                conn.reply(m.chat, `Succes membeli ${count} Sushi dengan harga ${Hsu * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'bandage':
                            if (global.db.data.users[m.sender].money >= Hb * count) {
                                global.db.data.users[m.sender].bandage += count * 1
                                global.db.data.users[m.sender].money -= Hb * count
                                conn.reply(m.chat, `Succes membeli ${count} Bandage dengan harga ${Hb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'ganja':
                            if (global.db.data.users[m.sender].money >= Hg * count) {
                                global.db.data.users[m.sender].money -= Hg * count
                                global.db.data.users[m.sender].ganja += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Ganja dengan harga ${Hg * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'soda':
                            if (global.db.data.users[m.sender].money >= Hso * count) {
                                global.db.data.users[m.sender].soda += count * 1
                                global.db.data.users[m.sender].money -= Hso * count
                                conn.reply(m.chat, `Succes membeli ${count} Soda dengan harga ${Hso * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'roti':
                            if (global.db.data.users[m.sender].money >= Hro * count) {
                                global.db.data.users[m.sender].roti += count * 1
                                global.db.data.users[m.sender].money -= Hro * count
                                conn.reply(m.chat, `Succes membeli ${count} Roti dengan harga ${Hro * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'ikanbakar':
                            if (global.db.data.users[m.sender].money >= Hib * count) {
                                global.db.data.users[m.sender].ikanbakar += count * 1
                                global.db.data.users[m.sender].money -= Hib * count
                                conn.reply(m.chat, `Succes membeli ${count} Ikan Bakar dengan harga ${Hib * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'lelebakar':
                            if (global.db.data.users[m.sender].money >= Hlb * count) {
                                global.db.data.users[m.sender].lelebakar += count * 1
                                global.db.data.users[m.sender].money -= Hlb * count
                                conn.reply(m.chat, `Succes membeli ${count} Lele Bakar dengan harga ${Hlb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'nilabakar':
                            if (global.db.data.users[m.sender].money >= Hnb * count) {
                                global.db.data.users[m.sender].money -= Hnb * count
                                global.db.data.users[m.sender].nilabakar += count * 1
                                conn.reply(m.chat, `Succes membeli ${count} Nila Bakar dengan harga ${Hnb * count} money`, m)
                            } else conn.reply(m.chat, `Money Tidak Cukup`,)
                        break
                    case 'bawalbakar':
                            if (global.db.data.users[m.sender].money >= Hbb * count) {
                                global.db.data.users[m.sender].bawalbakar += count * 1
                                global.db.data.users[m.sender].money -= Hbb * count
                                conn.reply(m.chat, `Succes membeli ${count} Bawal Bakar dengan harga ${Hbb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'udangbakar':
                            if (global.db.data.users[m.sender].money >= Hub * count) {
                                global.db.data.users[m.sender].udangbakar += count * 1
                                global.db.data.users[m.sender].money -= Hub * count
                                conn.reply(m.chat, `Succes membeli ${count} Udang Bakar dengan harga ${Hub * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                    case 'pausbakar':
                            if (global.db.data.users[m.sender].money >= Hpb * count) {
                                global.db.data.users[m.sender].pausbakar += count * 1
                                global.db.data.users[m.sender].money -= Hpb * count
                                conn.reply(m.chat, `Succes membeli ${count} Paus Bakar dengan harga ${Hpb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                   case 'kepitingbakar':
                            if (global.db.data.users[m.sender].money >= Hkb * count) {
                                global.db.data.users[m.sender].kepitingbakar += count * 1
                                global.db.data.users[m.sender].money -= Hkb * count
                                conn.reply(m.chat, `Succes membeli ${count} Kepiting Bakar dengan harga ${Hkb * count} money`, m)
                            } else conn.reply(m.chat, `Money anda tidak cukup`, m)                       
                        break
                default:
                    return conn.sendFile(m.chat, Kchat, ManzUrl, 'resto.mp4', m)
            }
        }
    } catch (e) {
        conn.reply(m.chat, Kchat, m)
        console.log(e)
        if (DevMode) {
            for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid)) {
                conn.sendMessage(jid, 'shop.js error\nNo: *' + m.sender.split`@`[0] + '*\nCommand: *' + m.text + '*\n\n*' + e + '*', MessageType.text)
            }
        }
    }
}

handler.help = ['resto *<beli> <args>*']
handler.tags = ['rpg']    

handler.command = /^(resto|beli)$/i
module.exports = handler