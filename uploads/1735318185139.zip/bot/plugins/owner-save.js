const fs = require('fs');
const syntaxError = require('syntax-error');
const path = require('path');
const util = require('util');

const _fs = fs.promises;

let handler = async (m, { text, usedPrefix, command, __dirname }) => {
   let input = `[!] *wrong input*\n\nEx : ${usedPrefix + command} example.js`;
   if (!text) return m.reply(input);
   if (!m.quoted) throw `Balas/quote media/text yang ingin disimpan`;

   if (/p(lugin)?/i.test(command)) {
        let filename = text.replace(/plugin(s)\//i, '') + (/\.js$/i.test(text) ? '' : '.js');
        const error = syntaxError(m.quoted.text, filename, {
            sourceType: 'module',
            allowReturnOutsideFunction: true,
            allowAwaitOutsideFunction: true
        });
        if (error) throw error;

        let fileContent = m.quoted.text;
        // Check if file is an ESM module, and convert to CJS if true
        if (/import\s|export\s/.test(fileContent)) {
            fileContent = convertESMtoCJS(fileContent);
            m.reply(`Detected ESM format, converting to CommonJS...`);
        }

        const pathFile = path.join(__dirname, filename);
        await _fs.writeFile(pathFile, fileContent);
        m.reply(`Successfully saved to *${filename}*`);
    } else {
        const isJavascript = m.quoted.text && !m.quoted.mediaMessage && /\.js/.test(text);
        if (isJavascript) {
            let fileContent = m.quoted.text;
            const error = syntaxError(fileContent, text, {
                sourceType: 'module',
                allowReturnOutsideFunction: true,
                allowAwaitOutsideFunction: true
            });
            if (error) throw error;

            // Convert ESM to CJS if applicable
            if (/import\s|export\s/.test(fileContent)) {
                fileContent = convertESMtoCJS(fileContent);
                m.reply(`Detected ESM format, converting to CommonJS...`);
            }

            await _fs.writeFile(text, fileContent);
            m.reply(`Successfully saved to *${text}*`);
        } else if (m.quoted.mediaMessage) {
            const media = await m.quoted.download();
            await _fs.writeFile(text, media);
            m.reply(`Successfully saved media to *${text}*`);
        } else {
            throw 'Not supported!!';
        }
    }
};

// ESM to CJS conversion function
function convertESMtoCJS(esmCode) {
    // Convert import statements
    let cjsCode = esmCode.replace(/import\s+([a-zA-Z0-9{},\s*]+)\s+from\s+['"](.*)['"];?/g, (match, imports, module) => {
        if (imports.includes("{")) {
            const [defaultImport, namedImports] = imports.split("{");
            let result = '';
            if (defaultImport.trim()) {
                result += `const ${defaultImport.trim()} = require('${module}');\n`;
            }
            if (namedImports) {
                result += `const { ${namedImports.replace("}", "").trim()} } = require('${module}');`;
            }
            return result;
        } else {
            return `const ${imports.trim()} = require('${module}');`;
        }
    });

    // Convert export default to module.exports
    cjsCode = cjsCode.replace(/export\s+default/g, 'module.exports =');

    // Convert export async function to exports.asyncFunction
    cjsCode = cjsCode.replace(/export\s+async\s+function\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)\s*{/g, 'exports.$1 = async function ($2) {');

    // Convert export function to exports.function
    cjsCode = cjsCode.replace(/export\s+function\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)\s*{/g, 'exports.$1 = function ($2) {');

    // Convert named exports (export const ...) to exports.<name> =
    cjsCode = cjsCode.replace(/export\s+const\s+([a-zA-Z0-9_]+)\s+=/g, 'exports.$1 =');

    // Convert grouped export (export { ... }) to module.exports = { ... }
    cjsCode = cjsCode.replace(/export\s*{\s*([^}]+)\s*};/g, (match, exportedVars) => {
        return `module.exports = { ${exportedVars.trim()} };`;
    });

    // Special case: Handle export without semicolon at the end
    cjsCode = cjsCode.replace(/export\s*{\s*([^}]+)\s*}/g, (match, exportedVars) => {
        return `module.exports = { ${exportedVars.trim()} };`;
    });

    // Convert dynamic imports (import()) to require syntax
    cjsCode = cjsCode.replace(/import\((.*)\)/g, 'require($1)');

    return cjsCode;
}

handler.help = ['plugin', 'scraper'].map(v => `save ${v} <name file>`);
handler.tags = ['owner'];
handler.command = /^(save)$/i;

handler.rowner = true;

module.exports = handler;

/*
*Don't Delete This WM*
Code By Dani
https://whatsapp.com/channel/0029VamiWH7AojYyFAZytI0R
*/